"use strict";
(() => {
  // ../shared/dist/currencies/index.js
  var CURRENCIES = {
    USD: { code: "USD", name: "US Dollar", symbol: "$", flag: "\u{1F1FA}\u{1F1F8}", decimalDigits: 2, countries: ["US"] },
    EUR: { code: "EUR", name: "Euro", symbol: "\u20AC", flag: "\u{1F1EA}\u{1F1FA}", decimalDigits: 2, countries: ["DE", "FR", "IT", "ES", "NL", "BE", "AT", "IE", "FI", "PT", "GR"] },
    GBP: { code: "GBP", name: "British Pound", symbol: "\xA3", flag: "\u{1F1EC}\u{1F1E7}", decimalDigits: 2, countries: ["GB"] },
    INR: { code: "INR", name: "Indian Rupee", symbol: "\u20B9", flag: "\u{1F1EE}\u{1F1F3}", decimalDigits: 2, countries: ["IN"] },
    JPY: { code: "JPY", name: "Japanese Yen", symbol: "\xA5", nativeSymbol: "\uFFE5", flag: "\u{1F1EF}\u{1F1F5}", decimalDigits: 0, countries: ["JP"] },
    CAD: { code: "CAD", name: "Canadian Dollar", symbol: "CA$", flag: "\u{1F1E8}\u{1F1E6}", decimalDigits: 2, countries: ["CA"] },
    AUD: { code: "AUD", name: "Australian Dollar", symbol: "A$", flag: "\u{1F1E6}\u{1F1FA}", decimalDigits: 2, countries: ["AU"] },
    CHF: { code: "CHF", name: "Swiss Franc", symbol: "CHF", flag: "\u{1F1E8}\u{1F1ED}", decimalDigits: 2, countries: ["CH", "LI"] },
    CNY: { code: "CNY", name: "Chinese Yuan", symbol: "CN\xA5", nativeSymbol: "\xA5", flag: "\u{1F1E8}\u{1F1F3}", decimalDigits: 2, countries: ["CN"] },
    AED: { code: "AED", name: "UAE Dirham", symbol: "AED", flag: "\u{1F1E6}\u{1F1EA}", decimalDigits: 2, countries: ["AE"] },
    AFN: { code: "AFN", name: "Afghan Afghani", symbol: "Af", flag: "\u{1F1E6}\u{1F1EB}", decimalDigits: 2, countries: ["AF"] },
    ALL: { code: "ALL", name: "Albanian Lek", symbol: "ALL", flag: "\u{1F1E6}\u{1F1F1}", decimalDigits: 2, countries: ["AL"] },
    AMD: { code: "AMD", name: "Armenian Dram", symbol: "AMD", flag: "\u{1F1E6}\u{1F1F2}", decimalDigits: 2, countries: ["AM"] },
    ANG: { code: "ANG", name: "NL Antillean Guilder", symbol: "ANG", flag: "\u{1F1E8}\u{1F1FC}", decimalDigits: 2, countries: ["CW", "SX"] },
    AOA: { code: "AOA", name: "Angolan Kwanza", symbol: "AOA", flag: "\u{1F1E6}\u{1F1F4}", decimalDigits: 2, countries: ["AO"] },
    ARS: { code: "ARS", name: "Argentine Peso", symbol: "AR$", flag: "\u{1F1E6}\u{1F1F7}", decimalDigits: 2, countries: ["AR"] },
    AZN: { code: "AZN", name: "Azerbaijani Manat", symbol: "man.", flag: "\u{1F1E6}\u{1F1FF}", decimalDigits: 2, countries: ["AZ"] },
    BAM: { code: "BAM", name: "Bosnia-Herzegovina Mark", symbol: "KM", flag: "\u{1F1E7}\u{1F1E6}", decimalDigits: 2, countries: ["BA"] },
    BBD: { code: "BBD", name: "Barbados Dollar", symbol: "BBD", flag: "\u{1F1E7}\u{1F1E7}", decimalDigits: 2, countries: ["BB"] },
    BDT: { code: "BDT", name: "Bangladeshi Taka", symbol: "\u09F3", flag: "\u{1F1E7}\u{1F1E9}", decimalDigits: 2, countries: ["BD"] },
    BGN: { code: "BGN", name: "Bulgarian Lev", symbol: "BGN", flag: "\u{1F1E7}\u{1F1EC}", decimalDigits: 2, countries: ["BG"] },
    BHD: { code: "BHD", name: "Bahraini Dinar", symbol: "BD", flag: "\u{1F1E7}\u{1F1ED}", decimalDigits: 3, countries: ["BH"] },
    BIF: { code: "BIF", name: "Burundian Franc", symbol: "FBu", flag: "\u{1F1E7}\u{1F1EE}", decimalDigits: 0, countries: ["BI"] },
    BMD: { code: "BMD", name: "Bermudian Dollar", symbol: "BMD", flag: "\u{1F1E7}\u{1F1F2}", decimalDigits: 2, countries: ["BM"] },
    BND: { code: "BND", name: "Brunei Dollar", symbol: "BN$", flag: "\u{1F1E7}\u{1F1F3}", decimalDigits: 2, countries: ["BN"] },
    BOB: { code: "BOB", name: "Bolivian Boliviano", symbol: "Bs", flag: "\u{1F1E7}\u{1F1F4}", decimalDigits: 2, countries: ["BO"] },
    BRL: { code: "BRL", name: "Brazilian Real", symbol: "R$", flag: "\u{1F1E7}\u{1F1F7}", decimalDigits: 2, countries: ["BR"] },
    BSD: { code: "BSD", name: "Bahamian Dollar", symbol: "BSD", flag: "\u{1F1E7}\u{1F1F8}", decimalDigits: 2, countries: ["BS"] },
    BTN: { code: "BTN", name: "Bhutanese Ngultrum", symbol: "Nu.", flag: "\u{1F1E7}\u{1F1F9}", decimalDigits: 2, countries: ["BT"] },
    BWP: { code: "BWP", name: "Botswana Pula", symbol: "BWP", flag: "\u{1F1E7}\u{1F1FC}", decimalDigits: 2, countries: ["BW"] },
    BYN: { code: "BYN", name: "Belarusian Ruble", symbol: "Br", flag: "\u{1F1E7}\u{1F1FE}", decimalDigits: 2, countries: ["BY"] },
    BZD: { code: "BZD", name: "Belize Dollar", symbol: "BZ$", flag: "\u{1F1E7}\u{1F1FF}", decimalDigits: 2, countries: ["BZ"] },
    CDF: { code: "CDF", name: "Congolese Franc", symbol: "CDF", flag: "\u{1F1E8}\u{1F1E9}", decimalDigits: 2, countries: ["CD"] },
    CLP: { code: "CLP", name: "Chilean Peso", symbol: "CL$", flag: "\u{1F1E8}\u{1F1F1}", decimalDigits: 0, countries: ["CL"] },
    COP: { code: "COP", name: "Colombian Peso", symbol: "CO$", flag: "\u{1F1E8}\u{1F1F4}", decimalDigits: 2, countries: ["CO"] },
    CRC: { code: "CRC", name: "Costa Rican Col\xF3n", symbol: "\u20A1", flag: "\u{1F1E8}\u{1F1F7}", decimalDigits: 2, countries: ["CR"] },
    CUP: { code: "CUP", name: "Cuban Peso", symbol: "CUP", flag: "\u{1F1E8}\u{1F1FA}", decimalDigits: 2, countries: ["CU"] },
    CVE: { code: "CVE", name: "Cape Verdean Escudo", symbol: "CV$", flag: "\u{1F1E8}\u{1F1FB}", decimalDigits: 2, countries: ["CV"] },
    CZK: { code: "CZK", name: "Czech Koruna", symbol: "K\u010D", flag: "\u{1F1E8}\u{1F1FF}", decimalDigits: 2, countries: ["CZ"] },
    DJF: { code: "DJF", name: "Djiboutian Franc", symbol: "Fdj", flag: "\u{1F1E9}\u{1F1EF}", decimalDigits: 0, countries: ["DJ"] },
    DKK: { code: "DKK", name: "Danish Krone", symbol: "kr", flag: "\u{1F1E9}\u{1F1F0}", decimalDigits: 2, countries: ["DK", "GL", "FO"] },
    DOP: { code: "DOP", name: "Dominican Peso", symbol: "RD$", flag: "\u{1F1E9}\u{1F1F4}", decimalDigits: 2, countries: ["DO"] },
    DZD: { code: "DZD", name: "Algerian Dinar", symbol: "DA", flag: "\u{1F1E9}\u{1F1FF}", decimalDigits: 2, countries: ["DZ"] },
    EGP: { code: "EGP", name: "Egyptian Pound", symbol: "EGP", flag: "\u{1F1EA}\u{1F1EC}", decimalDigits: 2, countries: ["EG"] },
    ERN: { code: "ERN", name: "Eritrean Nakfa", symbol: "Nfk", flag: "\u{1F1EA}\u{1F1F7}", decimalDigits: 2, countries: ["ER"] },
    ETB: { code: "ETB", name: "Ethiopian Birr", symbol: "Br", flag: "\u{1F1EA}\u{1F1F9}", decimalDigits: 2, countries: ["ET"] },
    FJD: { code: "FJD", name: "Fijian Dollar", symbol: "FJ$", flag: "\u{1F1EB}\u{1F1EF}", decimalDigits: 2, countries: ["FJ"] },
    FKP: { code: "FKP", name: "Falkland Islands Pound", symbol: "FK\xA3", flag: "\u{1F1EB}\u{1F1F0}", decimalDigits: 2, countries: ["FK"] },
    GEL: { code: "GEL", name: "Georgian Lari", symbol: "\u20BE", flag: "\u{1F1EC}\u{1F1EA}", decimalDigits: 2, countries: ["GE"] },
    GHS: { code: "GHS", name: "Ghanaian Cedi", symbol: "GH\u20B5", flag: "\u{1F1EC}\u{1F1ED}", decimalDigits: 2, countries: ["GH"] },
    GIP: { code: "GIP", name: "Gibraltar Pound", symbol: "\xA3", flag: "\u{1F1EC}\u{1F1EE}", decimalDigits: 2, countries: ["GI"] },
    GMD: { code: "GMD", name: "Gambian Dalasi", symbol: "D", flag: "\u{1F1EC}\u{1F1F2}", decimalDigits: 2, countries: ["GM"] },
    GNF: { code: "GNF", name: "Guinean Franc", symbol: "FG", flag: "\u{1F1EC}\u{1F1F3}", decimalDigits: 0, countries: ["GN"] },
    GTQ: { code: "GTQ", name: "Guatemalan Quetzal", symbol: "Q", flag: "\u{1F1EC}\u{1F1F9}", decimalDigits: 2, countries: ["GT"] },
    GYD: { code: "GYD", name: "Guyanaese Dollar", symbol: "GY$", flag: "\u{1F1EC}\u{1F1FE}", decimalDigits: 2, countries: ["GY"] },
    HKD: { code: "HKD", name: "Hong Kong Dollar", symbol: "HK$", flag: "\u{1F1ED}\u{1F1F0}", decimalDigits: 2, countries: ["HK"] },
    HNL: { code: "HNL", name: "Honduran Lempira", symbol: "L", flag: "\u{1F1ED}\u{1F1F3}", decimalDigits: 2, countries: ["HN"] },
    HRK: { code: "HRK", name: "Croatian Kuna", symbol: "kn", flag: "\u{1F1ED}\u{1F1F7}", decimalDigits: 2, countries: ["HR"] },
    HTG: { code: "HTG", name: "Haitian Gourde", symbol: "G", flag: "\u{1F1ED}\u{1F1F9}", decimalDigits: 2, countries: ["HT"] },
    HUF: { code: "HUF", name: "Hungarian Forint", symbol: "Ft", flag: "\u{1F1ED}\u{1F1FA}", decimalDigits: 0, countries: ["HU"] },
    IDR: { code: "IDR", name: "Indonesian Rupiah", symbol: "Rp", flag: "\u{1F1EE}\u{1F1E9}", decimalDigits: 0, countries: ["ID"] },
    ILS: { code: "ILS", name: "Israeli New Shekel", symbol: "\u20AA", flag: "\u{1F1EE}\u{1F1F1}", decimalDigits: 2, countries: ["IL"] },
    IQD: { code: "IQD", name: "Iraqi Dinar", symbol: "IQD", flag: "\u{1F1EE}\u{1F1F6}", decimalDigits: 3, countries: ["IQ"] },
    IRR: { code: "IRR", name: "Iranian Rial", symbol: "IRR", flag: "\u{1F1EE}\u{1F1F7}", decimalDigits: 0, countries: ["IR"] },
    ISK: { code: "ISK", name: "Icelandic Kr\xF3na", symbol: "kr", flag: "\u{1F1EE}\u{1F1F8}", decimalDigits: 0, countries: ["IS"] },
    JMD: { code: "JMD", name: "Jamaican Dollar", symbol: "J$", flag: "\u{1F1EF}\u{1F1F2}", decimalDigits: 2, countries: ["JM"] },
    JOD: { code: "JOD", name: "Jordanian Dinar", symbol: "JD", flag: "\u{1F1EF}\u{1F1F4}", decimalDigits: 3, countries: ["JO"] },
    KES: { code: "KES", name: "Kenyan Shilling", symbol: "KSh", flag: "\u{1F1F0}\u{1F1EA}", decimalDigits: 2, countries: ["KE"] },
    KGS: { code: "KGS", name: "Kyrgystani Som", symbol: "KGS", flag: "\u{1F1F0}\u{1F1EC}", decimalDigits: 2, countries: ["KG"] },
    KHR: { code: "KHR", name: "Cambodian Riel", symbol: "\u17DB", flag: "\u{1F1F0}\u{1F1ED}", decimalDigits: 2, countries: ["KH"] },
    KMF: { code: "KMF", name: "Comorian Franc", symbol: "CF", flag: "\u{1F1F0}\u{1F1F2}", decimalDigits: 0, countries: ["KM"] },
    KRW: { code: "KRW", name: "South Korean Won", symbol: "\u20A9", flag: "\u{1F1F0}\u{1F1F7}", decimalDigits: 0, countries: ["KR"] },
    KWD: { code: "KWD", name: "Kuwaiti Dinar", symbol: "KD", flag: "\u{1F1F0}\u{1F1FC}", decimalDigits: 3, countries: ["KW"] },
    KYD: { code: "KYD", name: "Cayman Islands Dollar", symbol: "CI$", flag: "\u{1F1F0}\u{1F1FE}", decimalDigits: 2, countries: ["KY"] },
    KZT: { code: "KZT", name: "Kazakhstani Tenge", symbol: "\u20B8", flag: "\u{1F1F0}\u{1F1FF}", decimalDigits: 2, countries: ["KZ"] },
    LAK: { code: "LAK", name: "Laotian Kip", symbol: "\u20AD", flag: "\u{1F1F1}\u{1F1E6}", decimalDigits: 0, countries: ["LA"] },
    LBP: { code: "LBP", name: "Lebanese Pound", symbol: "LB\xA3", flag: "\u{1F1F1}\u{1F1E7}", decimalDigits: 0, countries: ["LB"] },
    LKR: { code: "LKR", name: "Sri Lankan Rupee", symbol: "SLRs", flag: "\u{1F1F1}\u{1F1F0}", decimalDigits: 2, countries: ["LK"] },
    LRD: { code: "LRD", name: "Liberian Dollar", symbol: "L$", flag: "\u{1F1F1}\u{1F1F7}", decimalDigits: 2, countries: ["LR"] },
    LSL: { code: "LSL", name: "Lesotho Loti", symbol: "LSL", flag: "\u{1F1F1}\u{1F1F8}", decimalDigits: 2, countries: ["LS"] },
    LYD: { code: "LYD", name: "Libyan Dinar", symbol: "LD", flag: "\u{1F1F1}\u{1F1FE}", decimalDigits: 3, countries: ["LY"] },
    MAD: { code: "MAD", name: "Moroccan Dirham", symbol: "MAD", flag: "\u{1F1F2}\u{1F1E6}", decimalDigits: 2, countries: ["MA", "EH"] },
    MDL: { code: "MDL", name: "Moldovan Leu", symbol: "MDL", flag: "\u{1F1F2}\u{1F1E9}", decimalDigits: 2, countries: ["MD"] },
    MGA: { code: "MGA", name: "Malagasy Ariary", symbol: "MGA", flag: "\u{1F1F2}\u{1F1EC}", decimalDigits: 0, countries: ["MG"] },
    MKD: { code: "MKD", name: "Macedonian Denar", symbol: "MKD", flag: "\u{1F1F2}\u{1F1F0}", decimalDigits: 2, countries: ["MK"] },
    MMK: { code: "MMK", name: "Myanma Kyat", symbol: "MMK", flag: "\u{1F1F2}\u{1F1F2}", decimalDigits: 0, countries: ["MM"] },
    MNT: { code: "MNT", name: "Mongolian Tugrik", symbol: "\u20AE", flag: "\u{1F1F2}\u{1F1F3}", decimalDigits: 2, countries: ["MN"] },
    MOP: { code: "MOP", name: "Macanese Pataca", symbol: "MOP$", flag: "\u{1F1F2}\u{1F1F4}", decimalDigits: 2, countries: ["MO"] },
    MRU: { code: "MRU", name: "Mauritanian Ouguiya", symbol: "MRU", flag: "\u{1F1F2}\u{1F1F7}", decimalDigits: 2, countries: ["MR"] },
    MUR: { code: "MUR", name: "Mauritian Rupee", symbol: "MURs", flag: "\u{1F1F2}\u{1F1FA}", decimalDigits: 2, countries: ["MU"] },
    MVR: { code: "MVR", name: "Maldivian Rufiyaa", symbol: "Rf", flag: "\u{1F1F2}\u{1F1FB}", decimalDigits: 2, countries: ["MV"] },
    MWK: { code: "MWK", name: "Malawian Kwacha", symbol: "MK", flag: "\u{1F1F2}\u{1F1FC}", decimalDigits: 2, countries: ["MW"] },
    MXN: { code: "MXN", name: "Mexican Peso", symbol: "MX$", flag: "\u{1F1F2}\u{1F1FD}", decimalDigits: 2, countries: ["MX"] },
    MYR: { code: "MYR", name: "Malaysian Ringgit", symbol: "RM", flag: "\u{1F1F2}\u{1F1FE}", decimalDigits: 2, countries: ["MY"] },
    MZN: { code: "MZN", name: "Mozambican Metical", symbol: "MTn", flag: "\u{1F1F2}\u{1F1FF}", decimalDigits: 2, countries: ["MZ"] },
    NAD: { code: "NAD", name: "Namibian Dollar", symbol: "N$", flag: "\u{1F1F3}\u{1F1E6}", decimalDigits: 2, countries: ["NA"] },
    NGN: { code: "NGN", name: "Nigerian Naira", symbol: "\u20A6", flag: "\u{1F1F3}\u{1F1EC}", decimalDigits: 2, countries: ["NG"] },
    NIO: { code: "NIO", name: "Nicaraguan C\xF3rdoba", symbol: "C$", flag: "\u{1F1F3}\u{1F1EE}", decimalDigits: 2, countries: ["NI"] },
    NOK: { code: "NOK", name: "Norwegian Krone", symbol: "kr", flag: "\u{1F1F3}\u{1F1F4}", decimalDigits: 2, countries: ["NO", "SJ"] },
    NPR: { code: "NPR", name: "Nepalese Rupee", symbol: "NPRs", flag: "\u{1F1F3}\u{1F1F5}", decimalDigits: 2, countries: ["NP"] },
    NZD: { code: "NZD", name: "New Zealand Dollar", symbol: "NZ$", flag: "\u{1F1F3}\u{1F1FF}", decimalDigits: 2, countries: ["NZ", "CK", "NU", "PN"] },
    OMR: { code: "OMR", name: "Omani Rial", symbol: "OMR", flag: "\u{1F1F4}\u{1F1F2}", decimalDigits: 3, countries: ["OM"] },
    PAB: { code: "PAB", name: "Panamanian Balboa", symbol: "B/.", flag: "\u{1F1F5}\u{1F1E6}", decimalDigits: 2, countries: ["PA"] },
    PEN: { code: "PEN", name: "Peruvian Nuevo Sol", symbol: "S/.", flag: "\u{1F1F5}\u{1F1EA}", decimalDigits: 2, countries: ["PE"] },
    PGK: { code: "PGK", name: "Papua New Guinean Kina", symbol: "K", flag: "\u{1F1F5}\u{1F1EC}", decimalDigits: 2, countries: ["PG"] },
    PHP: { code: "PHP", name: "Philippine Peso", symbol: "\u20B1", flag: "\u{1F1F5}\u{1F1ED}", decimalDigits: 2, countries: ["PH"] },
    PKR: { code: "PKR", name: "Pakistani Rupee", symbol: "PKRs", flag: "\u{1F1F5}\u{1F1F0}", decimalDigits: 2, countries: ["PK"] },
    PLN: { code: "PLN", name: "Polish Zloty", symbol: "z\u0142", flag: "\u{1F1F5}\u{1F1F1}", decimalDigits: 2, countries: ["PL"] },
    PYG: { code: "PYG", name: "Paraguayan Guarani", symbol: "\u20B2", flag: "\u{1F1F5}\u{1F1FE}", decimalDigits: 0, countries: ["PY"] },
    QAR: { code: "QAR", name: "Qatari Rial", symbol: "QR", flag: "\u{1F1F6}\u{1F1E6}", decimalDigits: 2, countries: ["QA"] },
    RON: { code: "RON", name: "Romanian Leu", symbol: "RON", flag: "\u{1F1F7}\u{1F1F4}", decimalDigits: 2, countries: ["RO"] },
    RSD: { code: "RSD", name: "Serbian Dinar", symbol: "din.", flag: "\u{1F1F7}\u{1F1F8}", decimalDigits: 2, countries: ["RS"] },
    RUB: { code: "RUB", name: "Russian Ruble", symbol: "\u20BD", flag: "\u{1F1F7}\u{1F1FA}", decimalDigits: 2, countries: ["RU"] },
    RWF: { code: "RWF", name: "Rwandan Franc", symbol: "RWF", flag: "\u{1F1F7}\u{1F1FC}", decimalDigits: 0, countries: ["RW"] },
    SAR: { code: "SAR", name: "Saudi Riyal", symbol: "SR", flag: "\u{1F1F8}\u{1F1E6}", decimalDigits: 2, countries: ["SA"] },
    SBD: { code: "SBD", name: "Solomon Islands Dollar", symbol: "SI$", flag: "\u{1F1F8}\u{1F1E7}", decimalDigits: 2, countries: ["SB"] },
    SCR: { code: "SCR", name: "Seychellois Rupee", symbol: "SRe", flag: "\u{1F1F8}\u{1F1E8}", decimalDigits: 2, countries: ["SC"] },
    SDG: { code: "SDG", name: "Sudanese Pound", symbol: "SDG", flag: "\u{1F1F8}\u{1F1E9}", decimalDigits: 2, countries: ["SD"] },
    SEK: { code: "SEK", name: "Swedish Krona", symbol: "kr", flag: "\u{1F1F8}\u{1F1EA}", decimalDigits: 2, countries: ["SE"] },
    SGD: { code: "SGD", name: "Singapore Dollar", symbol: "S$", flag: "\u{1F1F8}\u{1F1EC}", decimalDigits: 2, countries: ["SG"] },
    SHP: { code: "SHP", name: "Saint Helena Pound", symbol: "\xA3", flag: "\u{1F1F8}\u{1F1ED}", decimalDigits: 2, countries: ["SH"] },
    SLL: { code: "SLL", name: "Sierra Leonean Leone", symbol: "Le", flag: "\u{1F1F8}\u{1F1F1}", decimalDigits: 2, countries: ["SL"] },
    SOS: { code: "SOS", name: "Somali Shilling", symbol: "Ssh", flag: "\u{1F1F8}\u{1F1F4}", decimalDigits: 2, countries: ["SO"] },
    SRD: { code: "SRD", name: "Surinamese Dollar", symbol: "$", flag: "\u{1F1F8}\u{1F1F7}", decimalDigits: 2, countries: ["SR"] },
    STN: { code: "STN", name: "S\xE3o Tom\xE9 and Pr\xEDncipe Dobra", symbol: "Db", flag: "\u{1F1F8}\u{1F1F9}", decimalDigits: 2, countries: ["ST"] },
    SYP: { code: "SYP", name: "Syrian Pound", symbol: "SY\xA3", flag: "\u{1F1F8}\u{1F1FE}", decimalDigits: 2, countries: ["SY"] },
    SZL: { code: "SZL", name: "Swazi Lilangeni", symbol: "SZL", flag: "\u{1F1F8}\u{1F1FF}", decimalDigits: 2, countries: ["SZ"] },
    THB: { code: "THB", name: "Thai Baht", symbol: "\u0E3F", flag: "\u{1F1F9}\u{1F1ED}", decimalDigits: 2, countries: ["TH"] },
    TJS: { code: "TJS", name: "Tajikistani Somoni", symbol: "TJS", flag: "\u{1F1F9}\u{1F1EF}", decimalDigits: 2, countries: ["TJ"] },
    TMT: { code: "TMT", name: "Turkmenistani Manat", symbol: "TMT", flag: "\u{1F1F9}\u{1F1F2}", decimalDigits: 2, countries: ["TM"] },
    TND: { code: "TND", name: "Tunisian Dinar", symbol: "DT", flag: "\u{1F1F9}\u{1F1F3}", decimalDigits: 3, countries: ["TN"] },
    TOP: { code: "TOP", name: "Tongan Pa\u02BBanga", symbol: "T$", flag: "\u{1F1F9}\u{1F1F4}", decimalDigits: 2, countries: ["TO"] },
    TRY: { code: "TRY", name: "Turkish Lira", symbol: "\u20BA", flag: "\u{1F1F9}\u{1F1F7}", decimalDigits: 2, countries: ["TR"] },
    TTD: { code: "TTD", name: "Trinidad and Tobago Dollar", symbol: "TT$", flag: "\u{1F1F9}\u{1F1F9}", decimalDigits: 2, countries: ["TT"] },
    TWD: { code: "TWD", name: "New Taiwan Dollar", symbol: "NT$", flag: "\u{1F1F9}\u{1F1FC}", decimalDigits: 2, countries: ["TW"] },
    TZS: { code: "TZS", name: "Tanzanian Shilling", symbol: "TSh", flag: "\u{1F1F9}\u{1F1FF}", decimalDigits: 2, countries: ["TZ"] },
    UAH: { code: "UAH", name: "Ukrainian Hryvnia", symbol: "\u20B4", flag: "\u{1F1FA}\u{1F1E6}", decimalDigits: 2, countries: ["UA"] },
    UGX: { code: "UGX", name: "Ugandan Shilling", symbol: "USh", flag: "\u{1F1FA}\u{1F1EC}", decimalDigits: 0, countries: ["UG"] },
    UYU: { code: "UYU", name: "Uruguayan Peso", symbol: "$U", flag: "\u{1F1FA}\u{1F1FE}", decimalDigits: 2, countries: ["UY"] },
    UZS: { code: "UZS", name: "Uzbekistan Som", symbol: "UZS", flag: "\u{1F1FA}\u{1F1FF}", decimalDigits: 2, countries: ["UZ"] },
    VES: { code: "VES", name: "Venezuelan Bol\xEDvar", symbol: "Bs.S", flag: "\u{1F1FB}\u{1F1EA}", decimalDigits: 2, countries: ["VE"] },
    VND: { code: "VND", name: "Vietnamese Dong", symbol: "\u20AB", flag: "\u{1F1FB}\u{1F1F3}", decimalDigits: 0, countries: ["VN"] },
    VUV: { code: "VUV", name: "Vanuatu Vatu", symbol: "VT", flag: "\u{1F1FB}\u{1F1FA}", decimalDigits: 0, countries: ["VU"] },
    WST: { code: "WST", name: "Samoan Tala", symbol: "WS$", flag: "\u{1F1FC}\u{1F1F8}", decimalDigits: 2, countries: ["WS"] },
    XAF: { code: "XAF", name: "Central African CFA Franc", symbol: "FCFA", flag: "\u{1F1E8}\u{1F1F2}", decimalDigits: 0, countries: ["CM", "CF", "TD", "CG", "GQ", "GA"] },
    XCD: { code: "XCD", name: "East Caribbean Dollar", symbol: "EC$", flag: "\u{1F1E6}\u{1F1EC}", decimalDigits: 2, countries: ["AG", "DM", "GD", "KN", "LC", "VC"] },
    XOF: { code: "XOF", name: "West African CFA Franc", symbol: "CFA", flag: "\u{1F1F8}\u{1F1F3}", decimalDigits: 0, countries: ["SN", "CI", "ML", "BF", "NE", "TG", "BJ", "GW"] },
    XPF: { code: "XPF", name: "CFP Franc", symbol: "CFPF", flag: "\u{1F1F5}\u{1F1EB}", decimalDigits: 0, countries: ["PF", "NC", "WF"] },
    YER: { code: "YER", name: "Yemeni Rial", symbol: "YR", flag: "\u{1F1FE}\u{1F1EA}", decimalDigits: 2, countries: ["YE"] },
    ZAR: { code: "ZAR", name: "South African Rand", symbol: "R", flag: "\u{1F1FF}\u{1F1E6}", decimalDigits: 2, countries: ["ZA"] },
    ZMW: { code: "ZMW", name: "Zambian Kwacha", symbol: "ZK", flag: "\u{1F1FF}\u{1F1F2}", decimalDigits: 2, countries: ["ZM"] },
    ZWL: { code: "ZWL", name: "Zimbabwean Dollar", symbol: "ZWL", flag: "\u{1F1FF}\u{1F1FC}", decimalDigits: 2, countries: ["ZW"] }
  };
  var SYMBOL_MAP = {
    "$": ["USD", "CAD", "AUD", "NZD", "SGD", "HKD", "MXN", "ARS", "CLP", "COP"],
    "\u20AC": ["EUR"],
    "\xA3": ["GBP", "EGP", "GIP"],
    "\u20B9": ["INR"],
    "\xA5": ["JPY", "CNY"],
    "\uFFE5": ["JPY", "CNY"],
    "R$": ["BRL"],
    "CA$": ["CAD"],
    "A$": ["AUD"],
    "AU$": ["AUD"],
    "NZ$": ["NZD"],
    "HK$": ["HKD"],
    "S$": ["SGD"],
    "US$": ["USD"],
    "\u20A9": ["KRW"],
    "\u20BD": ["RUB"],
    "\u20BA": ["TRY"],
    "\u20AB": ["VND"],
    "\u0E3F": ["THB"],
    "\u20B1": ["PHP"],
    "\u20AA": ["ILS"],
    "kr": ["SEK", "NOK", "DKK", "ISK"],
    "K\u010D": ["CZK"],
    "z\u0142": ["PLN"],
    "Ft": ["HUF"],
    "CHF": ["CHF"],
    "RM": ["MYR"],
    "Rp": ["IDR"],
    "\u09F3": ["BDT"],
    "\u20A8": ["PKR", "LKR", "NPR"],
    "Nu.": ["BTN"],
    "\u20AD": ["LAK"],
    "\u17DB": ["KHR"],
    "\u20AE": ["MNT"],
    "\u20BE": ["GEL"],
    "\u20B8": ["KZT"],
    "GH\u20B5": ["GHS"],
    "\u20A6": ["NGN"],
    "\u20A1": ["CRC"],
    "\u20B2": ["PYG"],
    "\u20B4": ["UAH"],
    "AED": ["AED"],
    "SAR": ["SAR"],
    "QAR": ["QAR"],
    "KWD": ["KWD"],
    "BHD": ["BHD"],
    "OMR": ["OMR"],
    "ZAR": ["ZAR"]
  };
  function getCurrency(code) {
    return CURRENCIES[code.toUpperCase()] || {
      code: code.toUpperCase(),
      name: code.toUpperCase(),
      symbol: code.toUpperCase(),
      flag: "\u{1F310}",
      decimalDigits: 2,
      countries: []
    };
  }
  function formatCurrencyAmount(amount, currencyCode, options = {}) {
    const meta = getCurrency(currencyCode);
    const precision = options.precision ?? meta.decimalDigits;
    const locale = options.locale ?? "en-US";
    const isNegative = amount < 0;
    const absAmount = Math.abs(amount);
    try {
      const formattedNum = new Intl.NumberFormat(locale, {
        minimumFractionDigits: precision,
        maximumFractionDigits: precision
      }).format(absAmount);
      if (options.showSymbol !== false) {
        return isNegative ? `-${meta.symbol}${formattedNum}` : `${meta.symbol}${formattedNum}`;
      }
      return isNegative ? `-${formattedNum}` : formattedNum;
    } catch {
      const fallbackFormatted = absAmount.toFixed(precision);
      if (options.showSymbol !== false) {
        return isNegative ? `-${meta.symbol}${fallbackFormatted}` : `${meta.symbol}${fallbackFormatted}`;
      }
      return isNegative ? `-${fallbackFormatted}` : fallbackFormatted;
    }
  }

  // ../shared/dist/detector/price-parser.js
  function normalizeNumericString(rawNumber) {
    if (!rawNumber || typeof rawNumber !== "string")
      return null;
    const trimmed = rawNumber.trim();
    if (!trimmed)
      return null;
    const isNegative = trimmed.startsWith("-") || /^-|\s*-/.test(trimmed) || trimmed.startsWith("(") && trimmed.endsWith(")");
    let cleaned = trimmed.replace(/[^\d.,]/g, "");
    if (!cleaned)
      return null;
    const hasComma = cleaned.includes(",");
    const hasDot = cleaned.includes(".");
    if (hasComma && hasDot) {
      const lastCommaIndex = cleaned.lastIndexOf(",");
      const lastDotIndex = cleaned.lastIndexOf(".");
      if (lastCommaIndex > lastDotIndex) {
        const intPart = cleaned.substring(0, lastCommaIndex);
        const decPart = cleaned.substring(lastCommaIndex + 1);
        const dotGroups = intPart.split(".");
        if (dotGroups.length > 1) {
          for (let i = 1; i < dotGroups.length; i++) {
            if (dotGroups[i].length !== 3)
              return null;
          }
        }
        cleaned = intPart.replace(/\./g, "") + "." + decPart;
      } else {
        const intPart = cleaned.substring(0, lastDotIndex);
        const decPart = cleaned.substring(lastDotIndex + 1);
        const commaGroups = intPart.split(",");
        if (commaGroups.length > 1) {
          for (let i = 1; i < commaGroups.length; i++) {
            if (commaGroups[i].length !== 3 && commaGroups[i].length !== 2)
              return null;
          }
        }
        cleaned = intPart.replace(/,/g, "") + "." + decPart;
      }
    } else if (hasComma && !hasDot) {
      const parts = cleaned.split(",");
      if (parts.length === 2 && parts[1].length <= 2) {
        cleaned = parts[0] + "." + parts[1];
      } else {
        for (let i = 1; i < parts.length; i++) {
          if (parts[i].length !== 3 && parts[i].length !== 2)
            return null;
        }
        cleaned = cleaned.replace(/,/g, "");
      }
    } else if (hasDot && !hasComma) {
      const parts = cleaned.split(".");
      if (parts.length > 2) {
        for (let i = 1; i < parts.length; i++) {
          if (parts[i].length !== 3)
            return null;
        }
        cleaned = cleaned.replace(/\./g, "");
      }
    }
    const dotCount = (cleaned.match(/\./g) || []).length;
    if (dotCount > 1)
      return null;
    const parsed = parseFloat(cleaned);
    if (isNaN(parsed))
      return null;
    return isNegative ? -Math.abs(parsed) : parsed;
  }
  function resolveAmbiguousSymbol(symbol, context) {
    if (context?.pageMetaCurrency && CURRENCIES[context.pageMetaCurrency.toUpperCase()]) {
      const metaCode = context.pageMetaCurrency.toUpperCase();
      const possibleCodes = SYMBOL_MAP[symbol] || [];
      if (possibleCodes.includes(metaCode) || possibleCodes.length === 0) {
        return metaCode;
      }
    }
    const domain = (context?.domain || context?.url || "").toLowerCase();
    switch (symbol) {
      case "$":
      case "US$":
        if (domain.endsWith(".ca") || domain.includes(".ca/"))
          return "CAD";
        if (domain.endsWith(".au") || domain.includes(".com.au"))
          return "AUD";
        if (domain.endsWith(".nz") || domain.includes(".co.nz"))
          return "NZD";
        if (domain.endsWith(".sg") || domain.includes(".com.sg"))
          return "SGD";
        if (domain.endsWith(".hk") || domain.includes(".com.hk"))
          return "HKD";
        if (domain.endsWith(".mx") || domain.includes(".com.mx"))
          return "MXN";
        return "USD";
      case "CA$":
        return "CAD";
      case "A$":
      case "AU$":
        return "AUD";
      case "NZ$":
        return "NZD";
      case "S$":
        return "SGD";
      case "HK$":
        return "HKD";
      case "\xA3":
        if (domain.endsWith(".eg"))
          return "EGP";
        return "GBP";
      case "\xA5":
      case "\uFFE5":
        if (domain.endsWith(".cn") || domain.includes(".cn/") || context?.lang?.startsWith("zh")) {
          return "CNY";
        }
        return "JPY";
      case "kr":
        if (domain.endsWith(".se"))
          return "SEK";
        if (domain.endsWith(".no"))
          return "NOK";
        if (domain.endsWith(".dk"))
          return "DKK";
        if (domain.endsWith(".is"))
          return "ISK";
        return "SEK";
      case "\u20B9":
      case "Rs":
      case "Rs.":
        return "INR";
      case "\u20AC":
        return "EUR";
      case "R$":
        return "BRL";
      case "\u20A9":
        return "KRW";
      case "\u20BD":
        return "RUB";
      case "\u20BA":
        return "TRY";
      case "\u20AB":
        return "VND";
      case "\u0E3F":
        return "THB";
      case "\u20B1":
        return "PHP";
      case "\u20AA":
        return "ILS";
      case "z\u0142":
        return "PLN";
      case "K\u010D":
        return "CZK";
      default:
        const mapped = SYMBOL_MAP[symbol];
        if (mapped && mapped.length > 0) {
          return mapped[0];
        }
        if (CURRENCIES[symbol.toUpperCase()]) {
          return symbol.toUpperCase();
        }
        return "USD";
    }
  }
  var CURRENCY_SYMBOLS_REGEX = "[$\u20AC\xA3\u20B9\xA5\uFFE5\u20BD\u20A9\u20BA\u20AB\u0E3F\u20B1\u20AA]|R\\$|CA\\$|A\\$|AU\\$|NZ\\$|HK\\$|S\\$|US\\$|kr|K\u010D|z\u0142|Ft|CHF|RM|Rp|\u09F3|\u20A8|Nu\\.|GH\u20B5|\u20A6|\u20A1|\u20B2|\u20B4";
  var CURRENCY_CODES_REGEX = Object.keys(CURRENCIES).join("|");
  var NUM_PATTERN = "\\d{1,3}(?:[.,\\s]\\d{3})*(?:[.,]\\d{1,4})?|\\d+(?:[.,]\\d{1,4})?";
  var REGEX_SYMBOL_PREFIX = new RegExp(`(?<!\\w)(${CURRENCY_SYMBOLS_REGEX})\\s*(${NUM_PATTERN})(?!\\w)`, "i");
  var REGEX_SYMBOL_SUFFIX = new RegExp(`(?<!\\w)(${NUM_PATTERN})\\s*(${CURRENCY_SYMBOLS_REGEX})(?!\\w)`, "i");
  var REGEX_CODE_PREFIX = new RegExp(`(?<![a-zA-Z])(${CURRENCY_CODES_REGEX})\\s+(${NUM_PATTERN})(?!\\w)`, "i");
  var REGEX_CODE_SUFFIX = new RegExp(`(?<!\\w)(${NUM_PATTERN})\\s+(${CURRENCY_CODES_REGEX})(?![a-zA-Z])`, "i");
  function parsePriceFromText(text, context) {
    if (!text || text.length > 250)
      return null;
    const trimmed = text.trim();
    let match = trimmed.match(REGEX_CODE_PREFIX);
    if (match) {
      const code = match[1].toUpperCase();
      const amount = normalizeNumericString(match[2]);
      if (amount !== null && amount > 0) {
        return {
          rawText: match[0],
          amount,
          currencyCode: code,
          confidence: 0.98,
          detectedSymbol: CURRENCIES[code]?.symbol || code
        };
      }
    }
    match = trimmed.match(REGEX_CODE_SUFFIX);
    if (match) {
      const code = match[2].toUpperCase();
      const amount = normalizeNumericString(match[1]);
      if (amount !== null && amount > 0) {
        return {
          rawText: match[0],
          amount,
          currencyCode: code,
          confidence: 0.98,
          detectedSymbol: CURRENCIES[code]?.symbol || code
        };
      }
    }
    match = trimmed.match(REGEX_SYMBOL_PREFIX);
    if (match) {
      const symbol = match[1];
      const amount = normalizeNumericString(match[2]);
      if (amount !== null && amount > 0) {
        const resolvedCode = resolveAmbiguousSymbol(symbol, context);
        return {
          rawText: match[0],
          amount,
          currencyCode: resolvedCode,
          confidence: symbol === "$" ? 0.85 : 0.95,
          detectedSymbol: symbol
        };
      }
    }
    match = trimmed.match(REGEX_SYMBOL_SUFFIX);
    if (match) {
      const symbol = match[2];
      const amount = normalizeNumericString(match[1]);
      if (amount !== null && amount > 0) {
        const resolvedCode = resolveAmbiguousSymbol(symbol, context);
        return {
          rawText: match[0],
          amount,
          currencyCode: resolvedCode,
          confidence: 0.9,
          detectedSymbol: symbol
        };
      }
    }
    return null;
  }
  function parsePriceFromSelection(text, fallbackCurrency = "USD", context) {
    if (!text || text.length > 100)
      return null;
    const standardMatch = parsePriceFromText(text, context);
    if (standardMatch)
      return standardMatch;
    const num = normalizeNumericString(text);
    if (num !== null && num > 0) {
      const code = (context?.pageMetaCurrency || fallbackCurrency || "USD").toUpperCase();
      return {
        rawText: text.trim(),
        amount: num,
        currencyCode: code,
        confidence: 0.8,
        detectedSymbol: CURRENCIES[code]?.symbol || code
      };
    }
    return null;
  }

  // ../shared/dist/config/index.js
  var DEFAULT_PERSONAL_RATE = {
    baseCurrency: "USD",
    targetCurrency: "INR",
    rate: 87.12,
    lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
    dailyReminderEnabled: true,
    additionalRates: {
      "EUR_INR": 94.7,
      "GBP_INR": 110.5,
      "JPY_INR": 0.58,
      "CAD_INR": 63.5,
      "AUD_INR": 57.8
    },
    savedPairs: [
      {
        id: "USD_INR",
        baseCurrency: "USD",
        targetCurrency: "INR",
        rate: 87.12,
        lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
        isActive: true
      }
    ]
  };
  var DEFAULT_RATE_PROFILES = [
    {
      id: "prof_personal",
      name: "Personal Rate",
      description: "Custom rates obtained from Google for personal purchases and budgeting",
      baseCurrency: "INR",
      rates: {
        "USD_INR": 87.12,
        "EUR_INR": 94.7,
        "GBP_INR": 110.5,
        "JPY_INR": 0.58,
        "CAD_INR": 63.5,
        "AUD_INR": 57.8,
        "AED_INR": 23.75,
        "SGD_INR": 65.2
      },
      isDefault: true,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    },
    {
      id: "prof_bank",
      name: "Bank Exchange Rate",
      description: "Typical credit card and bank foreign exchange rate with 2-3% spread",
      baseCurrency: "INR",
      rates: {
        "USD_INR": 89.5,
        "EUR_INR": 97.2,
        "GBP_INR": 113.8,
        "JPY_INR": 0.6,
        "CAD_INR": 65.2,
        "AUD_INR": 59.4,
        "AED_INR": 24.4,
        "SGD_INR": 67
      },
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    },
    {
      id: "prof_business",
      name: "Business Rate",
      description: "Corporate accounting and invoice valuation rates",
      baseCurrency: "USD",
      rates: {
        "USD_EUR": 0.92,
        "USD_GBP": 0.79,
        "USD_INR": 87,
        "USD_JPY": 154,
        "USD_CAD": 1.38,
        "USD_AUD": 1.52
      },
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    },
    {
      id: "prof_travel",
      name: "Travel Rate",
      description: "Cash airport exchange and kiosk rates for holiday trips",
      baseCurrency: "INR",
      rates: {
        "USD_INR": 90,
        "EUR_INR": 98,
        "GBP_INR": 115,
        "JPY_INR": 0.62,
        "AED_INR": 25,
        "THB_INR": 2.65
      },
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    },
    {
      id: "prof_custom",
      name: "Custom Rate",
      description: "User-defined direct currency pairs and overrides",
      rates: {
        "EUR_INR": 94.7,
        "USD_INR": 87.12
      },
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }
  ];
  var DEFAULT_DUAL_RATE_CONFIG = {
    mode: "manual",
    // Default to personal manual rate engine
    activeProfileId: "prof_personal",
    profiles: DEFAULT_RATE_PROFILES,
    fallbackToAutomaticOnError: false
  };
  var APP_CONFIG = {
    appName: "HoverCurrency",
    appTagline: "Instant Hover-to-Convert Currency Ecosystem",
    websiteUrl: "https://currenceconverter.me",
    apiUrl: "http://localhost:3000/api",
    plans: {
      free: {
        name: "Free",
        price: 0,
        monthlyConversionsLimit: 29,
        features: [
          "29 successful conversions per month",
          "Personal exchange rate system (Google rate entry)",
          "Hover-to-convert engine on all websites",
          "Daily update reminders & stale rate alerts",
          "Target currency selection (160+ currencies)",
          "Usage counter & reset tracker"
        ]
      },
      pro: {
        name: "Pro",
        price: 9,
        interval: "3 months",
        intervalCount: 3,
        monthlyConversionsLimit: Infinity,
        features: [
          "Unlimited currency conversions",
          "Unlimited hover-to-convert usage",
          "Premium rate profiles (Personal, Bank, Business, Travel)",
          "Cross-device browser sync",
          "Priority 24/7 support",
          "No conversion limits"
        ]
      }
    },
    defaultPreferences: {
      defaultBaseCurrency: "USD",
      defaultTargetCurrency: "INR",
      hoverEnabled: true,
      tooltipTheme: "dark",
      precision: 2,
      autoDetectSource: true,
      excludedDomains: [
        "paypal.com",
        "chase.com",
        "bankofamerica.com",
        "wellsfargo.com"
      ],
      showRateTimestamp: true,
      rateMode: "manual",
      activeProfileId: "prof_personal"
    },
    personalRate: DEFAULT_PERSONAL_RATE,
    dualRateEngine: DEFAULT_DUAL_RATE_CONFIG,
    dodoPayments: {
      sandboxUrl: "https://test.dodopayments.com",
      productionUrl: "https://api.dodopayments.com",
      defaultProductId: "p_quarterly_pro_9"
    }
  };

  // ../shared/dist/exchange-rate/rates.js
  var MissingManualRateError = class extends Error {
    from;
    to;
    profileName;
    constructor(from, to, profileName = "Personal Rate") {
      super(`Exchange rate not available for ${from} \u2192 ${to} in "${profileName}". Please enter this rate manually from Google.`);
      this.name = "MissingManualRateError";
      this.from = from;
      this.to = to;
      this.profileName = profileName;
    }
  };
  var PersonalRateEngine = class _PersonalRateEngine {
    static instance;
    config = { ...DEFAULT_DUAL_RATE_CONFIG };
    personalRate = { ...DEFAULT_PERSONAL_RATE };
    // Built-in cached reference rates for Automatic Mode (offline / zero external API calls)
    automaticCache = {
      USD: 1,
      EUR: 0.92,
      GBP: 0.79,
      INR: 87.12,
      JPY: 154,
      CAD: 1.38,
      AUD: 1.52,
      CHF: 0.88,
      CNY: 7.24,
      AED: 3.67,
      SGD: 1.34,
      BRL: 5.75,
      MXN: 20.15,
      KRW: 1390,
      SEK: 10.9,
      NZD: 1.68
    };
    constructor() {
    }
    static getInstance() {
      if (!_PersonalRateEngine.instance) {
        _PersonalRateEngine.instance = new _PersonalRateEngine();
      }
      return _PersonalRateEngine.instance;
    }
    // Personal Rate Management
    getPersonalRate() {
      return { ...this.personalRate };
    }
    setPersonalRate(rateConfig) {
      this.personalRate = {
        ...this.personalRate,
        ...rateConfig,
        lastUpdated: rateConfig.lastUpdated || (/* @__PURE__ */ new Date()).toISOString()
      };
      return { ...this.personalRate };
    }
    isRateStale(lastUpdatedIso) {
      const ageMs = Date.now() - new Date(lastUpdatedIso).getTime();
      return ageMs >= 24 * 60 * 60 * 1e3;
    }
    getRateFreshness(lastUpdatedIso) {
      return this.isRateStale(lastUpdatedIso) ? "stale" : "fresh";
    }
    // Dual engine config
    getConfig() {
      return { ...this.config };
    }
    setMode(mode) {
      this.config.mode = mode;
    }
    getMode() {
      return this.config.mode;
    }
    setActiveProfile(profileId) {
      const exists = this.config.profiles.some((p) => p.id === profileId);
      if (exists) {
        this.config.activeProfileId = profileId;
      }
    }
    getActiveProfile() {
      const found = this.config.profiles.find((p) => p.id === this.config.activeProfileId);
      return found || this.config.profiles[0] || DEFAULT_RATE_PROFILES[0];
    }
    setProfiles(profiles) {
      this.config.profiles = profiles;
    }
    /**
     * Resolves rate using Personal Exchange Rate system:
     * 1. 1 USD = [savedRate] [targetCurrency]
     * 2. If USD -> Target: rate = savedRate
     * 3. If Target -> USD: rate = 1 / savedRate
     * 4. Additional rates from profile or personal config if explicitly configured
     * Never invents missing rates!
     */
    resolveRate(from, to, personalConfig = this.personalRate, profile) {
      const f = from.toUpperCase();
      const t = to.toUpperCase();
      const base = (personalConfig.baseCurrency || "USD").toUpperCase();
      const target = (personalConfig.targetCurrency || "INR").toUpperCase();
      const savedRate = personalConfig.rate;
      if (f === t) {
        return { rate: 1, isCustom: false, profileName: "Identical Pair" };
      }
      const prof = profile || this.getActiveProfile();
      const isSpecificProfile = prof && prof.id !== "prof_personal";
      const checkProfileRates = () => {
        if (!prof || !prof.rates)
          return null;
        const directKey = `${f}_${t}`;
        const inverseKey = `${t}_${f}`;
        if (prof.rates[directKey] !== void 0) {
          return { rate: prof.rates[directKey], isCustom: true, profileName: prof.name };
        }
        if (prof.rates[inverseKey] !== void 0 && prof.rates[inverseKey] > 0) {
          return { rate: 1 / prof.rates[inverseKey], isCustom: true, profileName: prof.name };
        }
        if (prof.baseCurrency) {
          const pb = prof.baseCurrency.toUpperCase();
          const pbToF = f === pb ? 1 : prof.rates[`${pb}_${f}`] ?? prof.rates[f] ?? (prof.rates[`${f}_${pb}`] ? 1 / prof.rates[`${f}_${pb}`] : void 0);
          const pbToT = t === pb ? 1 : prof.rates[`${pb}_${t}`] ?? prof.rates[t] ?? (prof.rates[`${t}_${pb}`] ? 1 / prof.rates[`${t}_${pb}`] : void 0);
          if (pbToF && pbToT && pbToF > 0) {
            return { rate: pbToT / pbToF, isCustom: true, profileName: prof.name };
          }
        }
        for (const key of Object.keys(prof.rates)) {
          if (key.startsWith(`${f}_`)) {
            const common = key.substring(f.length + 1);
            const matchT = prof.rates[`${t}_${common}`];
            if (matchT && matchT > 0) {
              return { rate: prof.rates[key] / matchT, isCustom: true, profileName: prof.name };
            }
          }
        }
        for (const key of Object.keys(prof.rates)) {
          if (key.endsWith(`_${f}`)) {
            const common = key.substring(0, key.length - f.length - 1);
            const matchT = prof.rates[`${common}_${t}`];
            if (matchT && matchT > 0 && prof.rates[key] > 0) {
              return { rate: matchT / prof.rates[key], isCustom: true, profileName: prof.name };
            }
          }
        }
        return null;
      };
      if (isSpecificProfile) {
        const fromProf = checkProfileRates();
        if (fromProf)
          return fromProf;
      }
      if (personalConfig.savedPairs && personalConfig.savedPairs.length > 0) {
        const directPair = personalConfig.savedPairs.find((p) => p.baseCurrency.toUpperCase() === f && p.targetCurrency.toUpperCase() === t && p.rate > 0);
        if (directPair) {
          return { rate: directPair.rate, isCustom: true, profileName: "Personal Rate" };
        }
        const inversePair = personalConfig.savedPairs.find((p) => p.baseCurrency.toUpperCase() === t && p.targetCurrency.toUpperCase() === f && p.rate > 0);
        if (inversePair) {
          return { rate: 1 / inversePair.rate, isCustom: true, profileName: "Personal Rate" };
        }
        for (const pairA of personalConfig.savedPairs) {
          const aBase = pairA.baseCurrency.toUpperCase();
          const aTarget = pairA.targetCurrency.toUpperCase();
          let fToBridge = null;
          let bridge = null;
          if (aBase === f && pairA.rate > 0) {
            bridge = aTarget;
            fToBridge = pairA.rate;
          } else if (aTarget === f && pairA.rate > 0) {
            bridge = aBase;
            fToBridge = 1 / pairA.rate;
          }
          if (bridge && fToBridge !== null) {
            for (const pairB of personalConfig.savedPairs) {
              const bBase = pairB.baseCurrency.toUpperCase();
              const bTarget = pairB.targetCurrency.toUpperCase();
              let bridgeToT = null;
              if (bBase === bridge && bTarget === t && pairB.rate > 0) {
                bridgeToT = pairB.rate;
              } else if (bTarget === bridge && bBase === t && pairB.rate > 0) {
                bridgeToT = 1 / pairB.rate;
              }
              if (bridgeToT !== null) {
                return { rate: fToBridge * bridgeToT, isCustom: true, profileName: "Personal Rate" };
              }
            }
          }
        }
      }
      if (f === base && t === target && savedRate > 0) {
        return { rate: savedRate, isCustom: true, profileName: "Personal Rate" };
      }
      if (f === target && t === base && savedRate > 0) {
        return { rate: 1 / savedRate, isCustom: true, profileName: "Personal Rate" };
      }
      if (personalConfig.additionalRates) {
        const directKey = `${f}_${t}`;
        const inverseKey = `${t}_${f}`;
        if (personalConfig.additionalRates[directKey] !== void 0) {
          return { rate: personalConfig.additionalRates[directKey], isCustom: true, profileName: "Personal Rate" };
        }
        if (personalConfig.additionalRates[inverseKey] !== void 0 && personalConfig.additionalRates[inverseKey] > 0) {
          return { rate: 1 / personalConfig.additionalRates[inverseKey], isCustom: true, profileName: "Personal Rate" };
        }
        const fToTarget = personalConfig.additionalRates[`${f}_${target}`];
        const tToTarget = personalConfig.additionalRates[`${t}_${target}`];
        if (fToTarget && tToTarget && tToTarget > 0) {
          return { rate: fToTarget / tToTarget, isCustom: true, profileName: "Personal Rate" };
        }
        const baseToF = personalConfig.additionalRates[`${base}_${f}`] ?? (f === base ? 1 : void 0);
        const baseToT = personalConfig.additionalRates[`${base}_${t}`] ?? (t === base ? 1 : t === target ? savedRate : void 0);
        if (baseToF && baseToT && baseToF > 0) {
          return { rate: baseToT / baseToF, isCustom: true, profileName: "Personal Rate" };
        }
      }
      if (!isSpecificProfile) {
        const fromProf = checkProfileRates();
        if (fromProf)
          return fromProf;
      }
      return null;
    }
    /**
     * Main Conversion Engine (No External Currency API)
     */
    async convert(amount, from, to, options = {}) {
      const fromCode = from.toUpperCase();
      const toCode = to.toUpperCase();
      const personal = options.personalRateConfig || this.personalRate;
      const profile = options.profileId ? this.config.profiles.find((p) => p.id === options.profileId) || this.getActiveProfile() : this.getActiveProfile();
      const fromMeta = getCurrency(fromCode);
      const toMeta = getCurrency(toCode);
      const fromPrecision = fromMeta.decimalDigits;
      const toPrecision = options.precision ?? toMeta.decimalDigits;
      const effectiveMode = options.mode || this.config.mode;
      if (effectiveMode === "automatic") {
        let autoRate = null;
        if (fromCode === toCode) {
          autoRate = 1;
        } else if (this.automaticCache[fromCode] && this.automaticCache[toCode]) {
          autoRate = this.automaticCache[toCode] / this.automaticCache[fromCode];
        }
        if (autoRate !== null && !isNaN(autoRate) && autoRate > 0) {
          const factor2 = Math.pow(10, toPrecision);
          const convertedAmount2 = Math.round((amount * autoRate + Number.EPSILON) * factor2) / factor2;
          return {
            from: fromCode,
            to: toCode,
            originalAmount: amount,
            convertedAmount: convertedAmount2,
            rate: autoRate,
            lastUpdated: this.config.lastAutomaticFetch || (/* @__PURE__ */ new Date()).toISOString(),
            formattedOriginal: formatCurrencyAmount(amount, fromCode, { precision: fromPrecision }),
            formattedConverted: formatCurrencyAmount(convertedAmount2, toCode, { precision: toPrecision }),
            rateMode: "automatic",
            rateFreshness: "fresh",
            rateProvider: "Standard Exchange Reference Cache",
            isCustomRate: false,
            rateProfileName: "Automatic Live Rate"
          };
        }
      }
      let rate = options.customRate || null;
      let profileName = profile.name;
      if (rate === null) {
        const resolved = this.resolveRate(fromCode, toCode, personal, profile);
        if (resolved) {
          rate = resolved.rate;
          profileName = resolved.profileName;
        }
      }
      if (rate === null || isNaN(rate) || rate <= 0) {
        throw new MissingManualRateError(fromCode, toCode, profileName);
      }
      const factor = Math.pow(10, toPrecision);
      const convertedAmount = Math.round((amount * rate + Number.EPSILON) * factor) / factor;
      const isStale = this.isRateStale(personal.lastUpdated);
      const freshness = isStale ? "stale" : "fresh";
      return {
        from: fromCode,
        to: toCode,
        originalAmount: amount,
        convertedAmount,
        rate,
        lastUpdated: personal.lastUpdated,
        formattedOriginal: formatCurrencyAmount(amount, fromCode, { precision: fromPrecision }),
        formattedConverted: formatCurrencyAmount(convertedAmount, toCode, { precision: toPrecision }),
        rateMode: "manual",
        rateFreshness: freshness,
        rateProvider: `Personal Rate: 1 ${personal.baseCurrency} = ${personal.rate} ${personal.targetCurrency}`,
        isCustomRate: true,
        rateProfileName: profileName
      };
    }
    parseBulkRatesText(text, defaultTargetCurrency = "INR") {
      const results = [];
      const lines = text.split(/\r?\n/);
      for (const rawLine of lines) {
        const line = rawLine.trim();
        if (!line || line.startsWith("#") || line.startsWith("//"))
          continue;
        if (line.includes(",")) {
          const parts = line.split(",").map((p) => p.trim());
          if (parts.length >= 3) {
            const from = parts[0].toUpperCase();
            const to = parts[1].toUpperCase();
            const rate = parseFloat(parts[2]);
            if (!isNaN(rate) && rate > 0)
              results.push({ from, to, rate });
          } else if (parts.length === 2) {
            const from = parts[0].toUpperCase();
            const rate = parseFloat(parts[1]);
            if (!isNaN(rate) && rate > 0)
              results.push({ from, to: defaultTargetCurrency.toUpperCase(), rate });
          }
          continue;
        }
        const matchEquals = line.match(/(?:1\s+)?([A-Za-z]{3})\s*(?:=|\/|:|-)\s*(\d+(?:[.,]\d+)?)\s*([A-Za-z]{3})?/i);
        if (matchEquals) {
          const from = matchEquals[1].toUpperCase();
          const rate = parseFloat(matchEquals[2].replace(",", "."));
          const to = (matchEquals[3] || defaultTargetCurrency).toUpperCase();
          if (!isNaN(rate) && rate > 0)
            results.push({ from, to, rate });
        }
      }
      return results;
    }
    async getRates() {
      return {
        base: this.personalRate.baseCurrency,
        rates: {
          [this.personalRate.baseCurrency]: 1,
          [this.personalRate.targetCurrency]: this.personalRate.rate,
          ...this.personalRate.additionalRates || {}
        },
        lastUpdated: this.personalRate.lastUpdated,
        provider: "Personal Google Rate Entry"
      };
    }
  };
  var exchangeRateService = PersonalRateEngine.getInstance();

  // src/content/detector.ts
  var PriceHoverDetector = class {
    lastTarget = null;
    recentMatches = /* @__PURE__ */ new WeakMap();
    pageContext;
    constructor() {
      this.pageContext = this.extractPageContext();
    }
    extractPageContext() {
      const domain = window.location.hostname;
      const url = window.location.href;
      const lang = document.documentElement.lang || navigator.language;
      let pageMetaCurrency;
      const metaCurrencyEl = document.querySelector('meta[property="og:price:currency"], meta[name="currency"], meta[itemprop="priceCurrency"]');
      if (metaCurrencyEl) {
        pageMetaCurrency = metaCurrencyEl.getAttribute("content") || void 0;
      }
      return {
        domain,
        url,
        lang,
        pageMetaCurrency
      };
    }
    /**
     * Evaluates if element or its text contains an identifiable price
     */
    detectPriceAtElement(element) {
      const tag = element.tagName.toLowerCase();
      if (["input", "textarea", "select", "button", "script", "style", "code"].includes(tag)) {
        return null;
      }
      if (this.recentMatches.has(element)) {
        return this.recentMatches.get(element);
      }
      const directText = element.innerText || element.textContent || "";
      if (!directText || directText.length > 200) {
        return null;
      }
      let match = parsePriceFromText(directText, this.pageContext);
      if (!match && element.parentElement) {
        const parentTag = element.parentElement.tagName.toLowerCase();
        if (!["body", "html", "main", "section", "article"].includes(parentTag)) {
          const parentText = element.parentElement.innerText || element.parentElement.textContent || "";
          if (parentText && parentText.length > 0 && parentText.length < 120) {
            match = parsePriceFromText(parentText, this.pageContext);
          }
        }
      }
      if (match) {
        this.recentMatches.set(element, match);
        return match;
      }
      return null;
    }
    /**
     * Extracts price from user-selected text, with fallback to base currency if no symbol
     */
    detectPriceFromSelection(selectedText, fallbackCurrency = "USD") {
      if (!selectedText)
        return null;
      return parsePriceFromSelection(selectedText, fallbackCurrency, this.pageContext);
    }
    getContext() {
      return this.pageContext;
    }
  };

  // src/content/tooltip.ts
  var FloatingTooltip = class {
    hostElement = null;
    shadowRoot = null;
    tooltipEl = null;
    isVisible = false;
    hideTimeout = null;
    isPersistent = false;
    isMouseOverTooltip = false;
    constructor() {
      this.init();
    }
    init() {
      if (this.hostElement)
        return;
      this.hostElement = document.createElement("div");
      this.hostElement.id = "hover-currency-extension-host";
      this.hostElement.style.cssText = `
      position: absolute;
      top: 0;
      left: 0;
      width: 0;
      height: 0;
      overflow: visible;
      z-index: 2147483647;
      pointer-events: none;
    `;
      this.shadowRoot = this.hostElement.attachShadow({ mode: "open" });
      this.injectStyles();
      this.tooltipEl = document.createElement("div");
      this.tooltipEl.className = "hc-tooltip hc-hidden";
      this.tooltipEl.addEventListener("mouseenter", () => {
        this.isMouseOverTooltip = true;
        clearTimeout(this.hideTimeout);
      });
      this.tooltipEl.addEventListener("mouseleave", () => {
        this.isMouseOverTooltip = false;
        if (!this.isPersistent) {
          this.hide(350);
        }
      });
      this.shadowRoot.appendChild(this.tooltipEl);
      document.documentElement.appendChild(this.hostElement);
    }
    injectStyles() {
      if (!this.shadowRoot)
        return;
      const style = document.createElement("style");
      style.textContent = `
      *, *::before, *::after {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      }

      .hc-tooltip {
        position: fixed;
        pointer-events: auto;
        width: 290px;
        background: rgba(18, 20, 29, 0.95);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        color: #f1f5f9;
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 12px;
        padding: 12px 14px;
        box-shadow: 0 12px 32px rgba(0, 0, 0, 0.4), 0 2px 8px rgba(0, 0, 0, 0.2);
        font-size: 13px;
        line-height: 1.4;
        transition: opacity 0.16s ease, transform 0.16s ease;
        transform: translateY(0);
        opacity: 1;
        user-select: none;
      }

      .hc-tooltip.hc-hidden {
        opacity: 0;
        pointer-events: none;
        transform: translateY(6px);
      }

      .hc-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 8px;
        padding-bottom: 6px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
      }

      .hc-brand {
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 11px;
        font-weight: 600;
        color: #94a3b8;
        letter-spacing: 0.5px;
        text-transform: uppercase;
      }

      .hc-brand-dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #38bdf8;
        box-shadow: 0 0 8px #38bdf8;
      }

      .hc-badges {
        display: flex;
        align-items: center;
        gap: 4px;
      }

      .hc-badge {
        font-size: 10px;
        font-weight: 600;
        padding: 2px 6px;
        border-radius: 9999px;
        background: rgba(56, 189, 248, 0.12);
        color: #38bdf8;
        border: 1px solid rgba(56, 189, 248, 0.25);
      }

      .hc-badge.hc-custom {
        background: rgba(245, 158, 11, 0.15);
        color: #fbbf24;
        border-color: rgba(245, 158, 11, 0.35);
      }

      .hc-badge.hc-pro {
        background: linear-gradient(135deg, rgba(234, 179, 8, 0.2), rgba(245, 158, 11, 0.2));
        color: #fbbf24;
        border-color: rgba(245, 158, 11, 0.35);
      }

      .hc-converted-row {
        margin-bottom: 6px;
      }

      .hc-converted-label {
        font-size: 10px;
        color: #94a3b8;
        margin-bottom: 2px;
        display: flex;
        justify-content: space-between;
      }

      .hc-converted-amount {
        font-size: 20px;
        font-weight: 700;
        color: #38bdf8;
        display: flex;
        align-items: baseline;
        gap: 4px;
        letter-spacing: -0.3px;
      }

      .hc-converted-currency {
        font-size: 12px;
        font-weight: 600;
        color: #94a3b8;
      }

      .hc-original-row {
        font-size: 12px;
        color: #cbd5e1;
        margin-bottom: 8px;
        display: flex;
        justify-content: space-between;
      }

      .hc-original-val {
        color: #94a3b8;
        text-decoration: line-through;
      }

      .hc-rate-info {
        font-size: 10px;
        color: #64748b;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: rgba(255, 255, 255, 0.03);
        padding: 4px 6px;
        border-radius: 6px;
      }

      .hc-rate-tag {
        display: inline-flex;
        align-items: center;
        gap: 3px;
        font-weight: 600;
      }

      .hc-rate-tag.live { color: #34d399; }
      .hc-rate-tag.custom { color: #fbbf24; }
      .hc-rate-tag.cached { color: #60a5fa; }
      .hc-rate-tag.stale { color: #f87171; }

      /* Warning Card for Missing Manual Rate */
      .hc-missing-banner {
        background: rgba(245, 158, 11, 0.1);
        border: 1px solid rgba(245, 158, 11, 0.3);
        border-radius: 8px;
        padding: 8px;
        text-align: center;
      }

      .hc-missing-title {
        font-size: 12px;
        font-weight: 700;
        color: #fbbf24;
        margin-bottom: 4px;
      }

      .hc-missing-desc {
        font-size: 11px;
        color: #cbd5e1;
        margin-bottom: 8px;
      }

      .hc-restore-btn {
        display: block;
        width: 100%;
        background: #0284c7;
        color: #ffffff;
        font-size: 11px;
        font-weight: 600;
        text-decoration: none;
        padding: 6px 10px;
        border-radius: 6px;
        border: none;
        cursor: pointer;
        transition: opacity 0.15s;
      }

      .hc-restore-btn:hover {
        opacity: 0.9;
      }

      /* Upgrade Card for Limit Reached */
      .hc-close-btn {
        background: transparent;
        border: none;
        color: #94a3b8;
        font-size: 13px;
        line-height: 1;
        cursor: pointer;
        padding: 2px 6px;
        border-radius: 4px;
        transition: all 0.15s;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .hc-close-btn:hover {
        background: rgba(255, 255, 255, 0.15);
        color: #ffffff;
      }

      .hc-upgrade-banner {
        background: linear-gradient(180deg, rgba(30, 27, 75, 0.95) 0%, rgba(15, 23, 42, 0.95) 100%);
        border: 1px solid rgba(139, 92, 246, 0.45);
        border-radius: 12px;
        padding: 12px 14px;
        text-align: center;
        box-shadow: 0 8px 24px rgba(124, 58, 237, 0.25);
      }

      .hc-upgrade-title {
        font-size: 13px;
        font-weight: 700;
        color: #ffffff;
        margin-bottom: 5px;
      }

      .hc-upgrade-desc {
        font-size: 11px;
        color: #cbd5e1;
        line-height: 1.45;
        margin-bottom: 11px;
      }

      .hc-upgrade-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        width: 100%;
        background: linear-gradient(135deg, #2563eb 0%, #7c3aed 100%);
        color: #ffffff;
        font-size: 12px;
        font-weight: 700;
        text-decoration: none;
        padding: 9px 12px;
        border-radius: 9px;
        border: none;
        cursor: pointer;
        box-shadow: 0 4px 14px rgba(37, 99, 235, 0.4);
        transition: transform 0.1s ease, box-shadow 0.15s ease;
      }

      .hc-upgrade-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 6px 18px rgba(37, 99, 235, 0.5);
      }

      .hc-upgrade-btn:active {
        transform: translateY(0);
      }

      .hc-upgrade-sub {
        font-size: 9.5px;
        color: #94a3b8;
        margin-top: 7px;
      }

      .hc-upgrade-btn:hover {
        opacity: 0.9;
      }

      .hc-actions {
        display: flex;
        gap: 6px;
        margin-top: 8px;
      }

      .hc-action-btn {
        flex: 1;
        background: rgba(255, 255, 255, 0.06);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: #cbd5e1;
        font-size: 10px;
        padding: 4px 6px;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 4px;
        transition: background 0.15s;
      }

      .hc-action-btn:hover {
        background: rgba(255, 255, 255, 0.12);
        color: #ffffff;
      }
    `;
      this.shadowRoot.appendChild(style);
    }
    show(conversion, clientX, clientY, onRestoreAuto) {
      if (!this.tooltipEl)
        return;
      clearTimeout(this.hideTimeout);
      if (conversion.error === "MISSING_MANUAL_RATE") {
        this.isPersistent = false;
        this.tooltipEl.innerHTML = `
        <div class="hc-header">
          <div class="hc-brand">
            <span class="hc-brand-dot" style="background:#fbbf24;box-shadow:0 0 8px #fbbf24;"></span>
            Manual Rate Required
          </div>
          <span class="hc-badge hc-custom">Custom Rate</span>
        </div>
        <div class="hc-missing-banner">
          <div class="hc-missing-title">Rate Not Set (${conversion.from} \u2192 ${conversion.to})</div>
          <div class="hc-missing-desc">
            No custom rate found in profile "${conversion.profileName || "Active"}".
          </div>
          <button class="hc-restore-btn" id="hc-btn-restore-auto">Restore Automatic Rates</button>
        </div>
      `;
        const restoreBtn = this.tooltipEl.querySelector("#hc-btn-restore-auto");
        restoreBtn?.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          chrome.runtime.sendMessage({ type: "RESTORE_AUTOMATIC" }, () => {
            if (onRestoreAuto)
              onRestoreAuto();
            this.immediateHide();
          });
        });
      } else if (conversion.error === "LIMIT_REACHED" || conversion.usage?.isLimitReached) {
        this.isPersistent = true;
        this.tooltipEl.innerHTML = `
        <div class="hc-header">
          <div class="hc-brand">
            <span class="hc-brand-dot" style="background:#ef4444;box-shadow:0 0 8px #ef4444;"></span>
            HoverCurrency
          </div>
          <div style="display:flex;align-items:center;gap:6px;">
            <span class="hc-badge" style="background:rgba(239,68,68,0.18);color:#f87171;border-color:rgba(239,68,68,0.35);font-weight:700;">Free Limit 29/29</span>
            <button class="hc-close-btn" id="hc-btn-close-upgrade" title="Dismiss" aria-label="Dismiss">\u2715</button>
          </div>
        </div>
        <div class="hc-upgrade-banner">
          <div class="hc-upgrade-title">Monthly Free Limit Reached</div>
          <div class="hc-upgrade-desc">
            You've completed all <strong>29 free conversions</strong> this month. Upgrade to Pro for unlimited conversions worldwide!
          </div>
          <button class="hc-upgrade-btn" id="hc-btn-upgrade">
            <span>\u{1F451} Upgrade to Pro \u2013 $9 / 3 mos</span>
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M5 12h14m-7-7 7 7-7 7"/>
            </svg>
          </button>
          <div style="margin-top:6px;text-align:center;">
            <a href="#" id="hc-btn-sync-plan" style="color:#38bdf8;font-size:11px;text-decoration:underline;cursor:pointer;">Already upgraded? Click to refresh Pro status</a>
          </div>
          <div class="hc-upgrade-sub">Cancel anytime \u2022 Secure checkout via Dodo Payments</div>
        </div>
      `;
        const upgradeBtn = this.tooltipEl.querySelector("#hc-btn-upgrade");
        upgradeBtn?.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          window.open(`${APP_CONFIG.websiteUrl}/pricing`, "_blank");
          this.immediateHide();
        });
        const syncBtn = this.tooltipEl.querySelector("#hc-btn-sync-plan");
        syncBtn?.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          chrome.runtime?.sendMessage?.({ type: "SYNC_USER_PLAN", data: { plan: "pro" } }, () => {
            this.immediateHide();
          });
        });
        const closeBtn = this.tooltipEl.querySelector("#hc-btn-close-upgrade");
        closeBtn?.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          this.immediateHide();
        });
      } else {
        this.isPersistent = false;
        const isManual = conversion.rateMode === "manual" || conversion.isCustomRate;
        const isPro = conversion.usage?.plan === "pro";
        const planBadgeText = isPro ? "\u2728 Pro" : `Free ${conversion.usage?.count || 1}/29`;
        const planBadgeClass = isPro ? "hc-badge hc-pro" : "hc-badge";
        const customBadge = isManual ? `<span class="hc-badge hc-custom" title="Profile: ${conversion.rateProfileName || "Custom"}">\u{1F3F7}\uFE0F Custom Rate</span>` : "";
        let freshnessText = "\u26A1 Live Rate";
        let freshnessClass = "live";
        if (conversion.rateFreshness === "stale") {
          freshnessText = "\u26A0\uFE0F Stale (>24h)";
          freshnessClass = "stale";
        } else if (conversion.rateFreshness === "fresh") {
          freshnessText = "\u{1F7E2} Fresh Rate";
          freshnessClass = "live";
        } else if (isManual) {
          freshnessText = `\u{1F3F7}\uFE0F ${conversion.rateProfileName || "Personal Rate"}`;
          freshnessClass = "custom";
        } else if (conversion.rateFreshness === "cached") {
          freshnessText = "\u{1F552} Cached Rate";
          freshnessClass = "cached";
        }
        this.tooltipEl.innerHTML = `
        <div class="hc-header">
          <div class="hc-brand">
            <span class="hc-brand-dot" style="${isManual ? "background:#fbbf24;box-shadow:0 0 8px #fbbf24;" : ""}"></span>
            HoverCurrency
          </div>
          <div class="hc-badges">
            ${customBadge}
            <span class="${planBadgeClass}">${planBadgeText}</span>
          </div>
        </div>
        <div class="hc-converted-row">
          <div class="hc-converted-label">
            <span>Converted Amount</span>
            ${isManual ? '<span style="color:#fbbf24;">Manual Mode</span>' : '<span style="color:#38bdf8;">Auto Mode</span>'}
          </div>
          <div class="hc-converted-amount" style="${isManual ? "color:#fbbf24;" : ""}">
            <span>\u2248 ${conversion.formattedConverted}</span>
            <span class="hc-converted-currency">${conversion.to}</span>
          </div>
        </div>
        <div class="hc-original-row">
          <span>Original: ${conversion.formattedOriginal} ${conversion.from}</span>
          <span>1 ${conversion.from} = ${conversion.rate?.toFixed(4)} ${conversion.to}</span>
        </div>
        <div class="hc-rate-info">
          <span>Updated: ${new Date(conversion.lastUpdated || Date.now()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
          <span class="hc-rate-tag ${freshnessClass}">${freshnessText}</span>
        </div>
        <div class="hc-actions">
          <button class="hc-action-btn" id="hc-copy-btn">\u{1F4CB} Copy</button>
          <button class="hc-action-btn" id="hc-settings-btn">\u2699\uFE0F Rates & Options</button>
        </div>
      `;
        const copyBtn = this.tooltipEl.querySelector("#hc-copy-btn");
        copyBtn?.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          navigator.clipboard.writeText(conversion.formattedConverted || "");
          if (copyBtn)
            copyBtn.textContent = "\u2713 Copied!";
          setTimeout(() => {
            if (copyBtn)
              copyBtn.textContent = "\u{1F4CB} Copy";
          }, 1500);
        });
        const settingsBtn = this.tooltipEl.querySelector("#hc-settings-btn");
        settingsBtn?.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          chrome.runtime.sendMessage({ type: "OPEN_OPTIONS" }, () => {
            window.open("http://localhost:5173/dashboard?tab=rates", "_blank");
          });
        });
      }
      const tooltipWidth = 290;
      const tooltipHeight = 175;
      const margin = 14;
      let posX = clientX + 12;
      let posY = clientY + 16;
      if (posX + tooltipWidth > window.innerWidth - margin) {
        posX = clientX - tooltipWidth - 12;
      }
      if (posX < margin) {
        posX = margin;
      }
      if (posY + tooltipHeight > window.innerHeight - margin) {
        posY = clientY - tooltipHeight - 12;
      }
      if (posY < margin) {
        posY = margin;
      }
      this.tooltipEl.style.left = `${posX}px`;
      this.tooltipEl.style.top = `${posY}px`;
      this.tooltipEl.classList.remove("hc-hidden");
      this.isVisible = true;
    }
    hide(delayMs = 350) {
      if (!this.isVisible)
        return;
      if (this.isPersistent)
        return;
      if (this.isMouseOverTooltip)
        return;
      clearTimeout(this.hideTimeout);
      this.hideTimeout = setTimeout(() => {
        if (this.isPersistent || this.isMouseOverTooltip)
          return;
        this.tooltipEl?.classList.add("hc-hidden");
        this.isVisible = false;
      }, delayMs);
    }
    immediateHide() {
      clearTimeout(this.hideTimeout);
      this.isPersistent = false;
      this.isMouseOverTooltip = false;
      this.tooltipEl?.classList.add("hc-hidden");
      this.isVisible = false;
    }
    getIsPersistent() {
      return this.isPersistent;
    }
    getIsVisible() {
      return this.isVisible;
    }
    getHostElement() {
      return this.hostElement;
    }
  };

  // src/content/index.ts
  (function() {
    if (!chrome.runtime?.id)
      return;
    let detector = new PriceHoverDetector();
    let tooltip = new FloatingTooltip();
    let preferences = { ...APP_CONFIG.defaultPreferences };
    let personalRate = null;
    let hoverTimer = null;
    let activeElement = null;
    try {
      chrome.storage?.sync?.get(["preferences", "personalRate"], (data) => {
        if (chrome.runtime?.lastError)
          return;
        if (data?.preferences)
          preferences = data.preferences;
        if (data?.personalRate)
          personalRate = data.personalRate;
      });
    } catch {
      return;
    }
    try {
      chrome.storage?.onChanged?.addListener((changes, area) => {
        if (!chrome.runtime?.id)
          return;
        if (area === "sync") {
          if (changes.preferences) {
            preferences = changes.preferences.newValue;
          }
          if (changes.personalRate) {
            personalRate = changes.personalRate.newValue;
          }
        }
      });
    } catch {
    }
    function isCurrentDomainExcluded() {
      const currentHost = window.location.hostname.toLowerCase();
      if (currentHost.includes("currenceconverter.me") || currentHost.includes("currencyconverter.me") || currentHost.includes("localhost")) {
        return true;
      }
      return (preferences.excludedDomains || []).some(
        (excluded) => currentHost.includes(excluded.toLowerCase())
      );
    }
    function setupWebsiteSync() {
      const currentHost = window.location.hostname.toLowerCase();
      if (!currentHost.includes("currenceconverter.me") && !currentHost.includes("currencyconverter.me") && !currentHost.includes("localhost")) {
        return;
      }
      const checkAndSyncPlan = (planCandidate) => {
        const plan = planCandidate || document.documentElement.getAttribute("data-hc-plan") || localStorage.getItem("hc_plan");
        if (plan && chrome.runtime?.id) {
          chrome.runtime.sendMessage({
            type: "SYNC_USER_PLAN",
            data: { plan }
          }, (res) => {
            if (res?.success) {
              console.log("[HoverCurrency Extension] Auto-synced user plan from website:", plan);
            }
          });
        }
      };
      setTimeout(checkAndSyncPlan, 400);
      setTimeout(checkAndSyncPlan, 1500);
      document.addEventListener("HOVERCURRENCY_EXTENSION_SYNC", (e) => {
        if (e.detail?.plan) {
          checkAndSyncPlan(e.detail.plan);
        }
      });
      window.addEventListener("message", (e) => {
        if (e.data?.type === "HOVERCURRENCY_EXTENSION_SYNC" && e.data?.plan) {
          checkAndSyncPlan(e.data.plan);
        }
      });
      try {
        chrome.runtime?.onMessage?.addListener((request, _sender, sendResponse) => {
          if (request?.type === "REQUEST_PLAN_SYNC") {
            const plan = document.documentElement.getAttribute("data-hc-plan") || localStorage.getItem("hc_plan") || "pro";
            sendResponse({ plan });
          }
        });
      } catch {
      }
    }
    setupWebsiteSync();
    document.addEventListener(
      "mouseover",
      (e) => {
        if (!preferences.hoverEnabled || isCurrentDomainExcluded()) {
          return;
        }
        const target = e.target;
        if (!target || target === activeElement)
          return;
        clearTimeout(hoverTimer);
        hoverTimer = setTimeout(() => {
          if (!chrome.runtime?.id)
            return;
          activeElement = target;
          const match = detector.detectPriceAtElement(target);
          if (match) {
            const activeBase = personalRate?.baseCurrency || preferences.defaultBaseCurrency || "USD";
            const activeTarget = personalRate?.targetCurrency || preferences.defaultTargetCurrency || "INR";
            let targetCurrency = activeTarget;
            if (match.currencyCode === activeTarget) {
              targetCurrency = activeBase;
            }
            if (match.currencyCode === targetCurrency) {
              return;
            }
            chrome.runtime.sendMessage(
              {
                type: "CONVERT_PRICE",
                data: {
                  from: match.currencyCode,
                  to: targetCurrency,
                  amount: match.amount,
                  sourceUrl: window.location.href
                }
              },
              (conversionResponse) => {
                if (chrome.runtime.lastError) {
                  console.warn("[HoverCurrency] Runtime error:", chrome.runtime.lastError.message);
                  return;
                }
                if (conversionResponse && activeElement === target) {
                  tooltip.show(conversionResponse, e.clientX, e.clientY);
                }
              }
            );
          } else {
            tooltip.hide(100);
          }
        }, 100);
      },
      { passive: true }
    );
    document.addEventListener("mouseup", (e) => {
      if (!preferences.hoverEnabled || isCurrentDomainExcluded()) {
        return;
      }
      setTimeout(() => {
        const host = tooltip.getHostElement();
        if (host && e.composedPath().includes(host)) {
          return;
        }
        const selection = window.getSelection();
        const selectedText = selection?.toString()?.trim();
        if (!selection || !selectedText || selectedText.length > 50) {
          return;
        }
        if (!/\d/.test(selectedText)) {
          return;
        }
        const activeBase = personalRate?.baseCurrency || preferences.defaultBaseCurrency || "USD";
        const activeTarget = personalRate?.targetCurrency || preferences.defaultTargetCurrency || "INR";
        const match = detector.detectPriceFromSelection(selectedText, activeBase);
        if (!match)
          return;
        let targetCurrency = activeTarget;
        if (match.currencyCode === activeTarget) {
          targetCurrency = activeBase;
        }
        let posX = e.clientX;
        let posY = e.clientY;
        try {
          if (selection.rangeCount > 0) {
            const rect = selection.getRangeAt(0).getBoundingClientRect();
            if (rect.width > 0 && rect.height > 0) {
              posX = rect.left + rect.width / 2;
              posY = rect.top;
            }
          }
        } catch {
        }
        chrome.runtime.sendMessage(
          {
            type: "CONVERT_PRICE",
            data: {
              from: match.currencyCode,
              to: targetCurrency,
              amount: match.amount,
              sourceUrl: window.location.href
            }
          },
          (conversionResponse) => {
            if (chrome.runtime.lastError)
              return;
            if (conversionResponse) {
              tooltip.show(conversionResponse, posX, posY);
            }
          }
        );
      }, 30);
    });
    document.addEventListener(
      "mouseout",
      (e) => {
        if (tooltip.getIsPersistent()) {
          return;
        }
        const related = e.relatedTarget;
        if (!related || !activeElement?.contains(related)) {
          clearTimeout(hoverTimer);
          activeElement = null;
          tooltip.hide(400);
        }
      },
      { passive: true }
    );
    window.addEventListener(
      "scroll",
      () => {
        if (tooltip.getIsPersistent()) {
          return;
        }
        tooltip.immediateHide();
        clearTimeout(hoverTimer);
        activeElement = null;
      },
      { passive: true }
    );
    document.addEventListener(
      "click",
      (e) => {
        if (tooltip.getIsVisible() && tooltip.getIsPersistent()) {
          const path = e.composedPath();
          const host = tooltip.getHostElement();
          if (host && !path.includes(host)) {
            tooltip.immediateHide();
            activeElement = null;
          }
        }
      },
      { passive: true }
    );
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && tooltip.getIsVisible()) {
        tooltip.immediateHide();
        activeElement = null;
      }
    });
  })();
})();
//# sourceMappingURL=content.js.map
