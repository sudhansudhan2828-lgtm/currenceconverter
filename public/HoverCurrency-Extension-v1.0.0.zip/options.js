// ../shared/dist/currencies/index.js
var CURRENCIES = {
  USD: { code: "USD", name: "US Dollar", symbol: "$", flag: "\u{1F1FA}\u{1F1F8}", decimalDigits: 2, countries: ["US"] },
  EUR: { code: "EUR", name: "Euro", symbol: "\u20AC", flag: "\u{1F1EA}\u{1F1FA}", decimalDigits: 2, countries: ["DE", "FR", "IT", "ES", "NL", "BE", "AT", "IE", "FI", "PT", "GR"] },
  GBP: { code: "GBP", name: "British Pound", symbol: "\xA3", flag: "\u{1F1EC}\u{1F1E7}", decimalDigits: 2, countries: ["GB"] },
  INR: { code: "INR", name: "Indian Rupee", symbol: "\u20B9", flag: "\u{1F1EE}\u{1F1F3}", decimalDigits: 2, countries: ["IN"] },
  JPY: { code: "JPY", name: "Japanese Yen", symbol: "\xA5", nativeSymbol: "\uFFE5", flag: "\u{1F1EF}\u{1F1F5}", decimalDigits: 0, countries: ["JP"] },
  CAD: { code: "CAD", name: "Canadian Dollar", symbol: "CA$", flag: "\u{1F1E8}\u{1F1E6}", decimalDigits: 2, countries: ["CA"] },
  AUD: { code: "AUD", name: "Australian Dollar", symbol: "A$", flag: "\u{1F1E6}\u{1F1FA}", decimalDigits: 2, countries: ["AU"] },
  CHF: { code: "CHF", name: "Swiss Franc", symbol: "CHF", flag: "\u{1F1E8}\u{1F1ED}", decimalDigits: 2, countries: ["CH", "LI"] },
  CNY: { code: "CNY", name: "Chinese Yuan", symbol: "CN\xA5", nativeSymbol: "\xA5", flag: "\u{1F1E8}\u{1F1F3}", decimalDigits: 2, countries: ["CN"] },
  AED: { code: "AED", name: "UAE Dirham", symbol: "AED", flag: "\u{1F1E6}\u{1F1EA}", decimalDigits: 2, countries: ["AE"] },
  AFN: { code: "AFN", name: "Afghan Afghani", symbol: "Af", flag: "\u{1F1E6}\u{1F1EB}", decimalDigits: 2, countries: ["AF"] },
  ALL: { code: "ALL", name: "Albanian Lek", symbol: "ALL", flag: "\u{1F1E6}\u{1F1F1}", decimalDigits: 2, countries: ["AL"] },
  AMD: { code: "AMD", name: "Armenian Dram", symbol: "AMD", flag: "\u{1F1E6}\u{1F1F2}", decimalDigits: 2, countries: ["AM"] },
  ANG: { code: "ANG", name: "NL Antillean Guilder", symbol: "ANG", flag: "\u{1F1E8}\u{1F1FC}", decimalDigits: 2, countries: ["CW", "SX"] },
  AOA: { code: "AOA", name: "Angolan Kwanza", symbol: "AOA", flag: "\u{1F1E6}\u{1F1F4}", decimalDigits: 2, countries: ["AO"] },
  ARS: { code: "ARS", name: "Argentine Peso", symbol: "AR$", flag: "\u{1F1E6}\u{1F1F7}", decimalDigits: 2, countries: ["AR"] },
  AZN: { code: "AZN", name: "Azerbaijani Manat", symbol: "man.", flag: "\u{1F1E6}\u{1F1FF}", decimalDigits: 2, countries: ["AZ"] },
  BAM: { code: "BAM", name: "Bosnia-Herzegovina Mark", symbol: "KM", flag: "\u{1F1E7}\u{1F1E6}", decimalDigits: 2, countries: ["BA"] },
  BBD: { code: "BBD", name: "Barbados Dollar", symbol: "BBD", flag: "\u{1F1E7}\u{1F1E7}", decimalDigits: 2, countries: ["BB"] },
  BDT: { code: "BDT", name: "Bangladeshi Taka", symbol: "\u09F3", flag: "\u{1F1E7}\u{1F1E9}", decimalDigits: 2, countries: ["BD"] },
  BGN: { code: "BGN", name: "Bulgarian Lev", symbol: "BGN", flag: "\u{1F1E7}\u{1F1EC}", decimalDigits: 2, countries: ["BG"] },
  BHD: { code: "BHD", name: "Bahraini Dinar", symbol: "BD", flag: "\u{1F1E7}\u{1F1ED}", decimalDigits: 3, countries: ["BH"] },
  BIF: { code: "BIF", name: "Burundian Franc", symbol: "FBu", flag: "\u{1F1E7}\u{1F1EE}", decimalDigits: 0, countries: ["BI"] },
  BMD: { code: "BMD", name: "Bermudian Dollar", symbol: "BMD", flag: "\u{1F1E7}\u{1F1F2}", decimalDigits: 2, countries: ["BM"] },
  BND: { code: "BND", name: "Brunei Dollar", symbol: "BN$", flag: "\u{1F1E7}\u{1F1F3}", decimalDigits: 2, countries: ["BN"] },
  BOB: { code: "BOB", name: "Bolivian Boliviano", symbol: "Bs", flag: "\u{1F1E7}\u{1F1F4}", decimalDigits: 2, countries: ["BO"] },
  BRL: { code: "BRL", name: "Brazilian Real", symbol: "R$", flag: "\u{1F1E7}\u{1F1F7}", decimalDigits: 2, countries: ["BR"] },
  BSD: { code: "BSD", name: "Bahamian Dollar", symbol: "BSD", flag: "\u{1F1E7}\u{1F1F8}", decimalDigits: 2, countries: ["BS"] },
  BTN: { code: "BTN", name: "Bhutanese Ngultrum", symbol: "Nu.", flag: "\u{1F1E7}\u{1F1F9}", decimalDigits: 2, countries: ["BT"] },
  BWP: { code: "BWP", name: "Botswana Pula", symbol: "BWP", flag: "\u{1F1E7}\u{1F1FC}", decimalDigits: 2, countries: ["BW"] },
  BYN: { code: "BYN", name: "Belarusian Ruble", symbol: "Br", flag: "\u{1F1E7}\u{1F1FE}", decimalDigits: 2, countries: ["BY"] },
  BZD: { code: "BZD", name: "Belize Dollar", symbol: "BZ$", flag: "\u{1F1E7}\u{1F1FF}", decimalDigits: 2, countries: ["BZ"] },
  CDF: { code: "CDF", name: "Congolese Franc", symbol: "CDF", flag: "\u{1F1E8}\u{1F1E9}", decimalDigits: 2, countries: ["CD"] },
  CLP: { code: "CLP", name: "Chilean Peso", symbol: "CL$", flag: "\u{1F1E8}\u{1F1F1}", decimalDigits: 0, countries: ["CL"] },
  COP: { code: "COP", name: "Colombian Peso", symbol: "CO$", flag: "\u{1F1E8}\u{1F1F4}", decimalDigits: 2, countries: ["CO"] },
  CRC: { code: "CRC", name: "Costa Rican Col\xF3n", symbol: "\u20A1", flag: "\u{1F1E8}\u{1F1F7}", decimalDigits: 2, countries: ["CR"] },
  CUP: { code: "CUP", name: "Cuban Peso", symbol: "CUP", flag: "\u{1F1E8}\u{1F1FA}", decimalDigits: 2, countries: ["CU"] },
  CVE: { code: "CVE", name: "Cape Verdean Escudo", symbol: "CV$", flag: "\u{1F1E8}\u{1F1FB}", decimalDigits: 2, countries: ["CV"] },
  CZK: { code: "CZK", name: "Czech Koruna", symbol: "K\u010D", flag: "\u{1F1E8}\u{1F1FF}", decimalDigits: 2, countries: ["CZ"] },
  DJF: { code: "DJF", name: "Djiboutian Franc", symbol: "Fdj", flag: "\u{1F1E9}\u{1F1EF}", decimalDigits: 0, countries: ["DJ"] },
  DKK: { code: "DKK", name: "Danish Krone", symbol: "kr", flag: "\u{1F1E9}\u{1F1F0}", decimalDigits: 2, countries: ["DK", "GL", "FO"] },
  DOP: { code: "DOP", name: "Dominican Peso", symbol: "RD$", flag: "\u{1F1E9}\u{1F1F4}", decimalDigits: 2, countries: ["DO"] },
  DZD: { code: "DZD", name: "Algerian Dinar", symbol: "DA", flag: "\u{1F1E9}\u{1F1FF}", decimalDigits: 2, countries: ["DZ"] },
  EGP: { code: "EGP", name: "Egyptian Pound", symbol: "EGP", flag: "\u{1F1EA}\u{1F1EC}", decimalDigits: 2, countries: ["EG"] },
  ERN: { code: "ERN", name: "Eritrean Nakfa", symbol: "Nfk", flag: "\u{1F1EA}\u{1F1F7}", decimalDigits: 2, countries: ["ER"] },
  ETB: { code: "ETB", name: "Ethiopian Birr", symbol: "Br", flag: "\u{1F1EA}\u{1F1F9}", decimalDigits: 2, countries: ["ET"] },
  FJD: { code: "FJD", name: "Fijian Dollar", symbol: "FJ$", flag: "\u{1F1EB}\u{1F1EF}", decimalDigits: 2, countries: ["FJ"] },
  FKP: { code: "FKP", name: "Falkland Islands Pound", symbol: "FK\xA3", flag: "\u{1F1EB}\u{1F1F0}", decimalDigits: 2, countries: ["FK"] },
  GEL: { code: "GEL", name: "Georgian Lari", symbol: "\u20BE", flag: "\u{1F1EC}\u{1F1EA}", decimalDigits: 2, countries: ["GE"] },
  GHS: { code: "GHS", name: "Ghanaian Cedi", symbol: "GH\u20B5", flag: "\u{1F1EC}\u{1F1ED}", decimalDigits: 2, countries: ["GH"] },
  GIP: { code: "GIP", name: "Gibraltar Pound", symbol: "\xA3", flag: "\u{1F1EC}\u{1F1EE}", decimalDigits: 2, countries: ["GI"] },
  GMD: { code: "GMD", name: "Gambian Dalasi", symbol: "D", flag: "\u{1F1EC}\u{1F1F2}", decimalDigits: 2, countries: ["GM"] },
  GNF: { code: "GNF", name: "Guinean Franc", symbol: "FG", flag: "\u{1F1EC}\u{1F1F3}", decimalDigits: 0, countries: ["GN"] },
  GTQ: { code: "GTQ", name: "Guatemalan Quetzal", symbol: "Q", flag: "\u{1F1EC}\u{1F1F9}", decimalDigits: 2, countries: ["GT"] },
  GYD: { code: "GYD", name: "Guyanaese Dollar", symbol: "GY$", flag: "\u{1F1EC}\u{1F1FE}", decimalDigits: 2, countries: ["GY"] },
  HKD: { code: "HKD", name: "Hong Kong Dollar", symbol: "HK$", flag: "\u{1F1ED}\u{1F1F0}", decimalDigits: 2, countries: ["HK"] },
  HNL: { code: "HNL", name: "Honduran Lempira", symbol: "L", flag: "\u{1F1ED}\u{1F1F3}", decimalDigits: 2, countries: ["HN"] },
  HRK: { code: "HRK", name: "Croatian Kuna", symbol: "kn", flag: "\u{1F1ED}\u{1F1F7}", decimalDigits: 2, countries: ["HR"] },
  HTG: { code: "HTG", name: "Haitian Gourde", symbol: "G", flag: "\u{1F1ED}\u{1F1F9}", decimalDigits: 2, countries: ["HT"] },
  HUF: { code: "HUF", name: "Hungarian Forint", symbol: "Ft", flag: "\u{1F1ED}\u{1F1FA}", decimalDigits: 0, countries: ["HU"] },
  IDR: { code: "IDR", name: "Indonesian Rupiah", symbol: "Rp", flag: "\u{1F1EE}\u{1F1E9}", decimalDigits: 0, countries: ["ID"] },
  ILS: { code: "ILS", name: "Israeli New Shekel", symbol: "\u20AA", flag: "\u{1F1EE}\u{1F1F1}", decimalDigits: 2, countries: ["IL"] },
  IQD: { code: "IQD", name: "Iraqi Dinar", symbol: "IQD", flag: "\u{1F1EE}\u{1F1F6}", decimalDigits: 3, countries: ["IQ"] },
  IRR: { code: "IRR", name: "Iranian Rial", symbol: "IRR", flag: "\u{1F1EE}\u{1F1F7}", decimalDigits: 0, countries: ["IR"] },
  ISK: { code: "ISK", name: "Icelandic Kr\xF3na", symbol: "kr", flag: "\u{1F1EE}\u{1F1F8}", decimalDigits: 0, countries: ["IS"] },
  JMD: { code: "JMD", name: "Jamaican Dollar", symbol: "J$", flag: "\u{1F1EF}\u{1F1F2}", decimalDigits: 2, countries: ["JM"] },
  JOD: { code: "JOD", name: "Jordanian Dinar", symbol: "JD", flag: "\u{1F1EF}\u{1F1F4}", decimalDigits: 3, countries: ["JO"] },
  KES: { code: "KES", name: "Kenyan Shilling", symbol: "KSh", flag: "\u{1F1F0}\u{1F1EA}", decimalDigits: 2, countries: ["KE"] },
  KGS: { code: "KGS", name: "Kyrgystani Som", symbol: "KGS", flag: "\u{1F1F0}\u{1F1EC}", decimalDigits: 2, countries: ["KG"] },
  KHR: { code: "KHR", name: "Cambodian Riel", symbol: "\u17DB", flag: "\u{1F1F0}\u{1F1ED}", decimalDigits: 2, countries: ["KH"] },
  KMF: { code: "KMF", name: "Comorian Franc", symbol: "CF", flag: "\u{1F1F0}\u{1F1F2}", decimalDigits: 0, countries: ["KM"] },
  KRW: { code: "KRW", name: "South Korean Won", symbol: "\u20A9", flag: "\u{1F1F0}\u{1F1F7}", decimalDigits: 0, countries: ["KR"] },
  KWD: { code: "KWD", name: "Kuwaiti Dinar", symbol: "KD", flag: "\u{1F1F0}\u{1F1FC}", decimalDigits: 3, countries: ["KW"] },
  KYD: { code: "KYD", name: "Cayman Islands Dollar", symbol: "CI$", flag: "\u{1F1F0}\u{1F1FE}", decimalDigits: 2, countries: ["KY"] },
  KZT: { code: "KZT", name: "Kazakhstani Tenge", symbol: "\u20B8", flag: "\u{1F1F0}\u{1F1FF}", decimalDigits: 2, countries: ["KZ"] },
  LAK: { code: "LAK", name: "Laotian Kip", symbol: "\u20AD", flag: "\u{1F1F1}\u{1F1E6}", decimalDigits: 0, countries: ["LA"] },
  LBP: { code: "LBP", name: "Lebanese Pound", symbol: "LB\xA3", flag: "\u{1F1F1}\u{1F1E7}", decimalDigits: 0, countries: ["LB"] },
  LKR: { code: "LKR", name: "Sri Lankan Rupee", symbol: "SLRs", flag: "\u{1F1F1}\u{1F1F0}", decimalDigits: 2, countries: ["LK"] },
  LRD: { code: "LRD", name: "Liberian Dollar", symbol: "L$", flag: "\u{1F1F1}\u{1F1F7}", decimalDigits: 2, countries: ["LR"] },
  LSL: { code: "LSL", name: "Lesotho Loti", symbol: "LSL", flag: "\u{1F1F1}\u{1F1F8}", decimalDigits: 2, countries: ["LS"] },
  LYD: { code: "LYD", name: "Libyan Dinar", symbol: "LD", flag: "\u{1F1F1}\u{1F1FE}", decimalDigits: 3, countries: ["LY"] },
  MAD: { code: "MAD", name: "Moroccan Dirham", symbol: "MAD", flag: "\u{1F1F2}\u{1F1E6}", decimalDigits: 2, countries: ["MA", "EH"] },
  MDL: { code: "MDL", name: "Moldovan Leu", symbol: "MDL", flag: "\u{1F1F2}\u{1F1E9}", decimalDigits: 2, countries: ["MD"] },
  MGA: { code: "MGA", name: "Malagasy Ariary", symbol: "MGA", flag: "\u{1F1F2}\u{1F1EC}", decimalDigits: 0, countries: ["MG"] },
  MKD: { code: "MKD", name: "Macedonian Denar", symbol: "MKD", flag: "\u{1F1F2}\u{1F1F0}", decimalDigits: 2, countries: ["MK"] },
  MMK: { code: "MMK", name: "Myanma Kyat", symbol: "MMK", flag: "\u{1F1F2}\u{1F1F2}", decimalDigits: 0, countries: ["MM"] },
  MNT: { code: "MNT", name: "Mongolian Tugrik", symbol: "\u20AE", flag: "\u{1F1F2}\u{1F1F3}", decimalDigits: 2, countries: ["MN"] },
  MOP: { code: "MOP", name: "Macanese Pataca", symbol: "MOP$", flag: "\u{1F1F2}\u{1F1F4}", decimalDigits: 2, countries: ["MO"] },
  MRU: { code: "MRU", name: "Mauritanian Ouguiya", symbol: "MRU", flag: "\u{1F1F2}\u{1F1F7}", decimalDigits: 2, countries: ["MR"] },
  MUR: { code: "MUR", name: "Mauritian Rupee", symbol: "MURs", flag: "\u{1F1F2}\u{1F1FA}", decimalDigits: 2, countries: ["MU"] },
  MVR: { code: "MVR", name: "Maldivian Rufiyaa", symbol: "Rf", flag: "\u{1F1F2}\u{1F1FB}", decimalDigits: 2, countries: ["MV"] },
  MWK: { code: "MWK", name: "Malawian Kwacha", symbol: "MK", flag: "\u{1F1F2}\u{1F1FC}", decimalDigits: 2, countries: ["MW"] },
  MXN: { code: "MXN", name: "Mexican Peso", symbol: "MX$", flag: "\u{1F1F2}\u{1F1FD}", decimalDigits: 2, countries: ["MX"] },
  MYR: { code: "MYR", name: "Malaysian Ringgit", symbol: "RM", flag: "\u{1F1F2}\u{1F1FE}", decimalDigits: 2, countries: ["MY"] },
  MZN: { code: "MZN", name: "Mozambican Metical", symbol: "MTn", flag: "\u{1F1F2}\u{1F1FF}", decimalDigits: 2, countries: ["MZ"] },
  NAD: { code: "NAD", name: "Namibian Dollar", symbol: "N$", flag: "\u{1F1F3}\u{1F1E6}", decimalDigits: 2, countries: ["NA"] },
  NGN: { code: "NGN", name: "Nigerian Naira", symbol: "\u20A6", flag: "\u{1F1F3}\u{1F1EC}", decimalDigits: 2, countries: ["NG"] },
  NIO: { code: "NIO", name: "Nicaraguan C\xF3rdoba", symbol: "C$", flag: "\u{1F1F3}\u{1F1EE}", decimalDigits: 2, countries: ["NI"] },
  NOK: { code: "NOK", name: "Norwegian Krone", symbol: "kr", flag: "\u{1F1F3}\u{1F1F4}", decimalDigits: 2, countries: ["NO", "SJ"] },
  NPR: { code: "NPR", name: "Nepalese Rupee", symbol: "NPRs", flag: "\u{1F1F3}\u{1F1F5}", decimalDigits: 2, countries: ["NP"] },
  NZD: { code: "NZD", name: "New Zealand Dollar", symbol: "NZ$", flag: "\u{1F1F3}\u{1F1FF}", decimalDigits: 2, countries: ["NZ", "CK", "NU", "PN"] },
  OMR: { code: "OMR", name: "Omani Rial", symbol: "OMR", flag: "\u{1F1F4}\u{1F1F2}", decimalDigits: 3, countries: ["OM"] },
  PAB: { code: "PAB", name: "Panamanian Balboa", symbol: "B/.", flag: "\u{1F1F5}\u{1F1E6}", decimalDigits: 2, countries: ["PA"] },
  PEN: { code: "PEN", name: "Peruvian Nuevo Sol", symbol: "S/.", flag: "\u{1F1F5}\u{1F1EA}", decimalDigits: 2, countries: ["PE"] },
  PGK: { code: "PGK", name: "Papua New Guinean Kina", symbol: "K", flag: "\u{1F1F5}\u{1F1EC}", decimalDigits: 2, countries: ["PG"] },
  PHP: { code: "PHP", name: "Philippine Peso", symbol: "\u20B1", flag: "\u{1F1F5}\u{1F1ED}", decimalDigits: 2, countries: ["PH"] },
  PKR: { code: "PKR", name: "Pakistani Rupee", symbol: "PKRs", flag: "\u{1F1F5}\u{1F1F0}", decimalDigits: 2, countries: ["PK"] },
  PLN: { code: "PLN", name: "Polish Zloty", symbol: "z\u0142", flag: "\u{1F1F5}\u{1F1F1}", decimalDigits: 2, countries: ["PL"] },
  PYG: { code: "PYG", name: "Paraguayan Guarani", symbol: "\u20B2", flag: "\u{1F1F5}\u{1F1FE}", decimalDigits: 0, countries: ["PY"] },
  QAR: { code: "QAR", name: "Qatari Rial", symbol: "QR", flag: "\u{1F1F6}\u{1F1E6}", decimalDigits: 2, countries: ["QA"] },
  RON: { code: "RON", name: "Romanian Leu", symbol: "RON", flag: "\u{1F1F7}\u{1F1F4}", decimalDigits: 2, countries: ["RO"] },
  RSD: { code: "RSD", name: "Serbian Dinar", symbol: "din.", flag: "\u{1F1F7}\u{1F1F8}", decimalDigits: 2, countries: ["RS"] },
  RUB: { code: "RUB", name: "Russian Ruble", symbol: "\u20BD", flag: "\u{1F1F7}\u{1F1FA}", decimalDigits: 2, countries: ["RU"] },
  RWF: { code: "RWF", name: "Rwandan Franc", symbol: "RWF", flag: "\u{1F1F7}\u{1F1FC}", decimalDigits: 0, countries: ["RW"] },
  SAR: { code: "SAR", name: "Saudi Riyal", symbol: "SR", flag: "\u{1F1F8}\u{1F1E6}", decimalDigits: 2, countries: ["SA"] },
  SBD: { code: "SBD", name: "Solomon Islands Dollar", symbol: "SI$", flag: "\u{1F1F8}\u{1F1E7}", decimalDigits: 2, countries: ["SB"] },
  SCR: { code: "SCR", name: "Seychellois Rupee", symbol: "SRe", flag: "\u{1F1F8}\u{1F1E8}", decimalDigits: 2, countries: ["SC"] },
  SDG: { code: "SDG", name: "Sudanese Pound", symbol: "SDG", flag: "\u{1F1F8}\u{1F1E9}", decimalDigits: 2, countries: ["SD"] },
  SEK: { code: "SEK", name: "Swedish Krona", symbol: "kr", flag: "\u{1F1F8}\u{1F1EA}", decimalDigits: 2, countries: ["SE"] },
  SGD: { code: "SGD", name: "Singapore Dollar", symbol: "S$", flag: "\u{1F1F8}\u{1F1EC}", decimalDigits: 2, countries: ["SG"] },
  SHP: { code: "SHP", name: "Saint Helena Pound", symbol: "\xA3", flag: "\u{1F1F8}\u{1F1ED}", decimalDigits: 2, countries: ["SH"] },
  SLL: { code: "SLL", name: "Sierra Leonean Leone", symbol: "Le", flag: "\u{1F1F8}\u{1F1F1}", decimalDigits: 2, countries: ["SL"] },
  SOS: { code: "SOS", name: "Somali Shilling", symbol: "Ssh", flag: "\u{1F1F8}\u{1F1F4}", decimalDigits: 2, countries: ["SO"] },
  SRD: { code: "SRD", name: "Surinamese Dollar", symbol: "$", flag: "\u{1F1F8}\u{1F1F7}", decimalDigits: 2, countries: ["SR"] },
  STN: { code: "STN", name: "S\xE3o Tom\xE9 and Pr\xEDncipe Dobra", symbol: "Db", flag: "\u{1F1F8}\u{1F1F9}", decimalDigits: 2, countries: ["ST"] },
  SYP: { code: "SYP", name: "Syrian Pound", symbol: "SY\xA3", flag: "\u{1F1F8}\u{1F1FE}", decimalDigits: 2, countries: ["SY"] },
  SZL: { code: "SZL", name: "Swazi Lilangeni", symbol: "SZL", flag: "\u{1F1F8}\u{1F1FF}", decimalDigits: 2, countries: ["SZ"] },
  THB: { code: "THB", name: "Thai Baht", symbol: "\u0E3F", flag: "\u{1F1F9}\u{1F1ED}", decimalDigits: 2, countries: ["TH"] },
  TJS: { code: "TJS", name: "Tajikistani Somoni", symbol: "TJS", flag: "\u{1F1F9}\u{1F1EF}", decimalDigits: 2, countries: ["TJ"] },
  TMT: { code: "TMT", name: "Turkmenistani Manat", symbol: "TMT", flag: "\u{1F1F9}\u{1F1F2}", decimalDigits: 2, countries: ["TM"] },
  TND: { code: "TND", name: "Tunisian Dinar", symbol: "DT", flag: "\u{1F1F9}\u{1F1F3}", decimalDigits: 3, countries: ["TN"] },
  TOP: { code: "TOP", name: "Tongan Pa\u02BBanga", symbol: "T$", flag: "\u{1F1F9}\u{1F1F4}", decimalDigits: 2, countries: ["TO"] },
  TRY: { code: "TRY", name: "Turkish Lira", symbol: "\u20BA", flag: "\u{1F1F9}\u{1F1F7}", decimalDigits: 2, countries: ["TR"] },
  TTD: { code: "TTD", name: "Trinidad and Tobago Dollar", symbol: "TT$", flag: "\u{1F1F9}\u{1F1F9}", decimalDigits: 2, countries: ["TT"] },
  TWD: { code: "TWD", name: "New Taiwan Dollar", symbol: "NT$", flag: "\u{1F1F9}\u{1F1FC}", decimalDigits: 2, countries: ["TW"] },
  TZS: { code: "TZS", name: "Tanzanian Shilling", symbol: "TSh", flag: "\u{1F1F9}\u{1F1FF}", decimalDigits: 2, countries: ["TZ"] },
  UAH: { code: "UAH", name: "Ukrainian Hryvnia", symbol: "\u20B4", flag: "\u{1F1FA}\u{1F1E6}", decimalDigits: 2, countries: ["UA"] },
  UGX: { code: "UGX", name: "Ugandan Shilling", symbol: "USh", flag: "\u{1F1FA}\u{1F1EC}", decimalDigits: 0, countries: ["UG"] },
  UYU: { code: "UYU", name: "Uruguayan Peso", symbol: "$U", flag: "\u{1F1FA}\u{1F1FE}", decimalDigits: 2, countries: ["UY"] },
  UZS: { code: "UZS", name: "Uzbekistan Som", symbol: "UZS", flag: "\u{1F1FA}\u{1F1FF}", decimalDigits: 2, countries: ["UZ"] },
  VES: { code: "VES", name: "Venezuelan Bol\xEDvar", symbol: "Bs.S", flag: "\u{1F1FB}\u{1F1EA}", decimalDigits: 2, countries: ["VE"] },
  VND: { code: "VND", name: "Vietnamese Dong", symbol: "\u20AB", flag: "\u{1F1FB}\u{1F1F3}", decimalDigits: 0, countries: ["VN"] },
  VUV: { code: "VUV", name: "Vanuatu Vatu", symbol: "VT", flag: "\u{1F1FB}\u{1F1FA}", decimalDigits: 0, countries: ["VU"] },
  WST: { code: "WST", name: "Samoan Tala", symbol: "WS$", flag: "\u{1F1FC}\u{1F1F8}", decimalDigits: 2, countries: ["WS"] },
  XAF: { code: "XAF", name: "Central African CFA Franc", symbol: "FCFA", flag: "\u{1F1E8}\u{1F1F2}", decimalDigits: 0, countries: ["CM", "CF", "TD", "CG", "GQ", "GA"] },
  XCD: { code: "XCD", name: "East Caribbean Dollar", symbol: "EC$", flag: "\u{1F1E6}\u{1F1EC}", decimalDigits: 2, countries: ["AG", "DM", "GD", "KN", "LC", "VC"] },
  XOF: { code: "XOF", name: "West African CFA Franc", symbol: "CFA", flag: "\u{1F1F8}\u{1F1F3}", decimalDigits: 0, countries: ["SN", "CI", "ML", "BF", "NE", "TG", "BJ", "GW"] },
  XPF: { code: "XPF", name: "CFP Franc", symbol: "CFPF", flag: "\u{1F1F5}\u{1F1EB}", decimalDigits: 0, countries: ["PF", "NC", "WF"] },
  YER: { code: "YER", name: "Yemeni Rial", symbol: "YR", flag: "\u{1F1FE}\u{1F1EA}", decimalDigits: 2, countries: ["YE"] },
  ZAR: { code: "ZAR", name: "South African Rand", symbol: "R", flag: "\u{1F1FF}\u{1F1E6}", decimalDigits: 2, countries: ["ZA"] },
  ZMW: { code: "ZMW", name: "Zambian Kwacha", symbol: "ZK", flag: "\u{1F1FF}\u{1F1F2}", decimalDigits: 2, countries: ["ZM"] },
  ZWL: { code: "ZWL", name: "Zimbabwean Dollar", symbol: "ZWL", flag: "\u{1F1FF}\u{1F1FC}", decimalDigits: 2, countries: ["ZW"] }
};
var POPULAR_CURRENCIES = ["USD", "EUR", "GBP", "INR", "JPY", "CAD", "AUD", "CHF", "CNY", "BRL", "SGD", "AED"];
function getCurrency(code) {
  return CURRENCIES[code.toUpperCase()] || {
    code: code.toUpperCase(),
    name: code.toUpperCase(),
    symbol: code.toUpperCase(),
    flag: "\u{1F310}",
    decimalDigits: 2,
    countries: []
  };
}
function formatCurrencyAmount(amount, currencyCode, options = {}) {
  const meta = getCurrency(currencyCode);
  const precision = options.precision ?? meta.decimalDigits;
  const locale = options.locale ?? "en-US";
  const isNegative = amount < 0;
  const absAmount = Math.abs(amount);
  try {
    const formattedNum = new Intl.NumberFormat(locale, {
      minimumFractionDigits: precision,
      maximumFractionDigits: precision
    }).format(absAmount);
    if (options.showSymbol !== false) {
      return isNegative ? `-${meta.symbol}${formattedNum}` : `${meta.symbol}${formattedNum}`;
    }
    return isNegative ? `-${formattedNum}` : formattedNum;
  } catch {
    const fallbackFormatted = absAmount.toFixed(precision);
    if (options.showSymbol !== false) {
      return isNegative ? `-${meta.symbol}${fallbackFormatted}` : `${meta.symbol}${fallbackFormatted}`;
    }
    return isNegative ? `-${fallbackFormatted}` : fallbackFormatted;
  }
}

// ../shared/dist/detector/price-parser.js
var CURRENCY_SYMBOLS_REGEX = "[$\u20AC\xA3\u20B9\xA5\uFFE5\u20BD\u20A9\u20BA\u20AB\u0E3F\u20B1\u20AA]|R\\$|CA\\$|A\\$|AU\\$|NZ\\$|HK\\$|S\\$|US\\$|kr|K\u010D|z\u0142|Ft|CHF|RM|Rp|\u09F3|\u20A8|Nu\\.|GH\u20B5|\u20A6|\u20A1|\u20B2|\u20B4";
var CURRENCY_CODES_REGEX = Object.keys(CURRENCIES).join("|");
var NUM_PATTERN = "\\d{1,3}(?:[.,\\s]\\d{3})*(?:[.,]\\d{1,4})?|\\d+(?:[.,]\\d{1,4})?";
var REGEX_SYMBOL_PREFIX = new RegExp(`(?<!\\w)(${CURRENCY_SYMBOLS_REGEX})\\s*(${NUM_PATTERN})(?!\\w)`, "i");
var REGEX_SYMBOL_SUFFIX = new RegExp(`(?<!\\w)(${NUM_PATTERN})\\s*(${CURRENCY_SYMBOLS_REGEX})(?!\\w)`, "i");
var REGEX_CODE_PREFIX = new RegExp(`(?<![a-zA-Z])(${CURRENCY_CODES_REGEX})\\s+(${NUM_PATTERN})(?!\\w)`, "i");
var REGEX_CODE_SUFFIX = new RegExp(`(?<!\\w)(${NUM_PATTERN})\\s+(${CURRENCY_CODES_REGEX})(?![a-zA-Z])`, "i");

// ../shared/dist/config/index.js
var DEFAULT_PERSONAL_RATE = {
  baseCurrency: "USD",
  targetCurrency: "INR",
  rate: 87.12,
  lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
  dailyReminderEnabled: true,
  additionalRates: {
    "EUR_INR": 94.7,
    "GBP_INR": 110.5,
    "JPY_INR": 0.58,
    "CAD_INR": 63.5,
    "AUD_INR": 57.8
  },
  savedPairs: [
    {
      id: "USD_INR",
      baseCurrency: "USD",
      targetCurrency: "INR",
      rate: 87.12,
      lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
      isActive: true
    }
  ]
};
var DEFAULT_RATE_PROFILES = [
  {
    id: "prof_personal",
    name: "Personal Rate",
    description: "Custom rates obtained from Google for personal purchases and budgeting",
    baseCurrency: "INR",
    rates: {
      "USD_INR": 87.12,
      "EUR_INR": 94.7,
      "GBP_INR": 110.5,
      "JPY_INR": 0.58,
      "CAD_INR": 63.5,
      "AUD_INR": 57.8,
      "AED_INR": 23.75,
      "SGD_INR": 65.2
    },
    isDefault: true,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "prof_bank",
    name: "Bank Exchange Rate",
    description: "Typical credit card and bank foreign exchange rate with 2-3% spread",
    baseCurrency: "INR",
    rates: {
      "USD_INR": 89.5,
      "EUR_INR": 97.2,
      "GBP_INR": 113.8,
      "JPY_INR": 0.6,
      "CAD_INR": 65.2,
      "AUD_INR": 59.4,
      "AED_INR": 24.4,
      "SGD_INR": 67
    },
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "prof_business",
    name: "Business Rate",
    description: "Corporate accounting and invoice valuation rates",
    baseCurrency: "USD",
    rates: {
      "USD_EUR": 0.92,
      "USD_GBP": 0.79,
      "USD_INR": 87,
      "USD_JPY": 154,
      "USD_CAD": 1.38,
      "USD_AUD": 1.52
    },
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "prof_travel",
    name: "Travel Rate",
    description: "Cash airport exchange and kiosk rates for holiday trips",
    baseCurrency: "INR",
    rates: {
      "USD_INR": 90,
      "EUR_INR": 98,
      "GBP_INR": 115,
      "JPY_INR": 0.62,
      "AED_INR": 25,
      "THB_INR": 2.65
    },
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "prof_custom",
    name: "Custom Rate",
    description: "User-defined direct currency pairs and overrides",
    rates: {
      "EUR_INR": 94.7,
      "USD_INR": 87.12
    },
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  }
];
var DEFAULT_DUAL_RATE_CONFIG = {
  mode: "manual",
  // Default to personal manual rate engine
  activeProfileId: "prof_personal",
  profiles: DEFAULT_RATE_PROFILES,
  fallbackToAutomaticOnError: false
};
var APP_CONFIG = {
  appName: "HoverCurrency",
  appTagline: "Instant Hover-to-Convert Currency Ecosystem",
  websiteUrl: "https://currenceconverter.me",
  apiUrl: "http://localhost:3000/api",
  plans: {
    free: {
      name: "Free",
      price: 0,
      monthlyConversionsLimit: 29,
      features: [
        "29 successful conversions per month",
        "Personal exchange rate system (Google rate entry)",
        "Hover-to-convert engine on all websites",
        "Daily update reminders & stale rate alerts",
        "Target currency selection (160+ currencies)",
        "Usage counter & reset tracker"
      ]
    },
    pro: {
      name: "Pro",
      price: 9,
      interval: "3 months",
      intervalCount: 3,
      monthlyConversionsLimit: Infinity,
      features: [
        "Unlimited currency conversions",
        "Unlimited hover-to-convert usage",
        "Premium rate profiles (Personal, Bank, Business, Travel)",
        "Cross-device browser sync",
        "Priority 24/7 support",
        "No conversion limits"
      ]
    }
  },
  defaultPreferences: {
    defaultBaseCurrency: "USD",
    defaultTargetCurrency: "INR",
    hoverEnabled: true,
    tooltipTheme: "dark",
    precision: 2,
    autoDetectSource: true,
    excludedDomains: [
      "paypal.com",
      "chase.com",
      "bankofamerica.com",
      "wellsfargo.com"
    ],
    showRateTimestamp: true,
    rateMode: "manual",
    activeProfileId: "prof_personal"
  },
  personalRate: DEFAULT_PERSONAL_RATE,
  dualRateEngine: DEFAULT_DUAL_RATE_CONFIG,
  dodoPayments: {
    sandboxUrl: "https://test.dodopayments.com",
    productionUrl: "https://api.dodopayments.com",
    defaultProductId: "p_quarterly_pro_9"
  }
};

// ../shared/dist/exchange-rate/rates.js
var MissingManualRateError = class extends Error {
  from;
  to;
  profileName;
  constructor(from, to, profileName = "Personal Rate") {
    super(`Exchange rate not available for ${from} \u2192 ${to} in "${profileName}". Please enter this rate manually from Google.`);
    this.name = "MissingManualRateError";
    this.from = from;
    this.to = to;
    this.profileName = profileName;
  }
};
var PersonalRateEngine = class _PersonalRateEngine {
  static instance;
  config = { ...DEFAULT_DUAL_RATE_CONFIG };
  personalRate = { ...DEFAULT_PERSONAL_RATE };
  // Built-in cached reference rates for Automatic Mode (offline / zero external API calls)
  automaticCache = {
    USD: 1,
    EUR: 0.92,
    GBP: 0.79,
    INR: 87.12,
    JPY: 154,
    CAD: 1.38,
    AUD: 1.52,
    CHF: 0.88,
    CNY: 7.24,
    AED: 3.67,
    SGD: 1.34,
    BRL: 5.75,
    MXN: 20.15,
    KRW: 1390,
    SEK: 10.9,
    NZD: 1.68
  };
  constructor() {
  }
  static getInstance() {
    if (!_PersonalRateEngine.instance) {
      _PersonalRateEngine.instance = new _PersonalRateEngine();
    }
    return _PersonalRateEngine.instance;
  }
  // Personal Rate Management
  getPersonalRate() {
    return { ...this.personalRate };
  }
  setPersonalRate(rateConfig) {
    this.personalRate = {
      ...this.personalRate,
      ...rateConfig,
      lastUpdated: rateConfig.lastUpdated || (/* @__PURE__ */ new Date()).toISOString()
    };
    return { ...this.personalRate };
  }
  isRateStale(lastUpdatedIso) {
    const ageMs = Date.now() - new Date(lastUpdatedIso).getTime();
    return ageMs >= 24 * 60 * 60 * 1e3;
  }
  getRateFreshness(lastUpdatedIso) {
    return this.isRateStale(lastUpdatedIso) ? "stale" : "fresh";
  }
  // Dual engine config
  getConfig() {
    return { ...this.config };
  }
  setMode(mode) {
    this.config.mode = mode;
  }
  getMode() {
    return this.config.mode;
  }
  setActiveProfile(profileId) {
    const exists = this.config.profiles.some((p) => p.id === profileId);
    if (exists) {
      this.config.activeProfileId = profileId;
    }
  }
  getActiveProfile() {
    const found = this.config.profiles.find((p) => p.id === this.config.activeProfileId);
    return found || this.config.profiles[0] || DEFAULT_RATE_PROFILES[0];
  }
  setProfiles(profiles) {
    this.config.profiles = profiles;
  }
  /**
   * Resolves rate using Personal Exchange Rate system:
   * 1. 1 USD = [savedRate] [targetCurrency]
   * 2. If USD -> Target: rate = savedRate
   * 3. If Target -> USD: rate = 1 / savedRate
   * 4. Additional rates from profile or personal config if explicitly configured
   * Never invents missing rates!
   */
  resolveRate(from, to, personalConfig = this.personalRate, profile) {
    const f = from.toUpperCase();
    const t = to.toUpperCase();
    const base = (personalConfig.baseCurrency || "USD").toUpperCase();
    const target = (personalConfig.targetCurrency || "INR").toUpperCase();
    const savedRate = personalConfig.rate;
    if (f === t) {
      return { rate: 1, isCustom: false, profileName: "Identical Pair" };
    }
    const prof = profile || this.getActiveProfile();
    const isSpecificProfile = prof && prof.id !== "prof_personal";
    const checkProfileRates = () => {
      if (!prof || !prof.rates)
        return null;
      const directKey = `${f}_${t}`;
      const inverseKey = `${t}_${f}`;
      if (prof.rates[directKey] !== void 0) {
        return { rate: prof.rates[directKey], isCustom: true, profileName: prof.name };
      }
      if (prof.rates[inverseKey] !== void 0 && prof.rates[inverseKey] > 0) {
        return { rate: 1 / prof.rates[inverseKey], isCustom: true, profileName: prof.name };
      }
      if (prof.baseCurrency) {
        const pb = prof.baseCurrency.toUpperCase();
        const pbToF = f === pb ? 1 : prof.rates[`${pb}_${f}`] ?? prof.rates[f] ?? (prof.rates[`${f}_${pb}`] ? 1 / prof.rates[`${f}_${pb}`] : void 0);
        const pbToT = t === pb ? 1 : prof.rates[`${pb}_${t}`] ?? prof.rates[t] ?? (prof.rates[`${t}_${pb}`] ? 1 / prof.rates[`${t}_${pb}`] : void 0);
        if (pbToF && pbToT && pbToF > 0) {
          return { rate: pbToT / pbToF, isCustom: true, profileName: prof.name };
        }
      }
      for (const key of Object.keys(prof.rates)) {
        if (key.startsWith(`${f}_`)) {
          const common = key.substring(f.length + 1);
          const matchT = prof.rates[`${t}_${common}`];
          if (matchT && matchT > 0) {
            return { rate: prof.rates[key] / matchT, isCustom: true, profileName: prof.name };
          }
        }
      }
      for (const key of Object.keys(prof.rates)) {
        if (key.endsWith(`_${f}`)) {
          const common = key.substring(0, key.length - f.length - 1);
          const matchT = prof.rates[`${common}_${t}`];
          if (matchT && matchT > 0 && prof.rates[key] > 0) {
            return { rate: matchT / prof.rates[key], isCustom: true, profileName: prof.name };
          }
        }
      }
      return null;
    };
    if (isSpecificProfile) {
      const fromProf = checkProfileRates();
      if (fromProf)
        return fromProf;
    }
    if (personalConfig.savedPairs && personalConfig.savedPairs.length > 0) {
      const directPair = personalConfig.savedPairs.find((p) => p.baseCurrency.toUpperCase() === f && p.targetCurrency.toUpperCase() === t && p.rate > 0);
      if (directPair) {
        return { rate: directPair.rate, isCustom: true, profileName: "Personal Rate" };
      }
      const inversePair = personalConfig.savedPairs.find((p) => p.baseCurrency.toUpperCase() === t && p.targetCurrency.toUpperCase() === f && p.rate > 0);
      if (inversePair) {
        return { rate: 1 / inversePair.rate, isCustom: true, profileName: "Personal Rate" };
      }
      for (const pairA of personalConfig.savedPairs) {
        const aBase = pairA.baseCurrency.toUpperCase();
        const aTarget = pairA.targetCurrency.toUpperCase();
        let fToBridge = null;
        let bridge = null;
        if (aBase === f && pairA.rate > 0) {
          bridge = aTarget;
          fToBridge = pairA.rate;
        } else if (aTarget === f && pairA.rate > 0) {
          bridge = aBase;
          fToBridge = 1 / pairA.rate;
        }
        if (bridge && fToBridge !== null) {
          for (const pairB of personalConfig.savedPairs) {
            const bBase = pairB.baseCurrency.toUpperCase();
            const bTarget = pairB.targetCurrency.toUpperCase();
            let bridgeToT = null;
            if (bBase === bridge && bTarget === t && pairB.rate > 0) {
              bridgeToT = pairB.rate;
            } else if (bTarget === bridge && bBase === t && pairB.rate > 0) {
              bridgeToT = 1 / pairB.rate;
            }
            if (bridgeToT !== null) {
              return { rate: fToBridge * bridgeToT, isCustom: true, profileName: "Personal Rate" };
            }
          }
        }
      }
    }
    if (f === base && t === target && savedRate > 0) {
      return { rate: savedRate, isCustom: true, profileName: "Personal Rate" };
    }
    if (f === target && t === base && savedRate > 0) {
      return { rate: 1 / savedRate, isCustom: true, profileName: "Personal Rate" };
    }
    if (personalConfig.additionalRates) {
      const directKey = `${f}_${t}`;
      const inverseKey = `${t}_${f}`;
      if (personalConfig.additionalRates[directKey] !== void 0) {
        return { rate: personalConfig.additionalRates[directKey], isCustom: true, profileName: "Personal Rate" };
      }
      if (personalConfig.additionalRates[inverseKey] !== void 0 && personalConfig.additionalRates[inverseKey] > 0) {
        return { rate: 1 / personalConfig.additionalRates[inverseKey], isCustom: true, profileName: "Personal Rate" };
      }
      const fToTarget = personalConfig.additionalRates[`${f}_${target}`];
      const tToTarget = personalConfig.additionalRates[`${t}_${target}`];
      if (fToTarget && tToTarget && tToTarget > 0) {
        return { rate: fToTarget / tToTarget, isCustom: true, profileName: "Personal Rate" };
      }
      const baseToF = personalConfig.additionalRates[`${base}_${f}`] ?? (f === base ? 1 : void 0);
      const baseToT = personalConfig.additionalRates[`${base}_${t}`] ?? (t === base ? 1 : t === target ? savedRate : void 0);
      if (baseToF && baseToT && baseToF > 0) {
        return { rate: baseToT / baseToF, isCustom: true, profileName: "Personal Rate" };
      }
    }
    if (!isSpecificProfile) {
      const fromProf = checkProfileRates();
      if (fromProf)
        return fromProf;
    }
    return null;
  }
  /**
   * Main Conversion Engine (No External Currency API)
   */
  async convert(amount, from, to, options = {}) {
    const fromCode = from.toUpperCase();
    const toCode = to.toUpperCase();
    const personal = options.personalRateConfig || this.personalRate;
    const profile = options.profileId ? this.config.profiles.find((p) => p.id === options.profileId) || this.getActiveProfile() : this.getActiveProfile();
    const fromMeta = getCurrency(fromCode);
    const toMeta = getCurrency(toCode);
    const fromPrecision = fromMeta.decimalDigits;
    const toPrecision = options.precision ?? toMeta.decimalDigits;
    const effectiveMode = options.mode || this.config.mode;
    if (effectiveMode === "automatic") {
      let autoRate = null;
      if (fromCode === toCode) {
        autoRate = 1;
      } else if (this.automaticCache[fromCode] && this.automaticCache[toCode]) {
        autoRate = this.automaticCache[toCode] / this.automaticCache[fromCode];
      }
      if (autoRate !== null && !isNaN(autoRate) && autoRate > 0) {
        const factor2 = Math.pow(10, toPrecision);
        const convertedAmount2 = Math.round((amount * autoRate + Number.EPSILON) * factor2) / factor2;
        return {
          from: fromCode,
          to: toCode,
          originalAmount: amount,
          convertedAmount: convertedAmount2,
          rate: autoRate,
          lastUpdated: this.config.lastAutomaticFetch || (/* @__PURE__ */ new Date()).toISOString(),
          formattedOriginal: formatCurrencyAmount(amount, fromCode, { precision: fromPrecision }),
          formattedConverted: formatCurrencyAmount(convertedAmount2, toCode, { precision: toPrecision }),
          rateMode: "automatic",
          rateFreshness: "fresh",
          rateProvider: "Standard Exchange Reference Cache",
          isCustomRate: false,
          rateProfileName: "Automatic Live Rate"
        };
      }
    }
    let rate = options.customRate || null;
    let profileName = profile.name;
    if (rate === null) {
      const resolved = this.resolveRate(fromCode, toCode, personal, profile);
      if (resolved) {
        rate = resolved.rate;
        profileName = resolved.profileName;
      }
    }
    if (rate === null || isNaN(rate) || rate <= 0) {
      throw new MissingManualRateError(fromCode, toCode, profileName);
    }
    const factor = Math.pow(10, toPrecision);
    const convertedAmount = Math.round((amount * rate + Number.EPSILON) * factor) / factor;
    const isStale = this.isRateStale(personal.lastUpdated);
    const freshness = isStale ? "stale" : "fresh";
    return {
      from: fromCode,
      to: toCode,
      originalAmount: amount,
      convertedAmount,
      rate,
      lastUpdated: personal.lastUpdated,
      formattedOriginal: formatCurrencyAmount(amount, fromCode, { precision: fromPrecision }),
      formattedConverted: formatCurrencyAmount(convertedAmount, toCode, { precision: toPrecision }),
      rateMode: "manual",
      rateFreshness: freshness,
      rateProvider: `Personal Rate: 1 ${personal.baseCurrency} = ${personal.rate} ${personal.targetCurrency}`,
      isCustomRate: true,
      rateProfileName: profileName
    };
  }
  parseBulkRatesText(text, defaultTargetCurrency = "INR") {
    const results = [];
    const lines = text.split(/\r?\n/);
    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line || line.startsWith("#") || line.startsWith("//"))
        continue;
      if (line.includes(",")) {
        const parts = line.split(",").map((p) => p.trim());
        if (parts.length >= 3) {
          const from = parts[0].toUpperCase();
          const to = parts[1].toUpperCase();
          const rate = parseFloat(parts[2]);
          if (!isNaN(rate) && rate > 0)
            results.push({ from, to, rate });
        } else if (parts.length === 2) {
          const from = parts[0].toUpperCase();
          const rate = parseFloat(parts[1]);
          if (!isNaN(rate) && rate > 0)
            results.push({ from, to: defaultTargetCurrency.toUpperCase(), rate });
        }
        continue;
      }
      const matchEquals = line.match(/(?:1\s+)?([A-Za-z]{3})\s*(?:=|\/|:|-)\s*(\d+(?:[.,]\d+)?)\s*([A-Za-z]{3})?/i);
      if (matchEquals) {
        const from = matchEquals[1].toUpperCase();
        const rate = parseFloat(matchEquals[2].replace(",", "."));
        const to = (matchEquals[3] || defaultTargetCurrency).toUpperCase();
        if (!isNaN(rate) && rate > 0)
          results.push({ from, to, rate });
      }
    }
    return results;
  }
  async getRates() {
    return {
      base: this.personalRate.baseCurrency,
      rates: {
        [this.personalRate.baseCurrency]: 1,
        [this.personalRate.targetCurrency]: this.personalRate.rate,
        ...this.personalRate.additionalRates || {}
      },
      lastUpdated: this.personalRate.lastUpdated,
      provider: "Personal Google Rate Entry"
    };
  }
};
var exchangeRateService = PersonalRateEngine.getInstance();

// src/options/options.ts
var tabModeAuto = document.getElementById("tab-mode-auto");
var tabModeManual = document.getElementById("tab-mode-manual");
var modeDesc = document.getElementById("mode-desc");
var btnRestoreAuto = document.getElementById("btn-restore-automatic");
var selectProfile = document.getElementById("select-profile");
var inputFromCurrency = document.getElementById("input-from-currency");
var inputToCurrency = document.getElementById("input-to-currency");
var inputPairRate = document.getElementById("input-pair-rate");
var btnAddPair = document.getElementById("btn-add-pair");
var bulkRatesInput = document.getElementById("bulk-rates-input");
var btnImportBulk = document.getElementById("btn-import-bulk");
var importCountMsg = document.getElementById("import-count-msg");
var ratesTbody = document.getElementById("rates-tbody");
var defaultTargetSelect = document.getElementById("default-target");
var precisionSelect = document.getElementById("precision");
var btnSaveAll = document.getElementById("btn-save-all");
var statusAlert = document.getElementById("status-alert");
var currentMode = "automatic";
var currentProfiles = [...DEFAULT_RATE_PROFILES];
var activeProfileId = "prof_personal";
function populateCurrencyDropdowns() {
  const codes = Object.keys(CURRENCIES).sort((a, b) => {
    const isPopA = POPULAR_CURRENCIES.includes(a);
    const isPopB = POPULAR_CURRENCIES.includes(b);
    if (isPopA && !isPopB)
      return -1;
    if (!isPopA && isPopB)
      return 1;
    return a.localeCompare(b);
  });
  defaultTargetSelect.innerHTML = "";
  inputFromCurrency.innerHTML = "";
  inputToCurrency.innerHTML = "";
  for (const code of codes) {
    const curr = CURRENCIES[code];
    const opt = document.createElement("option");
    opt.value = code;
    opt.textContent = `${curr.flag} ${code} (${curr.symbol})`;
    defaultTargetSelect.appendChild(opt.cloneNode(true));
    inputFromCurrency.appendChild(opt.cloneNode(true));
    inputToCurrency.appendChild(opt);
  }
  inputFromCurrency.value = "EUR";
  inputToCurrency.value = "INR";
  defaultTargetSelect.value = "INR";
}
function populateProfiles() {
  selectProfile.innerHTML = "";
  for (const p of currentProfiles) {
    const opt = document.createElement("option");
    opt.value = p.id;
    opt.textContent = `${p.name} - ${p.description || ""}`;
    selectProfile.appendChild(opt);
  }
  selectProfile.value = activeProfileId;
}
function renderRatesTable() {
  ratesTbody.innerHTML = "";
  const profile = currentProfiles.find((p) => p.id === activeProfileId);
  if (!profile || Object.keys(profile.rates || {}).length === 0) {
    ratesTbody.innerHTML = `<tr><td colspan="4" style="text-align:center; color:#64748b; padding:16px;">No custom rates saved in this profile. Add pairs above.</td></tr>`;
    return;
  }
  for (const [pairKey, rate] of Object.entries(profile.rates)) {
    const parts = pairKey.split("_");
    const from = parts[0];
    const to = parts[1] || "INR";
    const inverse = rate > 0 ? (1 / rate).toFixed(4) : "-";
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td style="font-weight:600; color:white;">1 ${from} =</td>
      <td style="color:#fbbf24; font-weight:bold;">${rate} ${to}</td>
      <td style="color:#94a3b8; font-size:11px;">1 ${to} = ${inverse} ${from}</td>
      <td style="text-align:right;">
        <button class="btn-del" data-key="${pairKey}">Delete</button>
      </td>
    `;
    ratesTbody.appendChild(tr);
  }
  ratesTbody.querySelectorAll(".btn-del").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      const key = e.target.getAttribute("data-key");
      if (key && profile.rates[key] !== void 0) {
        delete profile.rates[key];
        profile.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
        renderRatesTable();
      }
    });
  });
}
function updateModeTabs() {
  if (currentMode === "manual") {
    tabModeAuto.className = "mode-tab";
    tabModeManual.className = "mode-tab active manual";
    modeDesc.textContent = "Manual Mode is ACTIVE: Hover-to-convert strictly uses the rates defined in the selected profile. If a rate is missing, an alert prompt will appear.";
  } else {
    tabModeAuto.className = "mode-tab active";
    tabModeManual.className = "mode-tab";
    modeDesc.textContent = "Automatic Mode is ACTIVE: Exchange rates are fetched from the live market API and updated hourly.";
  }
}
async function loadAllSettings() {
  const sync = await chrome.storage.sync.get([
    "rateMode",
    "activeProfileId",
    "rateProfiles",
    "preferences",
    "personalRate"
  ]);
  if (sync.rateMode)
    currentMode = sync.rateMode;
  if (sync.rateProfiles)
    currentProfiles = sync.rateProfiles;
  if (sync.activeProfileId)
    activeProfileId = sync.activeProfileId;
  const targetCurr = sync.personalRate?.targetCurrency || sync.preferences?.defaultTargetCurrency;
  if (targetCurr) {
    defaultTargetSelect.value = targetCurr;
  }
  const fromCurr = sync.personalRate?.baseCurrency || sync.preferences?.defaultBaseCurrency;
  if (fromCurr) {
    inputFromCurrency.value = fromCurr;
  }
  if (sync.preferences?.precision !== void 0) {
    precisionSelect.value = sync.preferences.precision.toString();
  }
  updateModeTabs();
  populateProfiles();
  renderRatesTable();
}
tabModeAuto.addEventListener("click", () => {
  currentMode = "automatic";
  updateModeTabs();
});
tabModeManual.addEventListener("click", () => {
  currentMode = "manual";
  updateModeTabs();
});
btnRestoreAuto.addEventListener("click", async () => {
  currentMode = "automatic";
  updateModeTabs();
  await chrome.storage.sync.set({ rateMode: "automatic" });
  chrome.runtime.sendMessage({ type: "RESTORE_AUTOMATIC" });
  showStatus("Restored to Automatic Live Market Rates!");
});
selectProfile.addEventListener("change", () => {
  activeProfileId = selectProfile.value;
  renderRatesTable();
});
btnAddPair.addEventListener("click", () => {
  const from = inputFromCurrency.value;
  const to = inputToCurrency.value;
  const rate = parseFloat(inputPairRate.value);
  if (isNaN(rate) || rate <= 0) {
    alert("Please enter a valid positive exchange rate value.");
    return;
  }
  const profile = currentProfiles.find((p) => p.id === activeProfileId);
  if (profile) {
    profile.rates[`${from}_${to}`] = rate;
    profile.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    inputPairRate.value = "";
    renderRatesTable();
    showStatus(`Saved 1 ${from} = ${rate} ${to}`);
  }
});
btnImportBulk.addEventListener("click", () => {
  const rawText = bulkRatesInput.value.trim();
  if (!rawText)
    return;
  const target = defaultTargetSelect.value || "INR";
  const parsed = exchangeRateService.parseBulkRatesText(rawText, target);
  if (parsed.length === 0) {
    alert("Could not parse any valid rates. Example formats:\n1 EUR = 94.70 INR\nUSD = 87.12 INR\nEUR,INR,94.70");
    return;
  }
  const profile = currentProfiles.find((p) => p.id === activeProfileId);
  if (profile) {
    for (const item of parsed) {
      profile.rates[`${item.from}_${item.to}`] = item.rate;
    }
    profile.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    renderRatesTable();
    importCountMsg.textContent = `\u2713 Imported ${parsed.length} rates successfully!`;
    bulkRatesInput.value = "";
    setTimeout(() => importCountMsg.textContent = "", 4e3);
  }
});
btnSaveAll.addEventListener("click", async () => {
  const sync = await chrome.storage.sync.get("preferences");
  const prefs = sync.preferences || { ...APP_CONFIG.defaultPreferences };
  prefs.defaultTargetCurrency = defaultTargetSelect.value;
  prefs.precision = parseInt(precisionSelect.value, 10);
  prefs.rateMode = currentMode;
  prefs.activeProfileId = activeProfileId;
  await chrome.storage.sync.set({
    rateMode: currentMode,
    activeProfileId,
    rateProfiles: currentProfiles,
    preferences: prefs
  });
  chrome.runtime.sendMessage({
    type: "SAVE_RATE_PROFILES",
    data: {
      profiles: currentProfiles,
      activeProfileId,
      rateMode: currentMode
    }
  });
  showStatus("All Dual Engine rates and settings saved!");
});
function showStatus(msg) {
  statusAlert.textContent = msg;
  statusAlert.style.display = "block";
  setTimeout(() => statusAlert.style.display = "none", 3e3);
}
populateCurrencyDropdowns();
loadAllSettings();
//# sourceMappingURL=options.js.map
