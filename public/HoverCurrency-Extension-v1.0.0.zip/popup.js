// ../shared/dist/currencies/index.js
var CURRENCIES = {
  USD: { code: "USD", name: "US Dollar", symbol: "$", flag: "\u{1F1FA}\u{1F1F8}", decimalDigits: 2, countries: ["US"] },
  EUR: { code: "EUR", name: "Euro", symbol: "\u20AC", flag: "\u{1F1EA}\u{1F1FA}", decimalDigits: 2, countries: ["DE", "FR", "IT", "ES", "NL", "BE", "AT", "IE", "FI", "PT", "GR"] },
  GBP: { code: "GBP", name: "British Pound", symbol: "\xA3", flag: "\u{1F1EC}\u{1F1E7}", decimalDigits: 2, countries: ["GB"] },
  INR: { code: "INR", name: "Indian Rupee", symbol: "\u20B9", flag: "\u{1F1EE}\u{1F1F3}", decimalDigits: 2, countries: ["IN"] },
  JPY: { code: "JPY", name: "Japanese Yen", symbol: "\xA5", nativeSymbol: "\uFFE5", flag: "\u{1F1EF}\u{1F1F5}", decimalDigits: 0, countries: ["JP"] },
  CAD: { code: "CAD", name: "Canadian Dollar", symbol: "CA$", flag: "\u{1F1E8}\u{1F1E6}", decimalDigits: 2, countries: ["CA"] },
  AUD: { code: "AUD", name: "Australian Dollar", symbol: "A$", flag: "\u{1F1E6}\u{1F1FA}", decimalDigits: 2, countries: ["AU"] },
  CHF: { code: "CHF", name: "Swiss Franc", symbol: "CHF", flag: "\u{1F1E8}\u{1F1ED}", decimalDigits: 2, countries: ["CH", "LI"] },
  CNY: { code: "CNY", name: "Chinese Yuan", symbol: "CN\xA5", nativeSymbol: "\xA5", flag: "\u{1F1E8}\u{1F1F3}", decimalDigits: 2, countries: ["CN"] },
  AED: { code: "AED", name: "UAE Dirham", symbol: "AED", flag: "\u{1F1E6}\u{1F1EA}", decimalDigits: 2, countries: ["AE"] },
  AFN: { code: "AFN", name: "Afghan Afghani", symbol: "Af", flag: "\u{1F1E6}\u{1F1EB}", decimalDigits: 2, countries: ["AF"] },
  ALL: { code: "ALL", name: "Albanian Lek", symbol: "ALL", flag: "\u{1F1E6}\u{1F1F1}", decimalDigits: 2, countries: ["AL"] },
  AMD: { code: "AMD", name: "Armenian Dram", symbol: "AMD", flag: "\u{1F1E6}\u{1F1F2}", decimalDigits: 2, countries: ["AM"] },
  ANG: { code: "ANG", name: "NL Antillean Guilder", symbol: "ANG", flag: "\u{1F1E8}\u{1F1FC}", decimalDigits: 2, countries: ["CW", "SX"] },
  AOA: { code: "AOA", name: "Angolan Kwanza", symbol: "AOA", flag: "\u{1F1E6}\u{1F1F4}", decimalDigits: 2, countries: ["AO"] },
  ARS: { code: "ARS", name: "Argentine Peso", symbol: "AR$", flag: "\u{1F1E6}\u{1F1F7}", decimalDigits: 2, countries: ["AR"] },
  AZN: { code: "AZN", name: "Azerbaijani Manat", symbol: "man.", flag: "\u{1F1E6}\u{1F1FF}", decimalDigits: 2, countries: ["AZ"] },
  BAM: { code: "BAM", name: "Bosnia-Herzegovina Mark", symbol: "KM", flag: "\u{1F1E7}\u{1F1E6}", decimalDigits: 2, countries: ["BA"] },
  BBD: { code: "BBD", name: "Barbados Dollar", symbol: "BBD", flag: "\u{1F1E7}\u{1F1E7}", decimalDigits: 2, countries: ["BB"] },
  BDT: { code: "BDT", name: "Bangladeshi Taka", symbol: "\u09F3", flag: "\u{1F1E7}\u{1F1E9}", decimalDigits: 2, countries: ["BD"] },
  BGN: { code: "BGN", name: "Bulgarian Lev", symbol: "BGN", flag: "\u{1F1E7}\u{1F1EC}", decimalDigits: 2, countries: ["BG"] },
  BHD: { code: "BHD", name: "Bahraini Dinar", symbol: "BD", flag: "\u{1F1E7}\u{1F1ED}", decimalDigits: 3, countries: ["BH"] },
  BIF: { code: "BIF", name: "Burundian Franc", symbol: "FBu", flag: "\u{1F1E7}\u{1F1EE}", decimalDigits: 0, countries: ["BI"] },
  BMD: { code: "BMD", name: "Bermudian Dollar", symbol: "BMD", flag: "\u{1F1E7}\u{1F1F2}", decimalDigits: 2, countries: ["BM"] },
  BND: { code: "BND", name: "Brunei Dollar", symbol: "BN$", flag: "\u{1F1E7}\u{1F1F3}", decimalDigits: 2, countries: ["BN"] },
  BOB: { code: "BOB", name: "Bolivian Boliviano", symbol: "Bs", flag: "\u{1F1E7}\u{1F1F4}", decimalDigits: 2, countries: ["BO"] },
  BRL: { code: "BRL", name: "Brazilian Real", symbol: "R$", flag: "\u{1F1E7}\u{1F1F7}", decimalDigits: 2, countries: ["BR"] },
  BSD: { code: "BSD", name: "Bahamian Dollar", symbol: "BSD", flag: "\u{1F1E7}\u{1F1F8}", decimalDigits: 2, countries: ["BS"] },
  BTN: { code: "BTN", name: "Bhutanese Ngultrum", symbol: "Nu.", flag: "\u{1F1E7}\u{1F1F9}", decimalDigits: 2, countries: ["BT"] },
  BWP: { code: "BWP", name: "Botswana Pula", symbol: "BWP", flag: "\u{1F1E7}\u{1F1FC}", decimalDigits: 2, countries: ["BW"] },
  BYN: { code: "BYN", name: "Belarusian Ruble", symbol: "Br", flag: "\u{1F1E7}\u{1F1FE}", decimalDigits: 2, countries: ["BY"] },
  BZD: { code: "BZD", name: "Belize Dollar", symbol: "BZ$", flag: "\u{1F1E7}\u{1F1FF}", decimalDigits: 2, countries: ["BZ"] },
  CDF: { code: "CDF", name: "Congolese Franc", symbol: "CDF", flag: "\u{1F1E8}\u{1F1E9}", decimalDigits: 2, countries: ["CD"] },
  CLP: { code: "CLP", name: "Chilean Peso", symbol: "CL$", flag: "\u{1F1E8}\u{1F1F1}", decimalDigits: 0, countries: ["CL"] },
  COP: { code: "COP", name: "Colombian Peso", symbol: "CO$", flag: "\u{1F1E8}\u{1F1F4}", decimalDigits: 2, countries: ["CO"] },
  CRC: { code: "CRC", name: "Costa Rican Col\xF3n", symbol: "\u20A1", flag: "\u{1F1E8}\u{1F1F7}", decimalDigits: 2, countries: ["CR"] },
  CUP: { code: "CUP", name: "Cuban Peso", symbol: "CUP", flag: "\u{1F1E8}\u{1F1FA}", decimalDigits: 2, countries: ["CU"] },
  CVE: { code: "CVE", name: "Cape Verdean Escudo", symbol: "CV$", flag: "\u{1F1E8}\u{1F1FB}", decimalDigits: 2, countries: ["CV"] },
  CZK: { code: "CZK", name: "Czech Koruna", symbol: "K\u010D", flag: "\u{1F1E8}\u{1F1FF}", decimalDigits: 2, countries: ["CZ"] },
  DJF: { code: "DJF", name: "Djiboutian Franc", symbol: "Fdj", flag: "\u{1F1E9}\u{1F1EF}", decimalDigits: 0, countries: ["DJ"] },
  DKK: { code: "DKK", name: "Danish Krone", symbol: "kr", flag: "\u{1F1E9}\u{1F1F0}", decimalDigits: 2, countries: ["DK", "GL", "FO"] },
  DOP: { code: "DOP", name: "Dominican Peso", symbol: "RD$", flag: "\u{1F1E9}\u{1F1F4}", decimalDigits: 2, countries: ["DO"] },
  DZD: { code: "DZD", name: "Algerian Dinar", symbol: "DA", flag: "\u{1F1E9}\u{1F1FF}", decimalDigits: 2, countries: ["DZ"] },
  EGP: { code: "EGP", name: "Egyptian Pound", symbol: "EGP", flag: "\u{1F1EA}\u{1F1EC}", decimalDigits: 2, countries: ["EG"] },
  ERN: { code: "ERN", name: "Eritrean Nakfa", symbol: "Nfk", flag: "\u{1F1EA}\u{1F1F7}", decimalDigits: 2, countries: ["ER"] },
  ETB: { code: "ETB", name: "Ethiopian Birr", symbol: "Br", flag: "\u{1F1EA}\u{1F1F9}", decimalDigits: 2, countries: ["ET"] },
  FJD: { code: "FJD", name: "Fijian Dollar", symbol: "FJ$", flag: "\u{1F1EB}\u{1F1EF}", decimalDigits: 2, countries: ["FJ"] },
  FKP: { code: "FKP", name: "Falkland Islands Pound", symbol: "FK\xA3", flag: "\u{1F1EB}\u{1F1F0}", decimalDigits: 2, countries: ["FK"] },
  GEL: { code: "GEL", name: "Georgian Lari", symbol: "\u20BE", flag: "\u{1F1EC}\u{1F1EA}", decimalDigits: 2, countries: ["GE"] },
  GHS: { code: "GHS", name: "Ghanaian Cedi", symbol: "GH\u20B5", flag: "\u{1F1EC}\u{1F1ED}", decimalDigits: 2, countries: ["GH"] },
  GIP: { code: "GIP", name: "Gibraltar Pound", symbol: "\xA3", flag: "\u{1F1EC}\u{1F1EE}", decimalDigits: 2, countries: ["GI"] },
  GMD: { code: "GMD", name: "Gambian Dalasi", symbol: "D", flag: "\u{1F1EC}\u{1F1F2}", decimalDigits: 2, countries: ["GM"] },
  GNF: { code: "GNF", name: "Guinean Franc", symbol: "FG", flag: "\u{1F1EC}\u{1F1F3}", decimalDigits: 0, countries: ["GN"] },
  GTQ: { code: "GTQ", name: "Guatemalan Quetzal", symbol: "Q", flag: "\u{1F1EC}\u{1F1F9}", decimalDigits: 2, countries: ["GT"] },
  GYD: { code: "GYD", name: "Guyanaese Dollar", symbol: "GY$", flag: "\u{1F1EC}\u{1F1FE}", decimalDigits: 2, countries: ["GY"] },
  HKD: { code: "HKD", name: "Hong Kong Dollar", symbol: "HK$", flag: "\u{1F1ED}\u{1F1F0}", decimalDigits: 2, countries: ["HK"] },
  HNL: { code: "HNL", name: "Honduran Lempira", symbol: "L", flag: "\u{1F1ED}\u{1F1F3}", decimalDigits: 2, countries: ["HN"] },
  HRK: { code: "HRK", name: "Croatian Kuna", symbol: "kn", flag: "\u{1F1ED}\u{1F1F7}", decimalDigits: 2, countries: ["HR"] },
  HTG: { code: "HTG", name: "Haitian Gourde", symbol: "G", flag: "\u{1F1ED}\u{1F1F9}", decimalDigits: 2, countries: ["HT"] },
  HUF: { code: "HUF", name: "Hungarian Forint", symbol: "Ft", flag: "\u{1F1ED}\u{1F1FA}", decimalDigits: 0, countries: ["HU"] },
  IDR: { code: "IDR", name: "Indonesian Rupiah", symbol: "Rp", flag: "\u{1F1EE}\u{1F1E9}", decimalDigits: 0, countries: ["ID"] },
  ILS: { code: "ILS", name: "Israeli New Shekel", symbol: "\u20AA", flag: "\u{1F1EE}\u{1F1F1}", decimalDigits: 2, countries: ["IL"] },
  IQD: { code: "IQD", name: "Iraqi Dinar", symbol: "IQD", flag: "\u{1F1EE}\u{1F1F6}", decimalDigits: 3, countries: ["IQ"] },
  IRR: { code: "IRR", name: "Iranian Rial", symbol: "IRR", flag: "\u{1F1EE}\u{1F1F7}", decimalDigits: 0, countries: ["IR"] },
  ISK: { code: "ISK", name: "Icelandic Kr\xF3na", symbol: "kr", flag: "\u{1F1EE}\u{1F1F8}", decimalDigits: 0, countries: ["IS"] },
  JMD: { code: "JMD", name: "Jamaican Dollar", symbol: "J$", flag: "\u{1F1EF}\u{1F1F2}", decimalDigits: 2, countries: ["JM"] },
  JOD: { code: "JOD", name: "Jordanian Dinar", symbol: "JD", flag: "\u{1F1EF}\u{1F1F4}", decimalDigits: 3, countries: ["JO"] },
  KES: { code: "KES", name: "Kenyan Shilling", symbol: "KSh", flag: "\u{1F1F0}\u{1F1EA}", decimalDigits: 2, countries: ["KE"] },
  KGS: { code: "KGS", name: "Kyrgystani Som", symbol: "KGS", flag: "\u{1F1F0}\u{1F1EC}", decimalDigits: 2, countries: ["KG"] },
  KHR: { code: "KHR", name: "Cambodian Riel", symbol: "\u17DB", flag: "\u{1F1F0}\u{1F1ED}", decimalDigits: 2, countries: ["KH"] },
  KMF: { code: "KMF", name: "Comorian Franc", symbol: "CF", flag: "\u{1F1F0}\u{1F1F2}", decimalDigits: 0, countries: ["KM"] },
  KRW: { code: "KRW", name: "South Korean Won", symbol: "\u20A9", flag: "\u{1F1F0}\u{1F1F7}", decimalDigits: 0, countries: ["KR"] },
  KWD: { code: "KWD", name: "Kuwaiti Dinar", symbol: "KD", flag: "\u{1F1F0}\u{1F1FC}", decimalDigits: 3, countries: ["KW"] },
  KYD: { code: "KYD", name: "Cayman Islands Dollar", symbol: "CI$", flag: "\u{1F1F0}\u{1F1FE}", decimalDigits: 2, countries: ["KY"] },
  KZT: { code: "KZT", name: "Kazakhstani Tenge", symbol: "\u20B8", flag: "\u{1F1F0}\u{1F1FF}", decimalDigits: 2, countries: ["KZ"] },
  LAK: { code: "LAK", name: "Laotian Kip", symbol: "\u20AD", flag: "\u{1F1F1}\u{1F1E6}", decimalDigits: 0, countries: ["LA"] },
  LBP: { code: "LBP", name: "Lebanese Pound", symbol: "LB\xA3", flag: "\u{1F1F1}\u{1F1E7}", decimalDigits: 0, countries: ["LB"] },
  LKR: { code: "LKR", name: "Sri Lankan Rupee", symbol: "SLRs", flag: "\u{1F1F1}\u{1F1F0}", decimalDigits: 2, countries: ["LK"] },
  LRD: { code: "LRD", name: "Liberian Dollar", symbol: "L$", flag: "\u{1F1F1}\u{1F1F7}", decimalDigits: 2, countries: ["LR"] },
  LSL: { code: "LSL", name: "Lesotho Loti", symbol: "LSL", flag: "\u{1F1F1}\u{1F1F8}", decimalDigits: 2, countries: ["LS"] },
  LYD: { code: "LYD", name: "Libyan Dinar", symbol: "LD", flag: "\u{1F1F1}\u{1F1FE}", decimalDigits: 3, countries: ["LY"] },
  MAD: { code: "MAD", name: "Moroccan Dirham", symbol: "MAD", flag: "\u{1F1F2}\u{1F1E6}", decimalDigits: 2, countries: ["MA", "EH"] },
  MDL: { code: "MDL", name: "Moldovan Leu", symbol: "MDL", flag: "\u{1F1F2}\u{1F1E9}", decimalDigits: 2, countries: ["MD"] },
  MGA: { code: "MGA", name: "Malagasy Ariary", symbol: "MGA", flag: "\u{1F1F2}\u{1F1EC}", decimalDigits: 0, countries: ["MG"] },
  MKD: { code: "MKD", name: "Macedonian Denar", symbol: "MKD", flag: "\u{1F1F2}\u{1F1F0}", decimalDigits: 2, countries: ["MK"] },
  MMK: { code: "MMK", name: "Myanma Kyat", symbol: "MMK", flag: "\u{1F1F2}\u{1F1F2}", decimalDigits: 0, countries: ["MM"] },
  MNT: { code: "MNT", name: "Mongolian Tugrik", symbol: "\u20AE", flag: "\u{1F1F2}\u{1F1F3}", decimalDigits: 2, countries: ["MN"] },
  MOP: { code: "MOP", name: "Macanese Pataca", symbol: "MOP$", flag: "\u{1F1F2}\u{1F1F4}", decimalDigits: 2, countries: ["MO"] },
  MRU: { code: "MRU", name: "Mauritanian Ouguiya", symbol: "MRU", flag: "\u{1F1F2}\u{1F1F7}", decimalDigits: 2, countries: ["MR"] },
  MUR: { code: "MUR", name: "Mauritian Rupee", symbol: "MURs", flag: "\u{1F1F2}\u{1F1FA}", decimalDigits: 2, countries: ["MU"] },
  MVR: { code: "MVR", name: "Maldivian Rufiyaa", symbol: "Rf", flag: "\u{1F1F2}\u{1F1FB}", decimalDigits: 2, countries: ["MV"] },
  MWK: { code: "MWK", name: "Malawian Kwacha", symbol: "MK", flag: "\u{1F1F2}\u{1F1FC}", decimalDigits: 2, countries: ["MW"] },
  MXN: { code: "MXN", name: "Mexican Peso", symbol: "MX$", flag: "\u{1F1F2}\u{1F1FD}", decimalDigits: 2, countries: ["MX"] },
  MYR: { code: "MYR", name: "Malaysian Ringgit", symbol: "RM", flag: "\u{1F1F2}\u{1F1FE}", decimalDigits: 2, countries: ["MY"] },
  MZN: { code: "MZN", name: "Mozambican Metical", symbol: "MTn", flag: "\u{1F1F2}\u{1F1FF}", decimalDigits: 2, countries: ["MZ"] },
  NAD: { code: "NAD", name: "Namibian Dollar", symbol: "N$", flag: "\u{1F1F3}\u{1F1E6}", decimalDigits: 2, countries: ["NA"] },
  NGN: { code: "NGN", name: "Nigerian Naira", symbol: "\u20A6", flag: "\u{1F1F3}\u{1F1EC}", decimalDigits: 2, countries: ["NG"] },
  NIO: { code: "NIO", name: "Nicaraguan C\xF3rdoba", symbol: "C$", flag: "\u{1F1F3}\u{1F1EE}", decimalDigits: 2, countries: ["NI"] },
  NOK: { code: "NOK", name: "Norwegian Krone", symbol: "kr", flag: "\u{1F1F3}\u{1F1F4}", decimalDigits: 2, countries: ["NO", "SJ"] },
  NPR: { code: "NPR", name: "Nepalese Rupee", symbol: "NPRs", flag: "\u{1F1F3}\u{1F1F5}", decimalDigits: 2, countries: ["NP"] },
  NZD: { code: "NZD", name: "New Zealand Dollar", symbol: "NZ$", flag: "\u{1F1F3}\u{1F1FF}", decimalDigits: 2, countries: ["NZ", "CK", "NU", "PN"] },
  OMR: { code: "OMR", name: "Omani Rial", symbol: "OMR", flag: "\u{1F1F4}\u{1F1F2}", decimalDigits: 3, countries: ["OM"] },
  PAB: { code: "PAB", name: "Panamanian Balboa", symbol: "B/.", flag: "\u{1F1F5}\u{1F1E6}", decimalDigits: 2, countries: ["PA"] },
  PEN: { code: "PEN", name: "Peruvian Nuevo Sol", symbol: "S/.", flag: "\u{1F1F5}\u{1F1EA}", decimalDigits: 2, countries: ["PE"] },
  PGK: { code: "PGK", name: "Papua New Guinean Kina", symbol: "K", flag: "\u{1F1F5}\u{1F1EC}", decimalDigits: 2, countries: ["PG"] },
  PHP: { code: "PHP", name: "Philippine Peso", symbol: "\u20B1", flag: "\u{1F1F5}\u{1F1ED}", decimalDigits: 2, countries: ["PH"] },
  PKR: { code: "PKR", name: "Pakistani Rupee", symbol: "PKRs", flag: "\u{1F1F5}\u{1F1F0}", decimalDigits: 2, countries: ["PK"] },
  PLN: { code: "PLN", name: "Polish Zloty", symbol: "z\u0142", flag: "\u{1F1F5}\u{1F1F1}", decimalDigits: 2, countries: ["PL"] },
  PYG: { code: "PYG", name: "Paraguayan Guarani", symbol: "\u20B2", flag: "\u{1F1F5}\u{1F1FE}", decimalDigits: 0, countries: ["PY"] },
  QAR: { code: "QAR", name: "Qatari Rial", symbol: "QR", flag: "\u{1F1F6}\u{1F1E6}", decimalDigits: 2, countries: ["QA"] },
  RON: { code: "RON", name: "Romanian Leu", symbol: "RON", flag: "\u{1F1F7}\u{1F1F4}", decimalDigits: 2, countries: ["RO"] },
  RSD: { code: "RSD", name: "Serbian Dinar", symbol: "din.", flag: "\u{1F1F7}\u{1F1F8}", decimalDigits: 2, countries: ["RS"] },
  RUB: { code: "RUB", name: "Russian Ruble", symbol: "\u20BD", flag: "\u{1F1F7}\u{1F1FA}", decimalDigits: 2, countries: ["RU"] },
  RWF: { code: "RWF", name: "Rwandan Franc", symbol: "RWF", flag: "\u{1F1F7}\u{1F1FC}", decimalDigits: 0, countries: ["RW"] },
  SAR: { code: "SAR", name: "Saudi Riyal", symbol: "SR", flag: "\u{1F1F8}\u{1F1E6}", decimalDigits: 2, countries: ["SA"] },
  SBD: { code: "SBD", name: "Solomon Islands Dollar", symbol: "SI$", flag: "\u{1F1F8}\u{1F1E7}", decimalDigits: 2, countries: ["SB"] },
  SCR: { code: "SCR", name: "Seychellois Rupee", symbol: "SRe", flag: "\u{1F1F8}\u{1F1E8}", decimalDigits: 2, countries: ["SC"] },
  SDG: { code: "SDG", name: "Sudanese Pound", symbol: "SDG", flag: "\u{1F1F8}\u{1F1E9}", decimalDigits: 2, countries: ["SD"] },
  SEK: { code: "SEK", name: "Swedish Krona", symbol: "kr", flag: "\u{1F1F8}\u{1F1EA}", decimalDigits: 2, countries: ["SE"] },
  SGD: { code: "SGD", name: "Singapore Dollar", symbol: "S$", flag: "\u{1F1F8}\u{1F1EC}", decimalDigits: 2, countries: ["SG"] },
  SHP: { code: "SHP", name: "Saint Helena Pound", symbol: "\xA3", flag: "\u{1F1F8}\u{1F1ED}", decimalDigits: 2, countries: ["SH"] },
  SLL: { code: "SLL", name: "Sierra Leonean Leone", symbol: "Le", flag: "\u{1F1F8}\u{1F1F1}", decimalDigits: 2, countries: ["SL"] },
  SOS: { code: "SOS", name: "Somali Shilling", symbol: "Ssh", flag: "\u{1F1F8}\u{1F1F4}", decimalDigits: 2, countries: ["SO"] },
  SRD: { code: "SRD", name: "Surinamese Dollar", symbol: "$", flag: "\u{1F1F8}\u{1F1F7}", decimalDigits: 2, countries: ["SR"] },
  STN: { code: "STN", name: "S\xE3o Tom\xE9 and Pr\xEDncipe Dobra", symbol: "Db", flag: "\u{1F1F8}\u{1F1F9}", decimalDigits: 2, countries: ["ST"] },
  SYP: { code: "SYP", name: "Syrian Pound", symbol: "SY\xA3", flag: "\u{1F1F8}\u{1F1FE}", decimalDigits: 2, countries: ["SY"] },
  SZL: { code: "SZL", name: "Swazi Lilangeni", symbol: "SZL", flag: "\u{1F1F8}\u{1F1FF}", decimalDigits: 2, countries: ["SZ"] },
  THB: { code: "THB", name: "Thai Baht", symbol: "\u0E3F", flag: "\u{1F1F9}\u{1F1ED}", decimalDigits: 2, countries: ["TH"] },
  TJS: { code: "TJS", name: "Tajikistani Somoni", symbol: "TJS", flag: "\u{1F1F9}\u{1F1EF}", decimalDigits: 2, countries: ["TJ"] },
  TMT: { code: "TMT", name: "Turkmenistani Manat", symbol: "TMT", flag: "\u{1F1F9}\u{1F1F2}", decimalDigits: 2, countries: ["TM"] },
  TND: { code: "TND", name: "Tunisian Dinar", symbol: "DT", flag: "\u{1F1F9}\u{1F1F3}", decimalDigits: 3, countries: ["TN"] },
  TOP: { code: "TOP", name: "Tongan Pa\u02BBanga", symbol: "T$", flag: "\u{1F1F9}\u{1F1F4}", decimalDigits: 2, countries: ["TO"] },
  TRY: { code: "TRY", name: "Turkish Lira", symbol: "\u20BA", flag: "\u{1F1F9}\u{1F1F7}", decimalDigits: 2, countries: ["TR"] },
  TTD: { code: "TTD", name: "Trinidad and Tobago Dollar", symbol: "TT$", flag: "\u{1F1F9}\u{1F1F9}", decimalDigits: 2, countries: ["TT"] },
  TWD: { code: "TWD", name: "New Taiwan Dollar", symbol: "NT$", flag: "\u{1F1F9}\u{1F1FC}", decimalDigits: 2, countries: ["TW"] },
  TZS: { code: "TZS", name: "Tanzanian Shilling", symbol: "TSh", flag: "\u{1F1F9}\u{1F1FF}", decimalDigits: 2, countries: ["TZ"] },
  UAH: { code: "UAH", name: "Ukrainian Hryvnia", symbol: "\u20B4", flag: "\u{1F1FA}\u{1F1E6}", decimalDigits: 2, countries: ["UA"] },
  UGX: { code: "UGX", name: "Ugandan Shilling", symbol: "USh", flag: "\u{1F1FA}\u{1F1EC}", decimalDigits: 0, countries: ["UG"] },
  UYU: { code: "UYU", name: "Uruguayan Peso", symbol: "$U", flag: "\u{1F1FA}\u{1F1FE}", decimalDigits: 2, countries: ["UY"] },
  UZS: { code: "UZS", name: "Uzbekistan Som", symbol: "UZS", flag: "\u{1F1FA}\u{1F1FF}", decimalDigits: 2, countries: ["UZ"] },
  VES: { code: "VES", name: "Venezuelan Bol\xEDvar", symbol: "Bs.S", flag: "\u{1F1FB}\u{1F1EA}", decimalDigits: 2, countries: ["VE"] },
  VND: { code: "VND", name: "Vietnamese Dong", symbol: "\u20AB", flag: "\u{1F1FB}\u{1F1F3}", decimalDigits: 0, countries: ["VN"] },
  VUV: { code: "VUV", name: "Vanuatu Vatu", symbol: "VT", flag: "\u{1F1FB}\u{1F1FA}", decimalDigits: 0, countries: ["VU"] },
  WST: { code: "WST", name: "Samoan Tala", symbol: "WS$", flag: "\u{1F1FC}\u{1F1F8}", decimalDigits: 2, countries: ["WS"] },
  XAF: { code: "XAF", name: "Central African CFA Franc", symbol: "FCFA", flag: "\u{1F1E8}\u{1F1F2}", decimalDigits: 0, countries: ["CM", "CF", "TD", "CG", "GQ", "GA"] },
  XCD: { code: "XCD", name: "East Caribbean Dollar", symbol: "EC$", flag: "\u{1F1E6}\u{1F1EC}", decimalDigits: 2, countries: ["AG", "DM", "GD", "KN", "LC", "VC"] },
  XOF: { code: "XOF", name: "West African CFA Franc", symbol: "CFA", flag: "\u{1F1F8}\u{1F1F3}", decimalDigits: 0, countries: ["SN", "CI", "ML", "BF", "NE", "TG", "BJ", "GW"] },
  XPF: { code: "XPF", name: "CFP Franc", symbol: "CFPF", flag: "\u{1F1F5}\u{1F1EB}", decimalDigits: 0, countries: ["PF", "NC", "WF"] },
  YER: { code: "YER", name: "Yemeni Rial", symbol: "YR", flag: "\u{1F1FE}\u{1F1EA}", decimalDigits: 2, countries: ["YE"] },
  ZAR: { code: "ZAR", name: "South African Rand", symbol: "R", flag: "\u{1F1FF}\u{1F1E6}", decimalDigits: 2, countries: ["ZA"] },
  ZMW: { code: "ZMW", name: "Zambian Kwacha", symbol: "ZK", flag: "\u{1F1FF}\u{1F1F2}", decimalDigits: 2, countries: ["ZM"] },
  ZWL: { code: "ZWL", name: "Zimbabwean Dollar", symbol: "ZWL", flag: "\u{1F1FF}\u{1F1FC}", decimalDigits: 2, countries: ["ZW"] }
};
var POPULAR_CURRENCIES = ["USD", "EUR", "GBP", "INR", "JPY", "CAD", "AUD", "CHF", "CNY", "BRL", "SGD", "AED"];
function getCurrency(code) {
  return CURRENCIES[code.toUpperCase()] || {
    code: code.toUpperCase(),
    name: code.toUpperCase(),
    symbol: code.toUpperCase(),
    flag: "\u{1F310}",
    decimalDigits: 2,
    countries: []
  };
}
function formatCurrencyAmount(amount, currencyCode, options = {}) {
  const meta = getCurrency(currencyCode);
  const precision = options.precision ?? meta.decimalDigits;
  const locale = options.locale ?? "en-US";
  const isNegative = amount < 0;
  const absAmount = Math.abs(amount);
  try {
    const formattedNum = new Intl.NumberFormat(locale, {
      minimumFractionDigits: precision,
      maximumFractionDigits: precision
    }).format(absAmount);
    if (options.showSymbol !== false) {
      return isNegative ? `-${meta.symbol}${formattedNum}` : `${meta.symbol}${formattedNum}`;
    }
    return isNegative ? `-${formattedNum}` : formattedNum;
  } catch {
    const fallbackFormatted = absAmount.toFixed(precision);
    if (options.showSymbol !== false) {
      return isNegative ? `-${meta.symbol}${fallbackFormatted}` : `${meta.symbol}${fallbackFormatted}`;
    }
    return isNegative ? `-${fallbackFormatted}` : fallbackFormatted;
  }
}

// ../shared/dist/detector/price-parser.js
var CURRENCY_SYMBOLS_REGEX = "[$\u20AC\xA3\u20B9\xA5\uFFE5\u20BD\u20A9\u20BA\u20AB\u0E3F\u20B1\u20AA]|R\\$|CA\\$|A\\$|AU\\$|NZ\\$|HK\\$|S\\$|US\\$|kr|K\u010D|z\u0142|Ft|CHF|RM|Rp|\u09F3|\u20A8|Nu\\.|GH\u20B5|\u20A6|\u20A1|\u20B2|\u20B4";
var CURRENCY_CODES_REGEX = Object.keys(CURRENCIES).join("|");
var NUM_PATTERN = "\\d{1,3}(?:[.,\\s]\\d{3})*(?:[.,]\\d{1,4})?|\\d+(?:[.,]\\d{1,4})?";
var REGEX_SYMBOL_PREFIX = new RegExp(`(?<!\\w)(${CURRENCY_SYMBOLS_REGEX})\\s*(${NUM_PATTERN})(?!\\w)`, "i");
var REGEX_SYMBOL_SUFFIX = new RegExp(`(?<!\\w)(${NUM_PATTERN})\\s*(${CURRENCY_SYMBOLS_REGEX})(?!\\w)`, "i");
var REGEX_CODE_PREFIX = new RegExp(`(?<![a-zA-Z])(${CURRENCY_CODES_REGEX})\\s+(${NUM_PATTERN})(?!\\w)`, "i");
var REGEX_CODE_SUFFIX = new RegExp(`(?<!\\w)(${NUM_PATTERN})\\s+(${CURRENCY_CODES_REGEX})(?![a-zA-Z])`, "i");

// ../shared/dist/config/index.js
var DEFAULT_PERSONAL_RATE = {
  baseCurrency: "USD",
  targetCurrency: "INR",
  rate: 87.12,
  lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
  dailyReminderEnabled: true,
  additionalRates: {
    "EUR_INR": 94.7,
    "GBP_INR": 110.5,
    "JPY_INR": 0.58,
    "CAD_INR": 63.5,
    "AUD_INR": 57.8
  },
  savedPairs: [
    {
      id: "USD_INR",
      baseCurrency: "USD",
      targetCurrency: "INR",
      rate: 87.12,
      lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
      isActive: true
    }
  ]
};
var DEFAULT_RATE_PROFILES = [
  {
    id: "prof_personal",
    name: "Personal Rate",
    description: "Custom rates obtained from Google for personal purchases and budgeting",
    baseCurrency: "INR",
    rates: {
      "USD_INR": 87.12,
      "EUR_INR": 94.7,
      "GBP_INR": 110.5,
      "JPY_INR": 0.58,
      "CAD_INR": 63.5,
      "AUD_INR": 57.8,
      "AED_INR": 23.75,
      "SGD_INR": 65.2
    },
    isDefault: true,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "prof_bank",
    name: "Bank Exchange Rate",
    description: "Typical credit card and bank foreign exchange rate with 2-3% spread",
    baseCurrency: "INR",
    rates: {
      "USD_INR": 89.5,
      "EUR_INR": 97.2,
      "GBP_INR": 113.8,
      "JPY_INR": 0.6,
      "CAD_INR": 65.2,
      "AUD_INR": 59.4,
      "AED_INR": 24.4,
      "SGD_INR": 67
    },
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "prof_business",
    name: "Business Rate",
    description: "Corporate accounting and invoice valuation rates",
    baseCurrency: "USD",
    rates: {
      "USD_EUR": 0.92,
      "USD_GBP": 0.79,
      "USD_INR": 87,
      "USD_JPY": 154,
      "USD_CAD": 1.38,
      "USD_AUD": 1.52
    },
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "prof_travel",
    name: "Travel Rate",
    description: "Cash airport exchange and kiosk rates for holiday trips",
    baseCurrency: "INR",
    rates: {
      "USD_INR": 90,
      "EUR_INR": 98,
      "GBP_INR": 115,
      "JPY_INR": 0.62,
      "AED_INR": 25,
      "THB_INR": 2.65
    },
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "prof_custom",
    name: "Custom Rate",
    description: "User-defined direct currency pairs and overrides",
    rates: {
      "EUR_INR": 94.7,
      "USD_INR": 87.12
    },
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  }
];
var DEFAULT_DUAL_RATE_CONFIG = {
  mode: "manual",
  // Default to personal manual rate engine
  activeProfileId: "prof_personal",
  profiles: DEFAULT_RATE_PROFILES,
  fallbackToAutomaticOnError: false
};
var APP_CONFIG = {
  appName: "HoverCurrency",
  appTagline: "Instant Hover-to-Convert Currency Ecosystem",
  websiteUrl: "https://currenceconverter.me",
  apiUrl: "http://localhost:3000/api",
  plans: {
    free: {
      name: "Free",
      price: 0,
      monthlyConversionsLimit: 29,
      features: [
        "29 successful conversions per month",
        "Personal exchange rate system (Google rate entry)",
        "Hover-to-convert engine on all websites",
        "Daily update reminders & stale rate alerts",
        "Target currency selection (160+ currencies)",
        "Usage counter & reset tracker"
      ]
    },
    pro: {
      name: "Pro",
      price: 9,
      interval: "3 months",
      intervalCount: 3,
      monthlyConversionsLimit: Infinity,
      features: [
        "Unlimited currency conversions",
        "Unlimited hover-to-convert usage",
        "Premium rate profiles (Personal, Bank, Business, Travel)",
        "Cross-device browser sync",
        "Priority 24/7 support",
        "No conversion limits"
      ]
    }
  },
  defaultPreferences: {
    defaultBaseCurrency: "USD",
    defaultTargetCurrency: "INR",
    hoverEnabled: true,
    tooltipTheme: "dark",
    precision: 2,
    autoDetectSource: true,
    excludedDomains: [
      "paypal.com",
      "chase.com",
      "bankofamerica.com",
      "wellsfargo.com"
    ],
    showRateTimestamp: true,
    rateMode: "manual",
    activeProfileId: "prof_personal"
  },
  personalRate: DEFAULT_PERSONAL_RATE,
  dualRateEngine: DEFAULT_DUAL_RATE_CONFIG,
  dodoPayments: {
    sandboxUrl: "https://test.dodopayments.com",
    productionUrl: "https://api.dodopayments.com",
    defaultProductId: "p_quarterly_pro_9"
  }
};

// ../shared/dist/exchange-rate/rates.js
var MissingManualRateError = class extends Error {
  from;
  to;
  profileName;
  constructor(from, to, profileName = "Personal Rate") {
    super(`Exchange rate not available for ${from} \u2192 ${to} in "${profileName}". Please enter this rate manually from Google.`);
    this.name = "MissingManualRateError";
    this.from = from;
    this.to = to;
    this.profileName = profileName;
  }
};
var PersonalRateEngine = class _PersonalRateEngine {
  static instance;
  config = { ...DEFAULT_DUAL_RATE_CONFIG };
  personalRate = { ...DEFAULT_PERSONAL_RATE };
  // Built-in cached reference rates for Automatic Mode (offline / zero external API calls)
  automaticCache = {
    USD: 1,
    EUR: 0.92,
    GBP: 0.79,
    INR: 87.12,
    JPY: 154,
    CAD: 1.38,
    AUD: 1.52,
    CHF: 0.88,
    CNY: 7.24,
    AED: 3.67,
    SGD: 1.34,
    BRL: 5.75,
    MXN: 20.15,
    KRW: 1390,
    SEK: 10.9,
    NZD: 1.68
  };
  constructor() {
  }
  static getInstance() {
    if (!_PersonalRateEngine.instance) {
      _PersonalRateEngine.instance = new _PersonalRateEngine();
    }
    return _PersonalRateEngine.instance;
  }
  // Personal Rate Management
  getPersonalRate() {
    return { ...this.personalRate };
  }
  setPersonalRate(rateConfig) {
    this.personalRate = {
      ...this.personalRate,
      ...rateConfig,
      lastUpdated: rateConfig.lastUpdated || (/* @__PURE__ */ new Date()).toISOString()
    };
    return { ...this.personalRate };
  }
  isRateStale(lastUpdatedIso) {
    const ageMs = Date.now() - new Date(lastUpdatedIso).getTime();
    return ageMs >= 24 * 60 * 60 * 1e3;
  }
  getRateFreshness(lastUpdatedIso) {
    return this.isRateStale(lastUpdatedIso) ? "stale" : "fresh";
  }
  // Dual engine config
  getConfig() {
    return { ...this.config };
  }
  setMode(mode) {
    this.config.mode = mode;
  }
  getMode() {
    return this.config.mode;
  }
  setActiveProfile(profileId) {
    const exists = this.config.profiles.some((p) => p.id === profileId);
    if (exists) {
      this.config.activeProfileId = profileId;
    }
  }
  getActiveProfile() {
    const found = this.config.profiles.find((p) => p.id === this.config.activeProfileId);
    return found || this.config.profiles[0] || DEFAULT_RATE_PROFILES[0];
  }
  setProfiles(profiles) {
    this.config.profiles = profiles;
  }
  /**
   * Resolves rate using Personal Exchange Rate system:
   * 1. 1 USD = [savedRate] [targetCurrency]
   * 2. If USD -> Target: rate = savedRate
   * 3. If Target -> USD: rate = 1 / savedRate
   * 4. Additional rates from profile or personal config if explicitly configured
   * Never invents missing rates!
   */
  resolveRate(from, to, personalConfig = this.personalRate, profile) {
    const f = from.toUpperCase();
    const t = to.toUpperCase();
    const base = (personalConfig.baseCurrency || "USD").toUpperCase();
    const target = (personalConfig.targetCurrency || "INR").toUpperCase();
    const savedRate = personalConfig.rate;
    if (f === t) {
      return { rate: 1, isCustom: false, profileName: "Identical Pair" };
    }
    const prof = profile || this.getActiveProfile();
    const isSpecificProfile = prof && prof.id !== "prof_personal";
    const checkProfileRates = () => {
      if (!prof || !prof.rates)
        return null;
      const directKey = `${f}_${t}`;
      const inverseKey = `${t}_${f}`;
      if (prof.rates[directKey] !== void 0) {
        return { rate: prof.rates[directKey], isCustom: true, profileName: prof.name };
      }
      if (prof.rates[inverseKey] !== void 0 && prof.rates[inverseKey] > 0) {
        return { rate: 1 / prof.rates[inverseKey], isCustom: true, profileName: prof.name };
      }
      if (prof.baseCurrency) {
        const pb = prof.baseCurrency.toUpperCase();
        const pbToF = f === pb ? 1 : prof.rates[`${pb}_${f}`] ?? prof.rates[f] ?? (prof.rates[`${f}_${pb}`] ? 1 / prof.rates[`${f}_${pb}`] : void 0);
        const pbToT = t === pb ? 1 : prof.rates[`${pb}_${t}`] ?? prof.rates[t] ?? (prof.rates[`${t}_${pb}`] ? 1 / prof.rates[`${t}_${pb}`] : void 0);
        if (pbToF && pbToT && pbToF > 0) {
          return { rate: pbToT / pbToF, isCustom: true, profileName: prof.name };
        }
      }
      for (const key of Object.keys(prof.rates)) {
        if (key.startsWith(`${f}_`)) {
          const common = key.substring(f.length + 1);
          const matchT = prof.rates[`${t}_${common}`];
          if (matchT && matchT > 0) {
            return { rate: prof.rates[key] / matchT, isCustom: true, profileName: prof.name };
          }
        }
      }
      for (const key of Object.keys(prof.rates)) {
        if (key.endsWith(`_${f}`)) {
          const common = key.substring(0, key.length - f.length - 1);
          const matchT = prof.rates[`${common}_${t}`];
          if (matchT && matchT > 0 && prof.rates[key] > 0) {
            return { rate: matchT / prof.rates[key], isCustom: true, profileName: prof.name };
          }
        }
      }
      return null;
    };
    if (isSpecificProfile) {
      const fromProf = checkProfileRates();
      if (fromProf)
        return fromProf;
    }
    if (personalConfig.savedPairs && personalConfig.savedPairs.length > 0) {
      const directPair = personalConfig.savedPairs.find((p) => p.baseCurrency.toUpperCase() === f && p.targetCurrency.toUpperCase() === t && p.rate > 0);
      if (directPair) {
        return { rate: directPair.rate, isCustom: true, profileName: "Personal Rate" };
      }
      const inversePair = personalConfig.savedPairs.find((p) => p.baseCurrency.toUpperCase() === t && p.targetCurrency.toUpperCase() === f && p.rate > 0);
      if (inversePair) {
        return { rate: 1 / inversePair.rate, isCustom: true, profileName: "Personal Rate" };
      }
      for (const pairA of personalConfig.savedPairs) {
        const aBase = pairA.baseCurrency.toUpperCase();
        const aTarget = pairA.targetCurrency.toUpperCase();
        let fToBridge = null;
        let bridge = null;
        if (aBase === f && pairA.rate > 0) {
          bridge = aTarget;
          fToBridge = pairA.rate;
        } else if (aTarget === f && pairA.rate > 0) {
          bridge = aBase;
          fToBridge = 1 / pairA.rate;
        }
        if (bridge && fToBridge !== null) {
          for (const pairB of personalConfig.savedPairs) {
            const bBase = pairB.baseCurrency.toUpperCase();
            const bTarget = pairB.targetCurrency.toUpperCase();
            let bridgeToT = null;
            if (bBase === bridge && bTarget === t && pairB.rate > 0) {
              bridgeToT = pairB.rate;
            } else if (bTarget === bridge && bBase === t && pairB.rate > 0) {
              bridgeToT = 1 / pairB.rate;
            }
            if (bridgeToT !== null) {
              return { rate: fToBridge * bridgeToT, isCustom: true, profileName: "Personal Rate" };
            }
          }
        }
      }
    }
    if (f === base && t === target && savedRate > 0) {
      return { rate: savedRate, isCustom: true, profileName: "Personal Rate" };
    }
    if (f === target && t === base && savedRate > 0) {
      return { rate: 1 / savedRate, isCustom: true, profileName: "Personal Rate" };
    }
    if (personalConfig.additionalRates) {
      const directKey = `${f}_${t}`;
      const inverseKey = `${t}_${f}`;
      if (personalConfig.additionalRates[directKey] !== void 0) {
        return { rate: personalConfig.additionalRates[directKey], isCustom: true, profileName: "Personal Rate" };
      }
      if (personalConfig.additionalRates[inverseKey] !== void 0 && personalConfig.additionalRates[inverseKey] > 0) {
        return { rate: 1 / personalConfig.additionalRates[inverseKey], isCustom: true, profileName: "Personal Rate" };
      }
      const fToTarget = personalConfig.additionalRates[`${f}_${target}`];
      const tToTarget = personalConfig.additionalRates[`${t}_${target}`];
      if (fToTarget && tToTarget && tToTarget > 0) {
        return { rate: fToTarget / tToTarget, isCustom: true, profileName: "Personal Rate" };
      }
      const baseToF = personalConfig.additionalRates[`${base}_${f}`] ?? (f === base ? 1 : void 0);
      const baseToT = personalConfig.additionalRates[`${base}_${t}`] ?? (t === base ? 1 : t === target ? savedRate : void 0);
      if (baseToF && baseToT && baseToF > 0) {
        return { rate: baseToT / baseToF, isCustom: true, profileName: "Personal Rate" };
      }
    }
    if (!isSpecificProfile) {
      const fromProf = checkProfileRates();
      if (fromProf)
        return fromProf;
    }
    return null;
  }
  /**
   * Main Conversion Engine (No External Currency API)
   */
  async convert(amount, from, to, options = {}) {
    const fromCode = from.toUpperCase();
    const toCode = to.toUpperCase();
    const personal = options.personalRateConfig || this.personalRate;
    const profile = options.profileId ? this.config.profiles.find((p) => p.id === options.profileId) || this.getActiveProfile() : this.getActiveProfile();
    const fromMeta = getCurrency(fromCode);
    const toMeta = getCurrency(toCode);
    const fromPrecision = fromMeta.decimalDigits;
    const toPrecision = options.precision ?? toMeta.decimalDigits;
    const effectiveMode = options.mode || this.config.mode;
    if (effectiveMode === "automatic") {
      let autoRate = null;
      if (fromCode === toCode) {
        autoRate = 1;
      } else if (this.automaticCache[fromCode] && this.automaticCache[toCode]) {
        autoRate = this.automaticCache[toCode] / this.automaticCache[fromCode];
      }
      if (autoRate !== null && !isNaN(autoRate) && autoRate > 0) {
        const factor2 = Math.pow(10, toPrecision);
        const convertedAmount2 = Math.round((amount * autoRate + Number.EPSILON) * factor2) / factor2;
        return {
          from: fromCode,
          to: toCode,
          originalAmount: amount,
          convertedAmount: convertedAmount2,
          rate: autoRate,
          lastUpdated: this.config.lastAutomaticFetch || (/* @__PURE__ */ new Date()).toISOString(),
          formattedOriginal: formatCurrencyAmount(amount, fromCode, { precision: fromPrecision }),
          formattedConverted: formatCurrencyAmount(convertedAmount2, toCode, { precision: toPrecision }),
          rateMode: "automatic",
          rateFreshness: "fresh",
          rateProvider: "Standard Exchange Reference Cache",
          isCustomRate: false,
          rateProfileName: "Automatic Live Rate"
        };
      }
    }
    let rate = options.customRate || null;
    let profileName = profile.name;
    if (rate === null) {
      const resolved = this.resolveRate(fromCode, toCode, personal, profile);
      if (resolved) {
        rate = resolved.rate;
        profileName = resolved.profileName;
      }
    }
    if (rate === null || isNaN(rate) || rate <= 0) {
      throw new MissingManualRateError(fromCode, toCode, profileName);
    }
    const factor = Math.pow(10, toPrecision);
    const convertedAmount = Math.round((amount * rate + Number.EPSILON) * factor) / factor;
    const isStale = this.isRateStale(personal.lastUpdated);
    const freshness = isStale ? "stale" : "fresh";
    return {
      from: fromCode,
      to: toCode,
      originalAmount: amount,
      convertedAmount,
      rate,
      lastUpdated: personal.lastUpdated,
      formattedOriginal: formatCurrencyAmount(amount, fromCode, { precision: fromPrecision }),
      formattedConverted: formatCurrencyAmount(convertedAmount, toCode, { precision: toPrecision }),
      rateMode: "manual",
      rateFreshness: freshness,
      rateProvider: `Personal Rate: 1 ${personal.baseCurrency} = ${personal.rate} ${personal.targetCurrency}`,
      isCustomRate: true,
      rateProfileName: profileName
    };
  }
  parseBulkRatesText(text, defaultTargetCurrency = "INR") {
    const results = [];
    const lines = text.split(/\r?\n/);
    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line || line.startsWith("#") || line.startsWith("//"))
        continue;
      if (line.includes(",")) {
        const parts = line.split(",").map((p) => p.trim());
        if (parts.length >= 3) {
          const from = parts[0].toUpperCase();
          const to = parts[1].toUpperCase();
          const rate = parseFloat(parts[2]);
          if (!isNaN(rate) && rate > 0)
            results.push({ from, to, rate });
        } else if (parts.length === 2) {
          const from = parts[0].toUpperCase();
          const rate = parseFloat(parts[1]);
          if (!isNaN(rate) && rate > 0)
            results.push({ from, to: defaultTargetCurrency.toUpperCase(), rate });
        }
        continue;
      }
      const matchEquals = line.match(/(?:1\s+)?([A-Za-z]{3})\s*(?:=|\/|:|-)\s*(\d+(?:[.,]\d+)?)\s*([A-Za-z]{3})?/i);
      if (matchEquals) {
        const from = matchEquals[1].toUpperCase();
        const rate = parseFloat(matchEquals[2].replace(",", "."));
        const to = (matchEquals[3] || defaultTargetCurrency).toUpperCase();
        if (!isNaN(rate) && rate > 0)
          results.push({ from, to, rate });
      }
    }
    return results;
  }
  async getRates() {
    return {
      base: this.personalRate.baseCurrency,
      rates: {
        [this.personalRate.baseCurrency]: 1,
        [this.personalRate.targetCurrency]: this.personalRate.rate,
        ...this.personalRate.additionalRates || {}
      },
      lastUpdated: this.personalRate.lastUpdated,
      provider: "Personal Google Rate Entry"
    };
  }
};
var exchangeRateService = PersonalRateEngine.getInstance();

// src/popup/popup.ts
var heroBaseCode = document.getElementById("hero-base-code");
var heroRateVal = document.getElementById("hero-rate-val");
var heroTargetCode = document.getElementById("hero-target-code");
var freshnessTag = document.getElementById("freshness-tag");
var freshnessText = document.getElementById("freshness-text");
var timestampText = document.getElementById("timestamp-text");
var staleWarning = document.getElementById("stale-warning");
var linkGoogle = document.getElementById("link-google");
var stepQuerySub = document.getElementById("step-query-sub");
var baseCurrencyBtn = document.getElementById("base-currency-btn");
var baseFlag = document.getElementById("base-flag");
var baseCode = document.getElementById("base-code");
var baseName = document.getElementById("base-name");
var baseDropdownPopover = document.getElementById("base-dropdown-popover");
var baseSearchInput = document.getElementById("base-search-input");
var baseOptionsList = document.getElementById("base-options-list");
var targetCurrencyBtn = document.getElementById("target-currency-btn");
var targetFlag = document.getElementById("target-flag");
var targetCode = document.getElementById("target-code");
var targetName = document.getElementById("target-name");
var targetDropdownPopover = document.getElementById("target-dropdown-popover");
var targetSearchInput = document.getElementById("target-search-input");
var targetOptionsList = document.getElementById("target-options-list");
var btnSwapPair = document.getElementById("btn-swap-pair");
var rateInputLabel = document.getElementById("rate-input-label");
var rateInputPrefix = document.getElementById("rate-input-prefix");
var inputRateVal = document.getElementById("input-rate-val");
var inputSuffixCode = document.getElementById("input-suffix-code");
var btnSaveRate = document.getElementById("btn-save-rate");
var btnSaveLabel = document.getElementById("btn-save-label");
var btnCancelEdit = document.getElementById("btn-cancel-edit");
var pairsCountBadge = document.getElementById("pairs-count-badge");
var savedPairsList = document.getElementById("saved-pairs-list");
var reminderToggle = document.getElementById("reminder-toggle");
var planBadge = document.getElementById("plan-badge");
var usageText = document.getElementById("usage-text");
var progressBarFill = document.getElementById("progress-bar-fill");
var linkDashboard = document.getElementById("link-dashboard");
var WEBSITE_URL = APP_CONFIG.websiteUrl;
var selectedBase = "USD";
var selectedTarget = "INR";
var editingPairId = null;
var savedPairs = [];
var currentConfig = null;
function getFilteredCurrencies(search = "") {
  const query = search.trim().toLowerCase();
  const allCodes = Object.keys(CURRENCIES);
  const filtered = allCodes.filter((code) => {
    if (!query)
      return true;
    const c = CURRENCIES[code];
    return code.toLowerCase().includes(query) || c.name.toLowerCase().includes(query) || c.symbol && c.symbol.toLowerCase().includes(query);
  });
  return filtered.sort((a, b) => {
    const isPopA = POPULAR_CURRENCIES.includes(a);
    const isPopB = POPULAR_CURRENCIES.includes(b);
    if (isPopA && !isPopB)
      return -1;
    if (!isPopA && isPopB)
      return 1;
    return a.localeCompare(b);
  });
}
function renderDropdownOptions(listEl, selectedCode, onSelect, search = "") {
  listEl.innerHTML = "";
  const codes = getFilteredCurrencies(search);
  if (codes.length === 0) {
    const emptyLi = document.createElement("li");
    emptyLi.style.padding = "8px";
    emptyLi.style.fontSize = "11px";
    emptyLi.style.color = "#94a3b8";
    emptyLi.style.textAlign = "center";
    emptyLi.textContent = "No currency found";
    listEl.appendChild(emptyLi);
    return;
  }
  for (const code of codes) {
    const curr = CURRENCIES[code];
    const li = document.createElement("li");
    li.className = `dropdown-option-item ${code === selectedCode ? "selected" : ""}`;
    li.innerHTML = `
      <div class="dropdown-option-left">
        <span class="curr-flag">${curr.flag}</span>
        <span class="dropdown-option-code">${code}</span>
      </div>
      <span class="dropdown-option-name" title="${curr.name}">${curr.name}</span>
    `;
    li.addEventListener("click", (e) => {
      e.stopPropagation();
      onSelect(code);
    });
    listEl.appendChild(li);
  }
}
function closeAllDropdowns() {
  baseDropdownPopover.classList.remove("open");
  baseCurrencyBtn.classList.remove("open");
  targetDropdownPopover.classList.remove("open");
  targetCurrencyBtn.classList.remove("open");
}
function setupBaseDropdown() {
  baseCurrencyBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    const isOpen = baseDropdownPopover.classList.contains("open");
    closeAllDropdowns();
    if (!isOpen) {
      baseDropdownPopover.classList.add("open");
      baseCurrencyBtn.classList.add("open");
      baseSearchInput.value = "";
      renderDropdownOptions(baseOptionsList, selectedBase, (newCode) => {
        if (newCode === selectedTarget) {
          selectedTarget = selectedBase;
        }
        selectedBase = newCode;
        closeAllDropdowns();
        onPairChanged();
      });
      setTimeout(() => baseSearchInput.focus(), 50);
    }
  });
  baseSearchInput.addEventListener("input", () => {
    renderDropdownOptions(
      baseOptionsList,
      selectedBase,
      (newCode) => {
        if (newCode === selectedTarget) {
          selectedTarget = selectedBase;
        }
        selectedBase = newCode;
        closeAllDropdowns();
        onPairChanged();
      },
      baseSearchInput.value
    );
  });
}
function setupTargetDropdown() {
  targetCurrencyBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    const isOpen = targetDropdownPopover.classList.contains("open");
    closeAllDropdowns();
    if (!isOpen) {
      targetDropdownPopover.classList.add("open");
      targetCurrencyBtn.classList.add("open");
      targetSearchInput.value = "";
      renderDropdownOptions(targetOptionsList, selectedTarget, (newCode) => {
        if (newCode === selectedBase) {
          selectedBase = selectedTarget;
        }
        selectedTarget = newCode;
        closeAllDropdowns();
        onPairChanged();
      });
      setTimeout(() => targetSearchInput.focus(), 50);
    }
  });
  targetSearchInput.addEventListener("input", () => {
    renderDropdownOptions(
      targetOptionsList,
      selectedTarget,
      (newCode) => {
        if (newCode === selectedBase) {
          selectedBase = selectedTarget;
        }
        selectedTarget = newCode;
        closeAllDropdowns();
        onPairChanged();
      },
      targetSearchInput.value
    );
  });
}
document.addEventListener("click", () => {
  closeAllDropdowns();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    closeAllDropdowns();
  }
});
function updateFormUI() {
  const bCurr = CURRENCIES[selectedBase] || { flag: "\u{1F310}", code: selectedBase, name: selectedBase };
  const tCurr = CURRENCIES[selectedTarget] || { flag: "\u{1F310}", code: selectedTarget, name: selectedTarget };
  baseFlag.textContent = bCurr.flag;
  baseCode.textContent = bCurr.code;
  baseName.textContent = bCurr.name;
  targetFlag.textContent = tCurr.flag;
  targetCode.textContent = tCurr.code;
  targetName.textContent = tCurr.name;
  rateInputLabel.textContent = `Google Exchange Rate (1 ${selectedBase} = ? ${selectedTarget})`;
  rateInputPrefix.textContent = `1 ${selectedBase} =`;
  inputSuffixCode.textContent = selectedTarget;
  if (linkGoogle) {
    linkGoogle.href = `https://www.google.com/search?q=1+${selectedBase.toLowerCase()}+to+${selectedTarget.toLowerCase()}`;
  }
  if (stepQuerySub) {
    stepQuerySub.textContent = `"1 ${selectedBase} to ${selectedTarget} live rate"`;
  }
}
function onPairChanged() {
  updateFormUI();
  if (!editingPairId) {
    const existingPair = savedPairs.find(
      (p) => p.baseCurrency === selectedBase && p.targetCurrency === selectedTarget
    );
    if (existingPair) {
      inputRateVal.value = existingPair.rate.toString();
    } else {
      const reversePair = savedPairs.find(
        (p) => p.baseCurrency === selectedTarget && p.targetCurrency === selectedBase
      );
      if (reversePair && reversePair.rate > 0) {
        const inv = 1 / reversePair.rate;
        inputRateVal.value = (inv < 0.01 ? inv.toFixed(6) : inv < 1 ? inv.toFixed(4) : inv.toFixed(2)).replace(/\.?0+$/, "");
      } else {
        inputRateVal.value = "";
      }
    }
  }
}
btnSwapPair.addEventListener("click", () => {
  const oldBase = selectedBase;
  const oldTarget = selectedTarget;
  selectedBase = oldTarget;
  selectedTarget = oldBase;
  const currentVal = parseFloat(inputRateVal.value);
  if (!isNaN(currentVal) && currentVal > 0) {
    const inv = 1 / currentVal;
    inputRateVal.value = (inv < 0.01 ? inv.toFixed(6) : inv < 1 ? inv.toFixed(4) : inv.toFixed(2)).replace(/\.?0+$/, "");
  }
  onPairChanged();
});
function formatTimestamp(isoString) {
  try {
    const d = new Date(isoString);
    if (isNaN(d.getTime()))
      return "Recently";
    const isToday = (/* @__PURE__ */ new Date()).toDateString() === d.toDateString();
    const timeStr = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    if (isToday)
      return `Today at ${timeStr}`;
    return d.toLocaleDateString([], { month: "short", day: "numeric" }) + ` at ${timeStr}`;
  } catch {
    return "Recently";
  }
}
function updateHeroDisplay(config) {
  heroBaseCode.textContent = config.baseCurrency;
  heroTargetCode.textContent = config.targetCurrency;
  const formattedRate = config.rate < 0.01 ? config.rate.toFixed(6) : config.rate < 1 ? config.rate.toFixed(4) : config.rate.toFixed(2);
  heroRateVal.textContent = formattedRate;
  const ageMs = Date.now() - new Date(config.lastUpdated).getTime();
  const isStale = ageMs >= 24 * 60 * 60 * 1e3;
  timestampText.textContent = `Updated ${formatTimestamp(config.lastUpdated)}`;
  if (isStale) {
    freshnessTag.className = "freshness-tag stale";
    freshnessText.textContent = "Stale Rate (>24h)";
    staleWarning.classList.add("show");
  } else {
    freshnessTag.className = "freshness-tag fresh";
    freshnessText.textContent = "Fresh Rate";
    staleWarning.classList.remove("show");
  }
}
function renderSavedPairsList() {
  savedPairsList.innerHTML = "";
  pairsCountBadge.textContent = `${savedPairs.length} ${savedPairs.length === 1 ? "Pair" : "Pairs"}`;
  if (savedPairs.length === 0) {
    return;
  }
  for (const pair of savedPairs) {
    const fromCurr = CURRENCIES[pair.baseCurrency] || { flag: "\u{1F310}", code: pair.baseCurrency };
    const toCurr = CURRENCIES[pair.targetCurrency] || { flag: "\u{1F310}", code: pair.targetCurrency };
    const ageMs = Date.now() - new Date(pair.lastUpdated).getTime();
    const isStale = ageMs >= 24 * 60 * 60 * 1e3;
    const formattedRate = pair.rate < 0.01 ? pair.rate.toFixed(6) : pair.rate < 1 ? pair.rate.toFixed(4) : pair.rate.toFixed(2);
    const card = document.createElement("div");
    card.className = `saved-pair-card ${pair.isActive ? "active-pair" : ""}`;
    card.innerHTML = `
      <div class="pair-info-left">
        <div class="pair-title-row">
          <span>${fromCurr.flag} ${pair.baseCurrency} \u2192 ${toCurr.flag} ${pair.targetCurrency}</span>
          ${pair.isActive ? '<span class="pair-active-tag">Active</span>' : ""}
        </div>
        <div class="pair-rate-val">
          1 ${pair.baseCurrency} = ${formattedRate} ${pair.targetCurrency}
        </div>
        <div class="pair-meta-sub">
          <span>${isStale ? "\u26A0\uFE0F Stale" : "\u2713 Fresh"}</span>
          <span>\u2022</span>
          <span>${formatTimestamp(pair.lastUpdated)}</span>
        </div>
      </div>
      <div class="pair-actions">
        <!-- Update Rate Google Button -->
        <button class="btn-action-icon btn-update-rate" data-id="${pair.id}" title="Check live rate on Google & update">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="23 4 23 10 17 10"/>
            <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>
          </svg>
        </button>

        <!-- Edit Button -->
        <button class="btn-action-icon btn-edit-pair" data-id="${pair.id}" title="Edit this pair">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
          </svg>
        </button>

        <!-- Set Active Button (if not already active) -->
        ${!pair.isActive ? `<button class="btn-action-icon btn-set-active" data-id="${pair.id}" title="Set as primary active pair">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
              </button>` : ""}

        <!-- Delete Button -->
        <button class="btn-action-icon danger btn-delete-pair" data-id="${pair.id}" title="Delete this pair">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="3 6 5 6 21 6"/>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
          </svg>
        </button>
      </div>
    `;
    const btnUpdate = card.querySelector(".btn-update-rate");
    btnUpdate.addEventListener("click", (e) => {
      e.stopPropagation();
      const gUrl = `https://www.google.com/search?q=1+${pair.baseCurrency.toLowerCase()}+to+${pair.targetCurrency.toLowerCase()}`;
      chrome.tabs.create({ url: gUrl });
      selectedBase = pair.baseCurrency;
      selectedTarget = pair.targetCurrency;
      editingPairId = pair.id;
      inputRateVal.value = pair.rate.toString();
      btnSaveLabel.textContent = `Update Rate (${pair.baseCurrency} \u2192 ${pair.targetCurrency})`;
      btnCancelEdit.style.display = "block";
      updateFormUI();
      inputRateVal.focus();
      inputRateVal.select();
    });
    const btnEdit = card.querySelector(".btn-edit-pair");
    btnEdit.addEventListener("click", (e) => {
      e.stopPropagation();
      selectedBase = pair.baseCurrency;
      selectedTarget = pair.targetCurrency;
      editingPairId = pair.id;
      inputRateVal.value = pair.rate.toString();
      btnSaveLabel.textContent = `Update Rate (${pair.baseCurrency} \u2192 ${pair.targetCurrency})`;
      btnCancelEdit.style.display = "block";
      updateFormUI();
      inputRateVal.focus();
      inputRateVal.select();
    });
    const btnActive = card.querySelector(".btn-set-active");
    if (btnActive) {
      btnActive.addEventListener("click", (e) => {
        e.stopPropagation();
        chrome.runtime.sendMessage({ type: "SET_ACTIVE_PAIR", data: { pairId: pair.id } }, (res) => {
          if (res && res.personalRate) {
            currentConfig = res.personalRate;
            savedPairs = res.personalRate.savedPairs || [];
            updateHeroDisplay(res.personalRate);
            renderSavedPairsList();
          }
        });
      });
    }
    const btnDel = card.querySelector(".btn-delete-pair");
    btnDel.addEventListener("click", (e) => {
      e.stopPropagation();
      chrome.runtime.sendMessage({ type: "DELETE_SAVED_PAIR", data: { pairId: pair.id } }, (res) => {
        if (res && res.personalRate) {
          currentConfig = res.personalRate;
          savedPairs = res.personalRate.savedPairs || [];
          if (editingPairId === pair.id) {
            cancelEditMode();
          }
          updateHeroDisplay(res.personalRate);
          renderSavedPairsList();
        }
      });
    });
    savedPairsList.appendChild(card);
  }
}
function cancelEditMode() {
  editingPairId = null;
  btnSaveLabel.textContent = "Save Currency Pair";
  btnCancelEdit.style.display = "none";
  if (currentConfig) {
    selectedBase = currentConfig.baseCurrency;
    selectedTarget = currentConfig.targetCurrency;
    inputRateVal.value = currentConfig.rate.toString();
  }
  updateFormUI();
}
btnCancelEdit.addEventListener("click", () => {
  cancelEditMode();
});
btnSaveRate.addEventListener("click", () => {
  const rateVal = parseFloat(inputRateVal.value);
  if (isNaN(rateVal) || rateVal <= 0) {
    alert("Please enter a valid positive exchange rate from Google Search.");
    inputRateVal.focus();
    return;
  }
  const reminder = reminderToggle.checked;
  btnSaveRate.disabled = true;
  btnSaveLabel.textContent = "Saving...";
  chrome.runtime.sendMessage(
    {
      type: "SAVE_PERSONAL_RATE",
      data: {
        baseCurrency: selectedBase,
        targetCurrency: selectedTarget,
        rate: rateVal,
        dailyReminderEnabled: reminder,
        savedPairs
      }
    },
    (res) => {
      btnSaveRate.disabled = false;
      if (res && res.personalRate) {
        currentConfig = res.personalRate;
        savedPairs = res.personalRate.savedPairs || [];
        updateHeroDisplay(res.personalRate);
        renderSavedPairsList();
        cancelEditMode();
        btnSaveRate.innerHTML = `
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px;">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
          <span>Saved Currency Pair!</span>
        `;
        setTimeout(() => {
          btnSaveRate.innerHTML = `
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:15px;height:15px;">
              <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
              <polyline points="17 21 17 13 7 13 7 21"/>
              <polyline points="7 3 7 8 15 8"/>
            </svg>
            <span id="btn-save-label">Save Currency Pair</span>
          `;
        }, 1800);
      }
    }
  );
});
reminderToggle.addEventListener("change", () => {
  chrome.runtime.sendMessage({
    type: "TOGGLE_REMINDER",
    data: { enabled: reminderToggle.checked }
  });
});
async function loadData() {
  chrome.runtime.sendMessage({ type: "GET_PERSONAL_RATE" }, (res) => {
    if (res && res.personalRate) {
      const config = res.personalRate;
      currentConfig = config;
      savedPairs = config.savedPairs || [
        {
          id: `${config.baseCurrency}_${config.targetCurrency}`,
          baseCurrency: config.baseCurrency,
          targetCurrency: config.targetCurrency,
          rate: config.rate,
          lastUpdated: config.lastUpdated,
          isActive: true
        }
      ];
      selectedBase = config.baseCurrency || "USD";
      selectedTarget = config.targetCurrency || "INR";
      inputRateVal.value = config.rate.toString();
      reminderToggle.checked = config.dailyReminderEnabled !== false;
      updateFormUI();
      updateHeroDisplay(config);
      renderSavedPairsList();
      if (res.userPlan === "pro") {
        planBadge.innerHTML = `<svg viewBox="0 0 24 24"><path d="M2 4l3 12h14l3-12-6 7-4-7-4 7-6-7zm3 16h14"/></svg><span>Pro Plan</span>`;
        planBadge.className = "plan-badge pro";
        usageText.textContent = `${res.usageCount} conversions`;
        progressBarFill.style.width = "100%";
        if (linkDashboard)
          linkDashboard.textContent = "Pro Active";
      } else {
        planBadge.innerHTML = `<svg viewBox="0 0 24 24"><path d="M2 4l3 12h14l3-12-6 7-4-7-4 7-6-7zm3 16h14"/></svg><span>Free Plan</span>`;
        planBadge.className = "plan-badge";
        usageText.textContent = `${res.usageCount} / 29 used`;
        const percentage = Math.min(100, Math.round(res.usageCount / 29 * 100));
        progressBarFill.style.width = `${percentage}%`;
        if (linkDashboard)
          linkDashboard.textContent = "Free Plan";
        try {
          chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]?.id && (tabs[0]?.url?.includes("currenceconverter.me") || tabs[0]?.url?.includes("localhost"))) {
              chrome.tabs.sendMessage(tabs[0].id, { type: "REQUEST_PLAN_SYNC" }, (syncRes) => {
                if (syncRes?.plan === "pro") {
                  chrome.runtime.sendMessage({ type: "SYNC_USER_PLAN", data: { plan: "pro" } }, () => {
                    loadData();
                  });
                }
              });
            }
          });
        } catch {
        }
      }
    }
  });
}
planBadge.addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: `${WEBSITE_URL}/pricing` });
});
if (linkDashboard) {
  linkDashboard.addEventListener("click", (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: `${WEBSITE_URL}/dashboard` });
  });
}
setupBaseDropdown();
setupTargetDropdown();
loadData();
//# sourceMappingURL=popup.js.map
